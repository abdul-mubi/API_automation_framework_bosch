
local DiagCom = tdutil.loadLibrary("DiagCom")
local ODX = tdutil.loadLibrary("ODX")

----------------------------------------------------------------------------------------------------------
-- WARNING: All byte positions follow Lua convention (index starts at 1) !!!!
----------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------
-- BaseVariant
----------------------------------------------------------------------------------------------------------

local UDSonCAN_Bosch = ODX.BaseVariant:new("UDSonCAN_Bosch", {})

function UDSonCAN_Bosch.getBaseVariant()
	return UDSonCAN_Bosch
end

function UDSonCAN_Bosch.getEcuVariant()
	if (UDSonCAN_Bosch[UDSonCAN_Bosch:getVariant()] ~= nil) then
		return UDSonCAN_Bosch[UDSonCAN_Bosch:getVariant()]
	end

	return UDSonCAN_Bosch
end

-- DtcDops

UDSonCAN_Bosch.DtcDops.DtcDopRef=ODX.DtcDop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 24, ODX.Encoding.NONE, false, nil, false),ODX.Identical:new(),ODX.DataType.A_UINT32,{[1]={textId='TE_DTC_01'},[2]={textId='TE_DTC_02'},[3]={textId='TE_DTC_03'}})

-- Dops

UDSonCAN_Bosch.Dops.Unsigned_1Byte=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),ODX.Identical:new(),ODX.DataType.A_UINT32,nil,nil,nil,nil)
UDSonCAN_Bosch.Dops.Unsigned_2Byte=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 16, ODX.Encoding.NONE, false, nil, false),ODX.Identical:new(),ODX.DataType.A_UINT32,nil,nil,nil,nil)
UDSonCAN_Bosch.Dops.Unsigned_3Byte=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 24, ODX.Encoding.NONE, false, nil, false),ODX.Identical:new(),ODX.DataType.A_UINT32,nil,nil,nil,nil)
UDSonCAN_Bosch.Dops.NUMBER_OF_IDENTIFIERS=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),ODX.Identical:new(),ODX.DataType.A_UINT32,nil,nil,nil,nil)
UDSonCAN_Bosch.Dops.NRC_DOP=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),ODX.TextTable:new(nil,{{low=16,text="General reject"},{low=17,text="Service not supported"},{low=18,text="Subfunction not supported"},{low=19,text="Incorrect message length or invalid format"},{low=20,text="Response too long"},{low=34,text="Conditions not correct"},{low=36,text="Request sequence error"},{low=49,text="Request out of range"},{low=51,text="Security access denied"},{low=114,text="General programming failure"},{low=120,text="Request correctly received - response pending"}}),ODX.DataType.A_UNICODE2STRING,nil,{{low=0,high=15,validity=ODX.Validity.NOT_DEFINED},{low=21,high=33,validity=ODX.Validity.NOT_DEFINED},{low=35,validity=ODX.Validity.NOT_DEFINED},{low=37,high=48,validity=ODX.Validity.NOT_DEFINED},{low=50,validity=ODX.Validity.NOT_DEFINED},{low=52,high=113,validity=ODX.Validity.NOT_DEFINED},{low=115,high=119,validity=ODX.Validity.NOT_DEFINED},{low=121,high=255,validity=ODX.Validity.NOT_DEFINED}},nil,nil)

-- Structures

UDSonCAN_Bosch.Structures.ListOfDTCAndStatus=ODX.Structure:new("ListOfDTCAndStatus", nil, {ODX.ValueParameter:new("DTCTable","DATA",1,0,nil,UDSonCAN_Bosch:getEcuVariant():getByShortName("DtcDopRef")),ODX.ValueParameter:new("DTCStatus","DATA",4,0,nil,function () return UDSonCAN_Bosch.Dops.Unsigned_1Byte end)})
UDSonCAN_Bosch.Structures.ListOfDTCSnapshots=ODX.Structure:new("ListOfDTCSnapshots", nil, {ODX.ValueParameter:new("DTCSnapshotRecordNumber","DATA",1,0,nil,function () return UDSonCAN_Bosch.Dops.Unsigned_1Byte end),ODX.ValueParameter:new("DTCSnapshotRecord","DATA",2,0,nil,function () return UDSonCAN_Bosch.DynamicLengthFields.LIST_OF_DTC_SNAPSHOT_RECORD end)})
UDSonCAN_Bosch.Structures.SNAPSHOT_RECORD=ODX.Structure:new("SNAPSHOT_RECORD", nil, {ODX.ValueParameter:new("DataIdentifier","DATA",1,0,nil,function () return UDSonCAN_Bosch.Dops.Unsigned_2Byte end),ODX.ValueParameter:new("SnapshotData","DATA",3,0,nil,function () return UDSonCAN_Bosch.Dops.Unsigned_1Byte end)})

-- Tables



-- Muxs



-- EndOfPduFields

UDSonCAN_Bosch.EndOfPduFields.ListOfDTCAndStatus=ODX.EndOfPduField:new(UDSonCAN_Bosch.Structures.ListOfDTCAndStatus, nil, nil)
UDSonCAN_Bosch.EndOfPduFields.ListOfDTCSnapshots=ODX.EndOfPduField:new(UDSonCAN_Bosch.Structures.ListOfDTCSnapshots, nil, nil)

-- DynamicLengthFields

UDSonCAN_Bosch.DynamicLengthFields.LIST_OF_DTC_SNAPSHOT_RECORD=ODX.DynamicLengthField:new(UDSonCAN_Bosch.Structures.SNAPSHOT_RECORD, 1, 0, UDSonCAN_Bosch.Dops.NUMBER_OF_IDENTIFIERS)

-- EnvDatas



-- EnvDataDescs



-- Requests

function UDSonCAN_Bosch.Requests.RQ_ReadDTCByStatusMask_19_02(context)
	local r = DiagCom.Request:new({25,2})
	r:encodeParameter(ODX.ValueParameter:new("DTCStatusMask","DATA",3,0,nil,function () return UDSonCAN_Bosch.Dops.Unsigned_1Byte end),context)

	return r
end

function UDSonCAN_Bosch.Requests.RQ_ReadDTCSnapshotRecordByDTCNumber_19_04(context)
	local r = DiagCom.Request:new({25,4})
	r:encodeParameter(ODX.ValueParameter:new("DTCMaskRecord","DATA",3,0,nil,function () return UDSonCAN_Bosch.Dops.Unsigned_3Byte end),context)
	r:encodeParameter(ODX.ValueParameter:new("DTCSnapshotRecordNumber","DATA",6,0,nil,function () return UDSonCAN_Bosch.Dops.Unsigned_1Byte end),context)

	return r
end

-- PosResponses

function UDSonCAN_Bosch.PosResponses.PR_ReadDTCByStatusMask_19_02(buf, context)
	local params = {}
	
	params.SID_PR = ODX.CodedConstParameter:new("SID_PR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),89)
	params.ReportType = ODX.CodedConstParameter:new("ReportType","SUBFUNCTION",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),2)
	if (params.SID_PR:matchParameter(buf) and params.ReportType:matchParameter(buf)) then
		local resp = DiagCom.Response:new("PR_ReadDTCByStatusMask_19_02", true)
		
		local byteOffset = params.SID_PR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_PR)
		
		byteOffset = params.ReportType:decodeParameter(buf, nil, context)
		resp:addParameter(params.ReportType)
		
		params.DTCStatusAvailabilityMask = ODX.ValueParameter:new("DTCStatusAvailabilityMask","DATA",3,0,nil,function () return UDSonCAN_Bosch.Dops.Unsigned_1Byte end)
		byteOffset = params.DTCStatusAvailabilityMask:decodeParameter(buf, nil, context)
		resp:addParameter(params.DTCStatusAvailabilityMask)
		
		params.LIST_OF_DTC_AND_STATUS = ODX.ValueParameter:new("LIST_OF_DTC_AND_STATUS","DATA",4,0,nil,function () return UDSonCAN_Bosch.EndOfPduFields.ListOfDTCAndStatus end)
		byteOffset = params.LIST_OF_DTC_AND_STATUS:decodeParameter(buf, nil, context)
		resp:addParameter(params.LIST_OF_DTC_AND_STATUS)
		
		return resp
	end
end

function UDSonCAN_Bosch.PosResponses.PR_ReadDTCSnapshotRecordByDTCNumber_19_04(buf, context)
	local params = {}
	
	params.SID_PR = ODX.CodedConstParameter:new("SID_PR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),89)
	params.ReportType = ODX.CodedConstParameter:new("ReportType","SUBFUNCTION",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),4)
	if (params.SID_PR:matchParameter(buf) and params.ReportType:matchParameter(buf)) then
		local resp = DiagCom.Response:new("PR_ReadDTCSnapshotRecordByDTCNumber_19_04", true)
		
		local byteOffset = params.SID_PR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_PR)
		
		byteOffset = params.ReportType:decodeParameter(buf, nil, context)
		resp:addParameter(params.ReportType)
		
		params.DTC = ODX.ValueParameter:new("DTC","DATA",3,0,nil,UDSonCAN_Bosch:getEcuVariant():getByShortName("DtcDopRef"))
		byteOffset = params.DTC:decodeParameter(buf, nil, context)
		resp:addParameter(params.DTC)
		
		params.DTCStatus = ODX.ValueParameter:new("DTCStatus","DATA",6,0,nil,function () return UDSonCAN_Bosch.Dops.Unsigned_1Byte end)
		byteOffset = params.DTCStatus:decodeParameter(buf, nil, context)
		resp:addParameter(params.DTCStatus)
		
		params.LIST_OF_SNAPSHOTS = ODX.ValueParameter:new("LIST_OF_SNAPSHOTS","DATA",7,0,nil,function () return UDSonCAN_Bosch.EndOfPduFields.ListOfDTCSnapshots end)
		byteOffset = params.LIST_OF_SNAPSHOTS:decodeParameter(buf, nil, context)
		resp:addParameter(params.LIST_OF_SNAPSHOTS)
		
		return resp
	end
end


-- NegResponses

function UDSonCAN_Bosch.NegResponses.NR_ReadDTCInformation_19(buf, context)
	local params = {}
	
	params.SID_NR = ODX.CodedConstParameter:new("SID_NR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	params.SID_RQ_NR = ODX.CodedConstParameter:new("SID_RQ_NR","SERVICEIDRQ",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),25)
	params.NRCConst_NRC = ODX.NrcConstParameter:new("NRCConst_NRC","DATA",3,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),{18,19,49})
	if (params.SID_NR:matchParameter(buf) and params.SID_RQ_NR:matchParameter(buf) and params.NRCConst_NRC:matchParameter(buf)) then
		local resp = DiagCom.Response:new("NR_ReadDTCInformation_19", false)
		
		local byteOffset = params.SID_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_NR)
		
		byteOffset = params.SID_RQ_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_RQ_NR)
		
		params.NRC = ODX.ValueParameter:new("NRC","DATA",3,0,nil,function () return UDSonCAN_Bosch.Dops.NRC_DOP end)
		byteOffset = params.NRC:decodeParameter(buf, nil, context)
		resp:addParameter(params.NRC)
		
		byteOffset = params.NRCConst_NRC:decodeParameter(buf, nil, context)
		resp:addParameter(params.NRCConst_NRC)
		
		return resp
	end
end

function UDSonCAN_Bosch.NegResponses.NR_ReadDTCInformation_19(buf, context)
	local params = {}
	
	params.SID_NR = ODX.CodedConstParameter:new("SID_NR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	params.SID_RQ_NR = ODX.CodedConstParameter:new("SID_RQ_NR","SERVICEIDRQ",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),25)
	params.NRCConst_NRC = ODX.NrcConstParameter:new("NRCConst_NRC","DATA",3,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),{18,19,49})
	if (params.SID_NR:matchParameter(buf) and params.SID_RQ_NR:matchParameter(buf) and params.NRCConst_NRC:matchParameter(buf)) then
		local resp = DiagCom.Response:new("NR_ReadDTCInformation_19", false)
		
		local byteOffset = params.SID_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_NR)
		
		byteOffset = params.SID_RQ_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_RQ_NR)
		
		params.NRC = ODX.ValueParameter:new("NRC","DATA",3,0,nil,function () return UDSonCAN_Bosch.Dops.NRC_DOP end)
		byteOffset = params.NRC:decodeParameter(buf, nil, context)
		resp:addParameter(params.NRC)
		
		byteOffset = params.NRCConst_NRC:decodeParameter(buf, nil, context)
		resp:addParameter(params.NRCConst_NRC)
		
		return resp
	end
end


-- GlobalNegResponses

function UDSonCAN_Bosch.GlobalNegResponses.UNSUPPORTED_SERVICE_NR(buf, context)
	local params = {}
	
	params.SID_NR = ODX.CodedConstParameter:new("SID_NR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	params.NRCConst_NRC = ODX.NrcConstParameter:new("NRCConst_NRC","DATA",3,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),{16,17,18,120})
	if (params.SID_NR:matchParameter(buf) and params.NRCConst_NRC:matchParameter(buf)) then
		local resp = DiagCom.Response:new("UNSUPPORTED_SERVICE_NR", false)
		
		local byteOffset = params.SID_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_NR)
		
		params.SID_RQ_NR = ODX.ReservedParameter:new("SID_RQ_NR",nil,2,0,nil,8)
		byteOffset = params.SID_RQ_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_RQ_NR)
		
		params.NRC = ODX.ValueParameter:new("NRC","DATA",3,0,nil,function () return UDSonCAN_Bosch.Dops.NRC_DOP end)
		byteOffset = params.NRC:decodeParameter(buf, nil, context)
		resp:addParameter(params.NRC)
		
		byteOffset = params.NRCConst_NRC:decodeParameter(buf, nil, context)
		resp:addParameter(params.NRCConst_NRC)
		
		return resp
	end
end


-- Services

UDSonCAN_Bosch.Services.ReadDTCByStatusMask_19_02 = UDSonCAN_Bosch:declareService("ReadDTCByStatusMask_19_02",UDSonCAN_Bosch.Requests.RQ_ReadDTCByStatusMask_19_02,{PR_ReadDTCByStatusMask_19_02=UDSonCAN_Bosch.PosResponses.PR_ReadDTCByStatusMask_19_02,NR_ReadDTCInformation_19=UDSonCAN_Bosch.NegResponses.NR_ReadDTCInformation_19,UNSUPPORTED_SERVICE_NR=UDSonCAN_Bosch.GlobalNegResponses.UNSUPPORTED_SERVICE_NR})
UDSonCAN_Bosch.Services.ReadDTCSnapshotRecordByDTCNumber_19_04 = UDSonCAN_Bosch:declareService("ReadDTCSnapshotRecordByDTCNumber_19_04",UDSonCAN_Bosch.Requests.RQ_ReadDTCSnapshotRecordByDTCNumber_19_04,{PR_ReadDTCSnapshotRecordByDTCNumber_19_04=UDSonCAN_Bosch.PosResponses.PR_ReadDTCSnapshotRecordByDTCNumber_19_04,NR_ReadDTCInformation_19=UDSonCAN_Bosch.NegResponses.NR_ReadDTCInformation_19,UNSUPPORTED_SERVICE_NR=UDSonCAN_Bosch.GlobalNegResponses.UNSUPPORTED_SERVICE_NR})

-- Semantics

UDSonCAN_Bosch.Semantics["DEFAULT-FAULT-READ"] = function ()
return {UDSonCAN_Bosch.Services.ReadDTCByStatusMask_19_02}
end


UDSonCAN_Bosch.Semantics["FAULTMEMORY"] = function ()
return {UDSonCAN_Bosch.Services.ReadDTCSnapshotRecordByDTCNumber_19_04}
end


-- DiagnosticClasses



----------------------------------------------------------------------------------------------------------
-- Variants
----------------------------------------------------------------------------------------------------------



function UDSonCAN_Bosch.getEcuVariants()
	return {}
end

return UDSonCAN_Bosch