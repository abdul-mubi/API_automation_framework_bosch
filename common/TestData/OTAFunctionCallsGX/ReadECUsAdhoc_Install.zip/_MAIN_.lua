-- Publisher version: 2.0.0.202004031512
local common_paths_available = type(package.searchers[2]('RdaLualibPaths')) == "function"
if (common_paths_available) then
	require('RdaLualibPaths')
else
end
package.path = './_lib/?.lua;./_odx/?.lua;' .. package.path
package.cpath = './_lib/?.dll;./_lib/?.so;' .. package.cpath

local RDCOM_NAME = 'RDCOM'
local common_rdcom_available = type(package.searchers[2](RDCOM_NAME)) == "function"
if (not common_rdcom_available) then
	print("Note: Common RDCOM.lua not available, using explicit platform version as fallback")
	RDCOM_NAME = 'RDCOM_PLCS'
end
require('loadLibrary')
require('TDLIB')

RDCOM = tdutil.loadLibrary(RDCOM_NAME)
if (tdutil.loadScriptParameters) then tdutil.loadScriptParameters() end
RDCOM.initializePlatform()

local _var_seq_result = OtxModule.executeMain('VMS2.RemoteDiagnostics', 'ReadECUs', _ENV)
RDCOM.releasePlatform()
return _var_seq_result
