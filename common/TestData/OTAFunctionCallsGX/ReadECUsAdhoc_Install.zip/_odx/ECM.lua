
local DiagCom = tdutil.loadLibrary("DiagCom")
local ODX = tdutil.loadLibrary("ODX")

----------------------------------------------------------------------------------------------------------
-- WARNING: All byte positions follow Lua convention (index starts at 1) !!!!
----------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------
-- BaseVariant
----------------------------------------------------------------------------------------------------------

local ECM = ODX.BaseVariant:new("ECM", {ODX.getFunctionalGroup("FGUDS")})

function ECM.getBaseVariant()
	return ECM
end

function ECM.getEcuVariant()
	if (ECM[ECM:getVariant()] ~= nil) then
		return ECM[ECM:getVariant()]
	end

	return ECM
end

-- DtcDops



-- Dops

ECM.Dops.DOP_FlexASCii=ODX.Dop:new(ODX.MinMaxLengthType:new(ODX.DataType.A_ASCIISTRING, ODX.Encoding.ISO_8859_1, true, 1, 128, ODX.Termination.ZERO),ODX.Identical:new(),ODX.DataType.A_UNICODE2STRING,nil,nil,nil,nil)
ECM.Dops.DOP_16ASCii=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_ASCIISTRING, 128, ODX.Encoding.ISO_8859_1, true, nil, false),ODX.Identical:new(),ODX.DataType.A_UNICODE2STRING,nil,nil,nil,nil)
ECM.Dops.Read_DOP=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),ODX.TextTable:new(nil,{{low=1,text="TEXT"},{low=51,text="Security access denied"},{low=120,text="Request correctly received - response pending"},{low=49,text="Request out of range"},{low=19,text="Incorrect message length or invalid format"},{low=34,text="Conditions not correct"}}),ODX.DataType.A_UNICODE2STRING,nil,{{low=0,validity=ODX.Validity.NOT_DEFINED},{low=2,high=18,validity=ODX.Validity.NOT_DEFINED},{low=20,high=33,validity=ODX.Validity.NOT_DEFINED},{low=35,high=48,validity=ODX.Validity.NOT_DEFINED},{low=50,validity=ODX.Validity.NOT_DEFINED},{low=52,high=119,validity=ODX.Validity.NOT_DEFINED},{low=121,high=255,validity=ODX.Validity.NOT_DEFINED}},nil,nil)

-- Structures



-- Tables



-- Muxs



-- EndOfPduFields



-- DynamicLengthFields



-- EnvDatas



-- EnvDataDescs



-- Requests

function ECM.Requests.ReqDS_HumanReadableControllerName(context)
	local r = DiagCom.Request:new({34,241,240})
	
	return r
end

function ECM.Requests.ReqDS_ReadEcuHwVersion(context)
	local r = DiagCom.Request:new({34,241,241})
	
	return r
end

function ECM.Requests.ReqDS_ReadEcuSwVersion(context)
	local r = DiagCom.Request:new({34,241,242})
	
	return r
end

function ECM.Requests.ReqDS_ReadEcuSerialNumber(context)
	local r = DiagCom.Request:new({34,241,243})
	
	return r
end

function ECM.Requests.ReqDS_ReadEcuVendorId(context)
	local r = DiagCom.Request:new({34,241,244})
	
	return r
end

-- PosResponses

function ECM.PosResponses.PosRespDS_HumanReadableControllerName(buf, context)
	local params = {}
	
	params.PRCode = ODX.CodedConstParameter:new("PRCode",nil,1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),98)
	params.newCodedConst = ODX.CodedConstParameter:new("newCodedConst","LOCAL-ID",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 16, ODX.Encoding.NONE, true, nil, false),61936)
	if (params.PRCode:matchParameter(buf) and params.newCodedConst:matchParameter(buf)) then
		local resp = DiagCom.Response:new("PosRespDS_HumanReadableControllerName", true)
		
		local byteOffset = params.PRCode:decodeParameter(buf, nil, context)
		resp:addParameter(params.PRCode)
		
		byteOffset = params.newCodedConst:decodeParameter(buf, nil, context)
		resp:addParameter(params.newCodedConst)
		
		params.Data = ODX.ValueParameter:new("Data","DATA",byteOffset,0,nil,function () return ECM.Dops.DOP_FlexASCii end)
		byteOffset = params.Data:decodeParameter(buf, nil, context)
		resp:addParameter(params.Data)
		
		return resp
	end
end

function ECM.PosResponses.PosRespDS_ReadHwVersion(buf, context)
	local params = {}
	
	params.SID_PR = ODX.CodedConstParameter:new("SID_PR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),98)
	params.DID = ODX.CodedConstParameter:new("DID","DATA",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 16, ODX.Encoding.NONE, true, nil, false),61937)
	if (params.SID_PR:matchParameter(buf) and params.DID:matchParameter(buf)) then
		local resp = DiagCom.Response:new("PosRespDS_ReadHwVersion", true)
		
		local byteOffset = params.SID_PR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_PR)
		
		byteOffset = params.DID:decodeParameter(buf, nil, context)
		resp:addParameter(params.DID)
		
		params.HardwareVersion = ODX.ValueParameter:new("HardwareVersion","DATA",4,0,nil,function () return ECM.Dops.DOP_16ASCii end)
		byteOffset = params.HardwareVersion:decodeParameter(buf, nil, context)
		resp:addParameter(params.HardwareVersion)
		
		return resp
	end
end

function ECM.PosResponses.PosRespDS_ReadSwVersion(buf, context)
	local params = {}
	
	params.SID_PR = ODX.CodedConstParameter:new("SID_PR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),98)
	params.DID = ODX.CodedConstParameter:new("DID","DATA",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 16, ODX.Encoding.NONE, true, nil, false),61938)
	if (params.SID_PR:matchParameter(buf) and params.DID:matchParameter(buf)) then
		local resp = DiagCom.Response:new("PosRespDS_ReadSwVersion", true)
		
		local byteOffset = params.SID_PR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_PR)
		
		byteOffset = params.DID:decodeParameter(buf, nil, context)
		resp:addParameter(params.DID)
		
		params.SoftwareVersion = ODX.ValueParameter:new("SoftwareVersion","DATA",4,0,nil,function () return ECM.Dops.DOP_16ASCii end)
		byteOffset = params.SoftwareVersion:decodeParameter(buf, nil, context)
		resp:addParameter(params.SoftwareVersion)
		
		return resp
	end
end

function ECM.PosResponses.PosRespDS_ReadECUSerialNumber(buf, context)
	local params = {}
	
	params.PRCode = ODX.CodedConstParameter:new("PRCode",nil,1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),98)
	params.DID = ODX.CodedConstParameter:new("DID","LOCAL-ID",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 16, ODX.Encoding.NONE, true, nil, false),61939)
	if (params.PRCode:matchParameter(buf) and params.DID:matchParameter(buf)) then
		local resp = DiagCom.Response:new("PosRespDS_ReadECUSerialNumber", true)
		
		local byteOffset = params.PRCode:decodeParameter(buf, nil, context)
		resp:addParameter(params.PRCode)
		
		byteOffset = params.DID:decodeParameter(buf, nil, context)
		resp:addParameter(params.DID)
		
		params.Data = ODX.ValueParameter:new("Data","DATA",byteOffset,0,nil,function () return ECM.Dops.DOP_FlexASCii end)
		byteOffset = params.Data:decodeParameter(buf, nil, context)
		resp:addParameter(params.Data)
		
		return resp
	end
end

function ECM.PosResponses.PosRespDS_ReadECUVendorID(buf, context)
	local params = {}
	
	params.PRCode = ODX.CodedConstParameter:new("PRCode",nil,1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),98)
	params.DID = ODX.CodedConstParameter:new("DID","LOCAL-ID",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 16, ODX.Encoding.NONE, true, nil, false),61940)
	if (params.PRCode:matchParameter(buf) and params.DID:matchParameter(buf)) then
		local resp = DiagCom.Response:new("PosRespDS_ReadECUVendorID", true)
		
		local byteOffset = params.PRCode:decodeParameter(buf, nil, context)
		resp:addParameter(params.PRCode)
		
		byteOffset = params.DID:decodeParameter(buf, nil, context)
		resp:addParameter(params.DID)
		
		params.Data = ODX.ValueParameter:new("Data","DATA",byteOffset,0,nil,function () return ECM.Dops.DOP_FlexASCii end)
		byteOffset = params.Data:decodeParameter(buf, nil, context)
		resp:addParameter(params.Data)
		
		return resp
	end
end


-- NegResponses

function ECM.NegResponses.NR_Read_IDENTIFICATION(buf, context)
	local params = {}
	
	params.SID_NR = ODX.CodedConstParameter:new("SID_NR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	params.SIDRQ_NR = ODX.CodedConstParameter:new("SIDRQ_NR","SERVICEIDRQ",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),34)
	if (params.SID_NR:matchParameter(buf) and params.SIDRQ_NR:matchParameter(buf)) then
		local resp = DiagCom.Response:new("NR_Read_IDENTIFICATION", false)
		
		local byteOffset = params.SID_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_NR)
		
		byteOffset = params.SIDRQ_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SIDRQ_NR)
		
		params.PRM_Read = ODX.ValueParameter:new("PRM_Read","DATA",3,0,nil,function () return ECM.Dops.Read_DOP end)
		byteOffset = params.PRM_Read:decodeParameter(buf, nil, context)
		resp:addParameter(params.PRM_Read)
		
		return resp
	end
end

function ECM.NegResponses.NR_Read_IDENTIFICATION(buf, context)
	local params = {}
	
	params.SID_NR = ODX.CodedConstParameter:new("SID_NR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	params.SIDRQ_NR = ODX.CodedConstParameter:new("SIDRQ_NR","SERVICEIDRQ",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),34)
	if (params.SID_NR:matchParameter(buf) and params.SIDRQ_NR:matchParameter(buf)) then
		local resp = DiagCom.Response:new("NR_Read_IDENTIFICATION", false)
		
		local byteOffset = params.SID_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_NR)
		
		byteOffset = params.SIDRQ_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SIDRQ_NR)
		
		params.PRM_Read = ODX.ValueParameter:new("PRM_Read","DATA",3,0,nil,function () return ECM.Dops.Read_DOP end)
		byteOffset = params.PRM_Read:decodeParameter(buf, nil, context)
		resp:addParameter(params.PRM_Read)
		
		return resp
	end
end

function ECM.NegResponses.NR_Read_IDENTIFICATION(buf, context)
	local params = {}
	
	params.SID_NR = ODX.CodedConstParameter:new("SID_NR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	params.SIDRQ_NR = ODX.CodedConstParameter:new("SIDRQ_NR","SERVICEIDRQ",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),34)
	if (params.SID_NR:matchParameter(buf) and params.SIDRQ_NR:matchParameter(buf)) then
		local resp = DiagCom.Response:new("NR_Read_IDENTIFICATION", false)
		
		local byteOffset = params.SID_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_NR)
		
		byteOffset = params.SIDRQ_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SIDRQ_NR)
		
		params.PRM_Read = ODX.ValueParameter:new("PRM_Read","DATA",3,0,nil,function () return ECM.Dops.Read_DOP end)
		byteOffset = params.PRM_Read:decodeParameter(buf, nil, context)
		resp:addParameter(params.PRM_Read)
		
		return resp
	end
end

function ECM.NegResponses.NR_Read_IDENTIFICATION(buf, context)
	local params = {}
	
	params.SID_NR = ODX.CodedConstParameter:new("SID_NR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	params.SIDRQ_NR = ODX.CodedConstParameter:new("SIDRQ_NR","SERVICEIDRQ",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),34)
	if (params.SID_NR:matchParameter(buf) and params.SIDRQ_NR:matchParameter(buf)) then
		local resp = DiagCom.Response:new("NR_Read_IDENTIFICATION", false)
		
		local byteOffset = params.SID_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_NR)
		
		byteOffset = params.SIDRQ_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SIDRQ_NR)
		
		params.PRM_Read = ODX.ValueParameter:new("PRM_Read","DATA",3,0,nil,function () return ECM.Dops.Read_DOP end)
		byteOffset = params.PRM_Read:decodeParameter(buf, nil, context)
		resp:addParameter(params.PRM_Read)
		
		return resp
	end
end

function ECM.NegResponses.NR_Read_IDENTIFICATION(buf, context)
	local params = {}
	
	params.SID_NR = ODX.CodedConstParameter:new("SID_NR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	params.SIDRQ_NR = ODX.CodedConstParameter:new("SIDRQ_NR","SERVICEIDRQ",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),34)
	if (params.SID_NR:matchParameter(buf) and params.SIDRQ_NR:matchParameter(buf)) then
		local resp = DiagCom.Response:new("NR_Read_IDENTIFICATION", false)
		
		local byteOffset = params.SID_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_NR)
		
		byteOffset = params.SIDRQ_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SIDRQ_NR)
		
		params.PRM_Read = ODX.ValueParameter:new("PRM_Read","DATA",3,0,nil,function () return ECM.Dops.Read_DOP end)
		byteOffset = params.PRM_Read:decodeParameter(buf, nil, context)
		resp:addParameter(params.PRM_Read)
		
		return resp
	end
end


-- GlobalNegResponses

function ECM.GlobalNegResponses.GLOBAL_NRESP(buf, context)
	local params = {}
	
	params.RESPONSEID = ODX.CodedConstParameter:new("RESPONSEID","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	params.RSID = ODX.MatchingRequestParameter:new("RSID","ID",2,0,nil,1,1)
	params.NRCConst_NRC = ODX.NrcConstParameter:new("NRCConst_NRC","DATA",3,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),{16,17,18,19,33,34,36,49,51,53,54,55,112,113,114,115,120,126,127,129,130,131,132,133,134,135,136,137,138,139,140,141,143,144,145,146,147})
	if (params.RESPONSEID:matchParameter(buf) and params.RSID:matchParameter(buf, context.request) and params.NRCConst_NRC:matchParameter(buf)) then
		local resp = DiagCom.Response:new("GLOBAL_NRESP", false)
		
		local byteOffset = params.RESPONSEID:decodeParameter(buf, nil, context)
		resp:addParameter(params.RESPONSEID)
		
		byteOffset = params.RSID:decodeParameter(buf, nil, context)
		resp:addParameter(params.RSID)
		
		params.NRC = ODX.ValueParameter:new("NRC","DATA",3,0,nil,function () return ECM.Dops.NRC_DOP end)
		byteOffset = params.NRC:decodeParameter(buf, nil, context)
		resp:addParameter(params.NRC)
		
		byteOffset = params.NRCConst_NRC:decodeParameter(buf, nil, context)
		resp:addParameter(params.NRCConst_NRC)
		
		return resp
	end
end


-- Services

ECM.Services.DS_ReadHumanReadableControllerName = ECM:declareService("DS_ReadHumanReadableControllerName",ECM.Requests.ReqDS_HumanReadableControllerName,{PosRespDS_HumanReadableControllerName=ECM.PosResponses.PosRespDS_HumanReadableControllerName,NR_Read_IDENTIFICATION=ECM.NegResponses.NR_Read_IDENTIFICATION,GLOBAL_NRESP=ECM.GlobalNegResponses.GLOBAL_NRESP})
ECM.Services.DS_Read_EcuHwVersion = ECM:declareService("DS_Read_EcuHwVersion",ECM.Requests.ReqDS_ReadEcuHwVersion,{PosRespDS_ReadHwVersion=ECM.PosResponses.PosRespDS_ReadHwVersion,NR_Read_IDENTIFICATION=ECM.NegResponses.NR_Read_IDENTIFICATION,GLOBAL_NRESP=ECM.GlobalNegResponses.GLOBAL_NRESP})
ECM.Services.DS_Read_EcuSwVersion = ECM:declareService("DS_Read_EcuSwVersion",ECM.Requests.ReqDS_ReadEcuSwVersion,{PosRespDS_ReadSwVersion=ECM.PosResponses.PosRespDS_ReadSwVersion,NR_Read_IDENTIFICATION=ECM.NegResponses.NR_Read_IDENTIFICATION,GLOBAL_NRESP=ECM.GlobalNegResponses.GLOBAL_NRESP})
ECM.Services.DS_ReadECUSerialNumber = ECM:declareService("DS_ReadECUSerialNumber",ECM.Requests.ReqDS_ReadEcuSerialNumber,{PosRespDS_ReadECUSerialNumber=ECM.PosResponses.PosRespDS_ReadECUSerialNumber,NR_Read_IDENTIFICATION=ECM.NegResponses.NR_Read_IDENTIFICATION,GLOBAL_NRESP=ECM.GlobalNegResponses.GLOBAL_NRESP})
ECM.Services.DS_ReadECUVendorIdentification = ECM:declareService("DS_ReadECUVendorIdentification",ECM.Requests.ReqDS_ReadEcuVendorId,{PosRespDS_ReadECUVendorID=ECM.PosResponses.PosRespDS_ReadECUVendorID,NR_Read_IDENTIFICATION=ECM.NegResponses.NR_Read_IDENTIFICATION,GLOBAL_NRESP=ECM.GlobalNegResponses.GLOBAL_NRESP})

-- Semantics



-- DiagnosticClasses



----------------------------------------------------------------------------------------------------------
-- Variants
----------------------------------------------------------------------------------------------------------



function ECM.getEcuVariants()
	return {}
end

return ECM