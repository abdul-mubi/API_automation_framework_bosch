
local DiagCom = tdutil.loadLibrary("DiagCom")
local ODX = tdutil.loadLibrary("ODX")

----------------------------------------------------------------------------------------------------------
-- WARNING: All byte positions follow Lua convention (index starts at 1) !!!!
----------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------
-- FunctionalGroup
----------------------------------------------------------------------------------------------------------

local FGUDS = ODX.FunctionalGroup:new("FGUDS", function () return {ODX.getBaseVariant("AADEFAULTECU06"),ODX.getBaseVariant("BCM"),ODX.getBaseVariant("CC_BRAKE"),ODX.getBaseVariant("ECM"),ODX.getBaseVariant("ECU07"),ODX.getBaseVariant("ECU08"),ODX.getBaseVariant("ECU09"),ODX.getBaseVariant("ECU10"),ODX.getBaseVariant("PS"),ODX.getBaseVariant("TPMS"),ODX.getBaseVariant("VCM")} end)

function FGUDS.getFunctionalGroup()
	return FGUDS
end

-- DtcDops



-- Dops

FGUDS.Dops.NRC_DOP=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),ODX.TextTable:new(nil,{{low=0,text="0",inverse=0},{low=1,high=15,text="ISOSAEReserved_01_0F",inverse=1},{low=16,text="generalReject",inverse=16},{low=17,text="serviceNotSupported",inverse=17},{low=18,text="subFunctionNotSupported",inverse=18},{low=19,text="incorrectMessageLengthOrInvalidFormat",inverse=19},{low=20,text="responseTooLong",inverse=20},{low=21,high=32,text="ISOSAEReserved_15_20",inverse=21},{low=33,text="busyRepeatRequest",inverse=33},{low=34,text="conditionsNotCorrect",inverse=34},{low=35,text="ISOSAEReserved_23",inverse=35},{low=36,text="requestSequenceError",inverse=36},{low=37,high=48,text="ISOSAEReserved_25_30",inverse=37},{low=49,text="requestOutOfRange",inverse=49},{low=50,text="ISOSAEReserved_32",inverse=50},{low=51,text="securityAccessDenied",inverse=51},{low=52,text="ISOSAEReserved_34",inverse=52},{low=53,text="invalidKey",inverse=53},{low=54,text="exceedNumberOfAttempts",inverse=54},{low=55,text="requiredTimeDelayNotExpired",inverse=55},{low=56,high=79,text="reservedByExtendedDataLinkSecurityDocument_38_4F",inverse=56},{low=80,high=111,text="ISOSAEReserved_50_6F",inverse=80},{low=112,text="uploadDownloadNotAccepted",inverse=112},{low=113,text="transferDataSuspended",inverse=113},{low=114,text="generalProgrammingFailure",inverse=114},{low=115,text="wrongBlockSequenceCounter",inverse=115},{low=116,high=119,text="ISOSAEReserved_74_77",inverse=116},{low=120,text="requestCorrectlyReceived-ResponsePending",inverse=120},{low=121,high=125,text="ISOSAEReserved_79_7D",inverse=121},{low=126,text="subFunctionNotSupportedInActiveSession",inverse=126},{low=127,text="serviceNotSupportedInActiveSession",inverse=127},{low=128,text="ISOSAEReserved_80",inverse=128},{low=129,text="rpmTooHigh",inverse=129},{low=130,text="rpmTooLow",inverse=130},{low=131,text="engineIsRunning",inverse=131},{low=132,text="engineIsNotRunning",inverse=132},{low=133,text="engineRunTimeTooLow",inverse=133},{low=134,text="temperatureTooHigh",inverse=134},{low=135,text="temperatureTooLow",inverse=135},{low=136,text="vehicleSpeedTooHigh",inverse=136},{low=137,text="vehicleSpeedTooLow",inverse=137},{low=138,text="throttle/PedalTooHigh",inverse=138},{low=139,text="throttle/PedalTooLow",inverse=139},{low=140,text="transmissionRangeNotInNeutral",inverse=140},{low=141,text="transmissionRangeNotInGear",inverse=141},{low=142,text="ISOSAEReserved_8E",inverse=142},{low=143,text="brakeSwitch(es)NotClosed (Brake Pedal not pressed or not applied)",inverse=143},{low=144,text="shifterLeverNotInPark",inverse=144},{low=145,text="torqueConverterClutchLocked",inverse=145},{low=146,text="voltageTooHigh",inverse=146},{low=147,text="voltageTooLow",inverse=147},{low=148,high=254,text="reservedForSpecificConditionsNotCorrect_94_FE",inverse=148},{low=255,text="ISOSAEReserved_FF",inverse=255}}),ODX.DataType.A_UNICODE2STRING,nil,nil,nil,nil)

-- Structures



-- Tables



-- Muxs



-- EndOfPduFields



-- DynamicLengthFields



-- EnvDatas



-- EnvDataDescs



-- Requests



-- PosResponses



-- NegResponses



-- GlobalNegResponses



-- Services



-- Semantics



-- DiagnosticClasses



return FGUDS
