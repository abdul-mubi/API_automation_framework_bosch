-- arg[1] = '{ "meta" :  { "logLevel": "DEBUG", "dataPath": [ "." ] }}'
-- arg[1] = '{ "meta" :  { "logLevel": "DEBUG" }}'

-- workaround to make sure the metadata is available on lua-path even if it's declared as data rather than script
-- package.path = '../data/_odx/?.lua;' .. package.path

return dofile('_MAIN_.lua')
