if (tdutil == nil) then
	-- Publisher version: 2.0.0.202004031512
	local common_paths_available = type(package.searchers[2]('RdaLualibPaths')) == "function"
	if (common_paths_available) then
		require('RdaLualibPaths')
	else
	end
	package.path = './_lib/?.lua;./_odx/?.lua;' .. package.path
	package.cpath = './_lib/?.dll;./_lib/?.so;' .. package.cpath
	
	local RDCOM_NAME = 'RDCOM'
	local common_rdcom_available = type(package.searchers[2](RDCOM_NAME)) == "function"
	if (not common_rdcom_available) then
		print("Note: Common RDCOM.lua not available, using explicit platform version as fallback")
		RDCOM_NAME = 'RDCOM_PLCS'
	end
	require('loadLibrary')
	require('TDLIB')
end

tdutil.registerOtxNamespaceModules({['http://iso.org/OTX/ProprietaryInterface/BackendCallback']='BackendCallback',['http://iso.org/OTX/1.0.0/DiagCom']='DiagCom',['http://iso.org/OTX/1.0.0/Flash']='Flash',['http://iso.org/OTX/1.0.0/StringUtil']='StringUtil',['http://iso.org/OTX/1.0.0/DateTime']='DateTime',['http://iso.org/OTX/1.0.0/Event']='EventHandling',['http://iso.org/OTX/1.0.0/Quantities']='Quantities',['http://iso.org/OTX/1.0.0/HMI']='HMI',['http://iso.org/OTX/1.0.0/DiagDataBrowsing']='DiagDataBrowsing',['http://iso.org/OTX/1.0.0/File']='File',['http://iso.org/OTX/1.0.0/FlashPlus']='FlashPlus',['http://iso.org/OTX/ProprietaryInterface/FaultCodeSetting']='FaultCodeSetting',['http://iso.org/OTX/ExtensionInterface/Inventory']='Inventory',['http://iso.org/OTX/ExtensionInterface/Persistence']='Persistency',['http://iso.org/OTX/ProprietaryInterface/RemoteMeasurement']='RemoteMeasurement',['http://www.bosch.com/OTX/GX_SECURITY']='Security',['http://gradex.bosch.com/OTX/1.0.0/Telediagnosis']='Tele',['http://iso.org/OTX/ProprietaryInterface/UnifiedReturnStructures']='UnifiedReturnStructures',['http://iso.org/OTX/ProprietaryInterface/VehicleProperties']='VehicleProperties'})

tdutil.loadOtxNamespaceModule({'http://iso.org/OTX/1.0.0/DataType','http://iso.org/OTX/1.0.0/DateTime','http://iso.org/OTX/1.0.0/DiagCom','http://iso.org/OTX/1.0.0/Logging','http://iso.org/OTX/1.0.0/StringUtil'})
tdutil.loadCustomerNamespaceModule({'http://iso.org/OTX/ProprietaryInterface/UnifiedReturnStructures'})

local _ENV  = OtxModule.declare('VMS2.RemoteDiagnostics', 'ReadECUs', '0.24.0', _ENV)
_imp_doc_5FGetComParameterFromVIT = OtxModule.import('VMS2.RemoteDiagnostics', 'GetComParameterFromVIT', _ENV, {major=0,minor=11,revision=0})
_imp_doc_5FVehicleInventoryUtils = OtxModule.import('VMS2.RemoteDiagnostics', 'VehicleInventoryUtils', _ENV, {major=0,minor=14,revision=0})

OtxModule.setPublic('_prc_main', _ENV)
function _prc_main(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_ECU_5FID = String:new('')
	local _var_scriptResult = 0
	
	-- in and inout parameters
	if (argumentsTable._var_ECU_5FID ~= nil) then _var_ECU_5FID = tdutil.checkParamType(argumentsTable._var_ECU_5FID, String:new('')) end
	
	-- inout and out parameters
	getReturnTable = function() return {_var_scriptResult=_var_scriptResult} end
	
	-- procedure declarations
	local _var_comChannel = nil
	local _var_ComParams = MapUtils.createMap({},{'map','OTXString','OTXString'})
	local _var_VIT = ListType:new({}, {'list',{'map','OTXString','OTXString'}})
	local _var_i1 = 0
	local _var_ResultState = DiagCom.ResultState.ALL_FAILED
	local _var_Result = nil
	local _var_e1 = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_e2 = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_LossOfComException = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_userException = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_controllerName = String:new('')
	local _var_softwareVersion = String:new('')
	local _var_hardwareVersion = String:new('')
	local _var_serialNumber = String:new('')
	local _var_vendorID = String:new('')
	local _var_ecu = _imp_doc_5FVehicleInventoryUtils._prc_VehicleEcu()
	local _var_inventory = _imp_doc_5FVehicleInventoryUtils._prc_VehicleInventory()
	local _var_negResponse = String:new('')
	local _var_globalNegativeResponse = String:new('')
	local _var_traceID = 0
	local _var_DiagService = nil
	local _var_VIT2 = ListType:new({}, {'list',{'map','OTXString','OTXString'}})
	
	-- NODE-ID: handler1
	OtxDebug.setCurrentNodeId('handler1')
	OtxExceptions.handler(
		function() --try
				-- NODE-ID: action26
				OtxDebug.setCurrentNodeId('action26')
				_var_inventory[String:new('ecu')]:clear()
				
				-- NODE-ID: action21
				OtxDebug.setCurrentNodeId('action21')
				OtxDebug.addStackLevel('doc_GetComParameterFromVIT:main')
				local _tmp_returnTable1
				_tmp_returnTable1 = _imp_doc_5FGetComParameterFromVIT._prc_main({})
				OtxDebug.decrementStackLevel()
				if (_tmp_returnTable1 ~= nil) then
					_var_VIT = _tmp_returnTable1._var_VITout
				end
				
				-- NODE-ID: action27
				OtxDebug.setCurrentNodeId('action27')
				OtxDebug.addStackLevel('ReduceECUs')
				local _tmp_returnTable2
				_tmp_returnTable2 = _prc_ReduceECUs({_var_ECU_5FID = _var_ECU_5FID, _var_VIT1 = _var_VIT})
				OtxDebug.decrementStackLevel()
				if (_tmp_returnTable2 ~= nil) then
					_var_VIT2 = _tmp_returnTable2._var_VIT2
				end
				
				-- NODE-ID: action25
				OtxDebug.setCurrentNodeId('action25')
				_var_VIT = _var_VIT2
				
				-- NODE-ID: loop1
				OtxDebug.setCurrentNodeId('loop1')
				for _key in pairs(_var_VIT) do
					_var_i1 = _key
					
					-- NODE-ID: handler2
					OtxDebug.setCurrentNodeId('handler2')
					OtxExceptions.handler(
						function() --try
								-- NODE-ID: action15
								OtxDebug.setCurrentNodeId('action15')
								_var_ComParams = _var_VIT[_var_i1]
								
								-- NODE-ID: action14
								OtxDebug.setCurrentNodeId('action14')
								_var_comChannel = DiagCom.GetComChannel(_var_ComParams[String:new('memberLogicalLink')], nil, false)
								
								-- NODE-ID: group2
								OtxDebug.setCurrentNodeId('group2')
								OtxDebug.logSpecification('generic')
								do
									-- NODE-ID: action37
									OtxDebug.setCurrentNodeId('action37')
									_var_traceID = 1
									
									-- NODE-ID: action76
									OtxDebug.setCurrentNodeId('action76')
									_var_ecu[String:new('trace')]:clear()
									
									-- NODE-ID: action64
									OtxDebug.setCurrentNodeId('action64')
									_var_ecu[String:new('ecuAddress')] = OtxMath.ToInteger(_var_ComParams[String:new('CP_CanRespUSDTId')])
									
									-- NODE-ID: action43
									OtxDebug.setCurrentNodeId('action43')
									OtxDebug.logSpecification('ECU ID')
									-- SPEC: ECU ID
									_var_ecu[String:new('ecuId')] = _var_ComParams[String:new('memberLogicalLink')]
									
									-- NODE-ID: action18
									-- DISABLED!
									
									-- NODE-ID: action8
									OtxDebug.setCurrentNodeId('action8')
									OtxDebug.logSpecification('ECU VARIANT ID')
									-- SPEC: ECU VARIANT ID
									_var_ecu[String:new('ecuVariantId')] = DiagCom.GetComChannelEcuVariantName(_var_comChannel)
									
									-- NODE-ID: action7
									OtxDebug.setCurrentNodeId('action7')
									_var_ecu[String:new('timestamp')] = DateTime.GetTimestamp()
									
								end
								
								-- NODE-ID: handler4
								OtxDebug.setCurrentNodeId('handler4')
								OtxExceptions.handler(
									function() --try
											-- NODE-ID: handler3
											OtxDebug.setCurrentNodeId('handler3')
											OtxExceptions.handler(
												function() --try
														-- NODE-ID: group14
														OtxDebug.setCurrentNodeId('group14')
														OtxDebug.logSpecification('humanName')
														do
															-- NODE-ID: action122
															OtxDebug.setCurrentNodeId('action122')
															OtxDebug.logSpecification('DiagService')
															-- SPEC: DiagService
															_var_DiagService = DiagCom.CreateDiagServiceByName(_var_comChannel, String:new('DS_ReadHumanReadableControllerName'))
															
															-- NODE-ID: action123
															OtxDebug.setCurrentNodeId('action123')
															OtxDebug.logSpecification('Execution')
															-- SPEC: Execution
															_var_Result, _var_ResultState = DiagCom.ExecuteDiagService(_var_DiagService, {}, {[String:new('PosRespDS_HumanReadableControllerName')]=function (r) _var_controllerName=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('Data')}}));  end, [String:new('NR_Read_IDENTIFICATION')]=function (r) _var_negResponse=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('PRM_Read')}}));  end, [String:new('GLOBAL_NRESP')]=function (r) _var_globalNegativeResponse=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('NRC')}}));  end}, false, false)
															
															-- NODE-ID: action124
															OtxDebug.setCurrentNodeId('action124')
															OtxDebug.logSpecification('Check')
															-- SPEC: Check
															OtxDebug.addStackLevel('check')
															local _tmp_returnTable3
															_tmp_returnTable3 = _prc_check({_var_ResultState = _var_ResultState, _var_Result = _var_Result})
															OtxDebug.decrementStackLevel()
															
															-- NODE-ID: action125
															OtxDebug.setCurrentNodeId('action125')
															_var_ecu[String:new('name')] = _var_controllerName
															
															-- NODE-ID: action30
															OtxDebug.setCurrentNodeId('action30')
															writeLog(SeverityLevel.INFO, String:new('Human readable controller name = ').._var_controllerName)
															
														end
														
														-- NODE-ID: group10
														OtxDebug.setCurrentNodeId('group10')
														OtxDebug.logSpecification('swVersion')
														do
															-- NODE-ID: action109
															OtxDebug.setCurrentNodeId('action109')
															OtxDebug.logSpecification('DiagService')
															-- SPEC: DiagService
															_var_DiagService = DiagCom.CreateDiagServiceByName(_var_comChannel, String:new('DS_Read_EcuSwVersion'))
															
															-- NODE-ID: action49
															OtxDebug.setCurrentNodeId('action49')
															OtxDebug.logSpecification('Execution')
															-- SPEC: Execution
															_var_Result, _var_ResultState = DiagCom.ExecuteDiagService(_var_DiagService, {}, {[String:new('PosRespDS_ReadSwVersion')]=function (r) _var_softwareVersion=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('SoftwareVersion')}}));  end, [String:new('NR_Read_IDENTIFICATION')]=function (r) _var_negResponse=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('PRM_Read')}}));  end, [String:new('GLOBAL_NRESP')]=function (r) _var_globalNegativeResponse=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('NRC')}}));  end}, false, false)
															
															-- NODE-ID: action114
															OtxDebug.setCurrentNodeId('action114')
															OtxDebug.logSpecification('Check')
															-- SPEC: Check
															OtxDebug.addStackLevel('check')
															local _tmp_returnTable4
															_tmp_returnTable4 = _prc_check({_var_ResultState = _var_ResultState, _var_Result = _var_Result})
															OtxDebug.decrementStackLevel()
															
															-- NODE-ID: action132
															OtxDebug.setCurrentNodeId('action132')
															OtxDebug.addStackLevel('addParameter')
															local _tmp_returnTable5
															_tmp_returnTable5 = _prc_addParameter({_var_ParameterName = String:new('EcuSWVersion'), _var_traceID = _var_traceID, _var_valueString = _var_softwareVersion, _var_valueBF = ByteFieldType:new(DiagCom.GetFirstResponse(_var_Result).pdu), _var_traceRequest = ByteFieldType:new(DiagCom.GetRequest(_var_DiagService):getBytes()), _var_traceResponse = ByteFieldType:new(DiagCom.GetFirstResponse(_var_Result).pdu), _var_traceServiceId = String:new(_var_DiagService.name), _var_traceResponseId = String:new(DiagCom.GetFirstResponse(_var_Result).name), _var_ecuinout = _var_ecu})
															OtxDebug.decrementStackLevel()
															if (_tmp_returnTable5 ~= nil) then
																_var_ecu = _tmp_returnTable5._var_ecuinout
															end
															
															-- NODE-ID: action85
															OtxDebug.setCurrentNodeId('action85')
															_var_traceID = (_var_traceID + 1)
															
														end
														
														-- NODE-ID: group11
														OtxDebug.setCurrentNodeId('group11')
														OtxDebug.logSpecification('hwVersion')
														do
															-- NODE-ID: action103
															OtxDebug.setCurrentNodeId('action103')
															OtxDebug.logSpecification('DiagService')
															-- SPEC: DiagService
															_var_DiagService = DiagCom.CreateDiagServiceByName(_var_comChannel, String:new('DS_Read_EcuHwVersion'))
															
															-- NODE-ID: action115
															OtxDebug.setCurrentNodeId('action115')
															OtxDebug.logSpecification('Execution')
															-- SPEC: Execution
															_var_Result, _var_ResultState = DiagCom.ExecuteDiagService(_var_DiagService, {}, {[String:new('PosRespDS_ReadHwVersion')]=function (r) _var_hardwareVersion=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('HardwareVersion')}}));  end, [String:new('NR_Read_IDENTIFICATION')]=function (r) _var_negResponse=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('PRM_Read')}}));  end, [String:new('GLOBAL_NRESP')]=function (r) _var_globalNegativeResponse=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('NRC')}}));  end}, false, false)
															
															-- NODE-ID: action116
															OtxDebug.setCurrentNodeId('action116')
															OtxDebug.logSpecification('Check')
															-- SPEC: Check
															OtxDebug.addStackLevel('check')
															local _tmp_returnTable6
															_tmp_returnTable6 = _prc_check({_var_ResultState = _var_ResultState, _var_Result = _var_Result})
															OtxDebug.decrementStackLevel()
															
															-- NODE-ID: action153
															OtxDebug.setCurrentNodeId('action153')
															OtxDebug.addStackLevel('addParameter')
															local _tmp_returnTable7
															_tmp_returnTable7 = _prc_addParameter({_var_ParameterName = String:new('EcuHWVersion'), _var_traceID = _var_traceID, _var_valueString = _var_hardwareVersion, _var_valueBF = ByteFieldType:new(DiagCom.GetFirstResponse(_var_Result).pdu), _var_traceRequest = ByteFieldType:new(DiagCom.GetRequest(_var_DiagService):getBytes()), _var_traceResponse = ByteFieldType:new(DiagCom.GetFirstResponse(_var_Result).pdu), _var_traceServiceId = String:new(_var_DiagService.name), _var_traceResponseId = String:new(DiagCom.GetFirstResponse(_var_Result).name), _var_ecuinout = _var_ecu})
															OtxDebug.decrementStackLevel()
															if (_tmp_returnTable7 ~= nil) then
																_var_ecu = _tmp_returnTable7._var_ecuinout
															end
															
															-- NODE-ID: action2
															OtxDebug.setCurrentNodeId('action2')
															_var_traceID = (_var_traceID + 1)
															
														end
														
														-- NODE-ID: group12
														OtxDebug.setCurrentNodeId('group12')
														OtxDebug.logSpecification('serialNumber')
														do
															-- NODE-ID: action105
															OtxDebug.setCurrentNodeId('action105')
															_var_DiagService = DiagCom.CreateDiagServiceByName(_var_comChannel, String:new('DS_ReadECUSerialNumber'))
															
															-- NODE-ID: action117
															OtxDebug.setCurrentNodeId('action117')
															_var_Result, _var_ResultState = DiagCom.ExecuteDiagService(_var_DiagService, {}, {[String:new('PosRespDS_ReadECUSerialNumber')]=function (r) _var_serialNumber=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('Data')}}));  end, [String:new('NR_Read_IDENTIFICATION')]=function (r) _var_negResponse=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('PRM_Read')}}));  end, [String:new('GLOBAL_NRESP')]=function (r) _var_globalNegativeResponse=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('NRC')}}));  end}, false, false)
															
															-- NODE-ID: action118
															OtxDebug.setCurrentNodeId('action118')
															OtxDebug.logSpecification('Check')
															-- SPEC: Check
															OtxDebug.addStackLevel('check')
															local _tmp_returnTable8
															_tmp_returnTable8 = _prc_check({_var_ResultState = _var_ResultState, _var_Result = _var_Result})
															OtxDebug.decrementStackLevel()
															
															-- NODE-ID: action10
															OtxDebug.setCurrentNodeId('action10')
															OtxDebug.addStackLevel('addParameter')
															local _tmp_returnTable9
															_tmp_returnTable9 = _prc_addParameter({_var_ParameterName = String:new('SerialNumber'), _var_traceID = _var_traceID, _var_valueString = _var_serialNumber, _var_valueBF = ByteFieldType:new(DiagCom.GetFirstResponse(_var_Result).pdu), _var_traceRequest = ByteFieldType:new(DiagCom.GetRequest(_var_DiagService):getBytes()), _var_traceResponse = ByteFieldType:new(DiagCom.GetFirstResponse(_var_Result).pdu), _var_traceServiceId = String:new(_var_DiagService.name), _var_traceResponseId = String:new(DiagCom.GetFirstResponse(_var_Result).name), _var_ecuinout = _var_ecu})
															OtxDebug.decrementStackLevel()
															if (_tmp_returnTable9 ~= nil) then
																_var_ecu = _tmp_returnTable9._var_ecuinout
															end
															
															-- NODE-ID: action3
															OtxDebug.setCurrentNodeId('action3')
															_var_traceID = (_var_traceID + 1)
															
														end
														
														-- NODE-ID: group13
														OtxDebug.setCurrentNodeId('group13')
														OtxDebug.logSpecification('vendorID')
														do
															-- NODE-ID: action108
															OtxDebug.setCurrentNodeId('action108')
															_var_DiagService = DiagCom.CreateDiagServiceByName(_var_comChannel, String:new('DS_ReadECUVendorIdentification'))
															
															-- NODE-ID: action119
															OtxDebug.setCurrentNodeId('action119')
															_var_Result, _var_ResultState = DiagCom.ExecuteDiagService(_var_DiagService, {}, {[String:new('PosRespDS_ReadECUVendorID')]=function (r) _var_vendorID=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('Data')}}));  end, [String:new('NR_Read_IDENTIFICATION')]=function (r) _var_negResponse=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('PRM_Read')}}));  end, [String:new('GLOBAL_NRESP')]=function (r) _var_globalNegativeResponse=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('NRC')}}));  end}, false, false)
															
															-- NODE-ID: action120
															OtxDebug.setCurrentNodeId('action120')
															OtxDebug.logSpecification('Check')
															-- SPEC: Check
															OtxDebug.addStackLevel('check')
															local _tmp_returnTable10
															_tmp_returnTable10 = _prc_check({_var_ResultState = _var_ResultState, _var_Result = _var_Result})
															OtxDebug.decrementStackLevel()
															
															-- NODE-ID: action127
															OtxDebug.setCurrentNodeId('action127')
															OtxDebug.addStackLevel('addParameter')
															local _tmp_returnTable11
															_tmp_returnTable11 = _prc_addParameter({_var_ParameterName = String:new('EcuVendorId'), _var_traceID = _var_traceID, _var_valueString = _var_vendorID, _var_valueBF = ByteFieldType:new(DiagCom.GetFirstResponse(_var_Result).pdu), _var_traceRequest = ByteFieldType:new(DiagCom.GetRequest(_var_DiagService):getBytes()), _var_traceResponse = ByteFieldType:new(DiagCom.GetFirstResponse(_var_Result).pdu), _var_traceServiceId = String:new(_var_DiagService.name), _var_traceResponseId = String:new(DiagCom.GetFirstResponse(_var_Result).name), _var_ecuinout = _var_ecu})
															OtxDebug.decrementStackLevel()
															if (_tmp_returnTable11 ~= nil) then
																_var_ecu = _tmp_returnTable11._var_ecuinout
															end
															
															-- NODE-ID: action4
															OtxDebug.setCurrentNodeId('action4')
															_var_traceID = (_var_traceID + 1)
															
														end
														
														-- NODE-ID: action111
														OtxDebug.setCurrentNodeId('action111')
														OtxDebug.addStackLevel('addECU')
														local _tmp_returnTable12
														_tmp_returnTable12 = _prc_addECU({_var_ecuAddress = OtxMath.ToInteger(_var_ComParams[String:new('CP_CanRespUSDTId')]), _var_ecuID = _var_ComParams[String:new('memberLogicalLink')], _var_ecuVariantID = _var_ComParams[String:new('CP_ECULayerShortName')], _var_ecuName = _var_controllerName, _var_ecuParameterName = String:new('test'), _var_ecuinout = _var_ecu})
														OtxDebug.decrementStackLevel()
														if (_tmp_returnTable12 ~= nil) then
															_var_ecu = _tmp_returnTable12._var_ecuinout
														end
														
														-- NODE-ID: action73
														OtxDebug.setCurrentNodeId('action73')
														_var_inventory[String:new('ecu')]:append({tdutil.CopyStructure(_var_ecu)})
														
												end, { --catch
													OtxExceptions.createCatch('LossOfComException', 
														function(exception)
														end
													),
													OtxExceptions.createCatch('UserException', 
														function(exception)
															_var_userException = exception
															
														end
													),
												}, function() --finally
												end
											)
											
									end, { --catch
										OtxExceptions.createCatch('LossOfComException', 
											function(exception)
												_var_LossOfComException = exception
												
													-- NODE-ID: action9
													OtxDebug.setCurrentNodeId('action9')
													writeLog(SeverityLevel.INFO, String:new('ECU ')..ToString(_var_i1)..String:new('. ').._var_ComParams[String:new('memberLogicalLink')]..String:new(' not present ').._var_LossOfComException.text)
													
											end
										),
										OtxExceptions.createCatch('Exception', 
											function(exception)
												_var_e2 = exception
												
													-- NODE-ID: action29
													OtxDebug.setCurrentNodeId('action29')
													writeLog(SeverityLevel.INFO, String:new('ECU ')..ToString(_var_i1)..String:new('. ').._var_ComParams[String:new('memberLogicalLink')]..String:new(' not present ').._var_e2.text)
													
											end
										),
									}, function() --finally
									end
								)
								
								-- NODE-ID: action12
								OtxDebug.setCurrentNodeId('action12')
								DiagCom.CloseComChannel(_var_comChannel)
								
						end, { --catch
							OtxExceptions.createCatch('LossOfComException', 
								function(exception)
										-- NODE-ID: action16
										OtxDebug.setCurrentNodeId('action16')
										writeLog(SeverityLevel.INFO, String:new('ECU ')..ToString(_var_i1)..String:new('. ').._var_ComParams[String:new('memberLogicalLink')]..String:new(' not present'))
										
										-- NODE-ID: action19
										OtxDebug.setCurrentNodeId('action19')
										DiagCom.CloseComChannel(_var_comChannel)
										
								end
							),
							OtxExceptions.createCatch('Exception', 
								function(exception)
									_var_e1 = exception
									
										-- NODE-ID: action17
										OtxDebug.setCurrentNodeId('action17')
										writeLog(SeverityLevel.INFO, String:new('ECU ')..ToString(_var_i1)..String:new('. ').._var_ComParams[String:new('memberLogicalLink')]..String:new(' not present ').._var_e1.text)
										
										-- NODE-ID: action20
										OtxDebug.setCurrentNodeId('action20')
										DiagCom.CloseComChannel(_var_comChannel)
										
								end
							),
						}, function() --finally
						end
					)
					
					-- NODE-ID: macro1
					OtxDebug.setCurrentNodeId('macro1')
					do
					end
					
				end
				
				-- NODE-ID: action31
				OtxDebug.setCurrentNodeId('action31')
				setLogLevel(LogLevel.TRACE)
				
				-- NODE-ID: action62
				OtxDebug.setCurrentNodeId('action62')
				
UnifiedReturnStructures.EnableDebug(true) 
UnifiedReturnStructures.SaveVehicleInventory(_var_inventory)
				
				-- NODE-ID: action74
				OtxDebug.setCurrentNodeId('action74')
				_var_scriptResult = 0
				
		end, { --catch
			OtxExceptions.createCatch('LossOfComException', 
				function(exception)
						-- NODE-ID: action1
						OtxDebug.setCurrentNodeId('action1')
						writeLog(SeverityLevel.INFO, String:new('ECU ')..ToString(_var_i1)..String:new('. ').._var_ComParams[String:new('memberLogicalLink')]..String:new(' not present'))
						
				end
			),
			OtxExceptions.createCatch('Exception', 
				function(exception)
					_var_e1 = exception
					
						-- NODE-ID: action5
						OtxDebug.setCurrentNodeId('action5')
						writeLog(SeverityLevel.INFO, String:new('ECU ')..ToString(_var_i1)..String:new('. ').._var_VIT[String:new('i1')][String:new('memberLogicalLink')]..String:new(' not present ').._var_e1.text)
						
				end
			),
		}, function() --finally
		end
	)
	
	-- NODE-ID: action6
	OtxDebug.setCurrentNodeId('action6')
	_var_scriptResult = 0
	
	-- NODE-ID: return
	OtxDebug.setCurrentNodeId('return')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

function _prc_addECU(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_ecuAddress = 0
	local _var_ecuID = String:new('')
	local _var_ecuVariantID = String:new('')
	local _var_ecuName = String:new('')
	local _var_ecuParameterName = String:new('')
	local _var_ecuinout = _imp_doc_5FVehicleInventoryUtils._prc_VehicleEcu()
	
	-- in and inout parameters
	if (argumentsTable._var_ecuAddress ~= nil) then _var_ecuAddress = tdutil.checkParamType(argumentsTable._var_ecuAddress, 0) end
	if (argumentsTable._var_ecuID ~= nil) then _var_ecuID = tdutil.checkParamType(argumentsTable._var_ecuID, String:new('')) end
	if (argumentsTable._var_ecuVariantID ~= nil) then _var_ecuVariantID = tdutil.checkParamType(argumentsTable._var_ecuVariantID, String:new('')) end
	if (argumentsTable._var_ecuName ~= nil) then _var_ecuName = tdutil.checkParamType(argumentsTable._var_ecuName, String:new('')) end
	if (argumentsTable._var_ecuParameterName ~= nil) then _var_ecuParameterName = tdutil.checkParamType(argumentsTable._var_ecuParameterName, String:new('')) end
	if (argumentsTable._var_ecuinout ~= nil) then _var_ecuinout = tdutil.checkParamType(argumentsTable._var_ecuinout, _imp_doc_5FVehicleInventoryUtils._prc_VehicleEcu()) end
	
	-- inout and out parameters
	getReturnTable = function() return {_var_ecuinout=_var_ecuinout} end
	
	-- procedure declarations
	local _var_i1 = 0
	local _var_ecu = _imp_doc_5FVehicleInventoryUtils._prc_VehicleEcu()
	local _var_trace = _imp_doc_5FVehicleInventoryUtils._prc_TraceMessage()
	local _var_param = _imp_doc_5FVehicleInventoryUtils._prc_Parameter()
	local _var_traceID = 0
	
	-- NODE-ID: action106
	OtxDebug.setCurrentNodeId('action106')
	_var_ecu[String:new('trace')]:clear()
	
	-- NODE-ID: action110
	OtxDebug.setCurrentNodeId('action110')
	_var_ecu[String:new('otherParameter')]:clear()
	
	-- NODE-ID: group15
	OtxDebug.setCurrentNodeId('group15')
	OtxDebug.logSpecification('Generic')
	do
		-- NODE-ID: action112
		OtxDebug.setCurrentNodeId('action112')
		_var_i1 = 5
		
		-- NODE-ID: action113
		OtxDebug.setCurrentNodeId('action113')
		_var_ecu[String:new('ecuAddress')] = _var_ecuAddress
		
		-- NODE-ID: action136
		OtxDebug.setCurrentNodeId('action136')
		_var_ecu[String:new('ecuId')] = _var_ecuID
		
		-- NODE-ID: action137
		OtxDebug.setCurrentNodeId('action137')
		_var_ecu[String:new('ecuVariantId')] = _var_ecuVariantID
		
		-- NODE-ID: action138
		OtxDebug.setCurrentNodeId('action138')
		_var_ecu[String:new('name')] = _var_ecuName
		
		-- NODE-ID: action11
		OtxDebug.setCurrentNodeId('action11')
		_var_ecu[String:new('timestamp')] = DateTime.GetTimestamp()
		
	end
	
	-- NODE-ID: return1
	OtxDebug.setCurrentNodeId('return1')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

function _prc_check(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_ResultState = DiagCom.ResultState.ALL_FAILED
	local _var_Result = nil
	
	-- in and inout parameters
	if (argumentsTable._var_ResultState ~= nil) then _var_ResultState = tdutil.checkParamType(argumentsTable._var_ResultState, DiagCom.ResultState.ALL_FAILED) end
	if (argumentsTable._var_Result ~= nil) then _var_Result = tdutil.checkParamType(argumentsTable._var_Result, nil) end
	
	-- inout and out parameters
	getReturnTable = function() return {} end
	
	-- procedure declarations
	local _var_Response = nil
	
	-- NODE-ID: branch4
	OtxDebug.setCurrentNodeId('branch4')
	if (((Equals(_var_ResultState, DiagCom.ResultState.ALL_POSITIVE)) or (Equals(_var_ResultState, DiagCom.ResultState.POSITIVE)))) then
		-- NODE-ID: action135
		OtxDebug.setCurrentNodeId('action135')
		_var_Response = DiagCom.GetFirstResponse(_var_Result)
		
		-- NODE-ID: branch5
		OtxDebug.setCurrentNodeId('branch5')
		if (_var_Response.positive) then
		else
			-- NODE-ID: throw2
			OtxDebug.setCurrentNodeId('throw2')
			OtxExceptions.throw(OtxExceptions.createException('UserException', String:new('0801'), String:new('mandatory diag service')))
			
		end
		
	else
		-- NODE-ID: throw1
		OtxDebug.setCurrentNodeId('throw1')
		OtxExceptions.throw(OtxExceptions.createException('UserException', String:new('0800'), String:new('mandatory diag service')))
		
	end
	
	-- NODE-ID: return2
	OtxDebug.setCurrentNodeId('return2')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

function _prc_addParameter(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_ParameterName = String:new('')
	local _var_traceID = 0
	local _var_valueString = String:new('')
	local _var_valueBF = ByteFieldType:new()
	local _var_traceRequest = ByteFieldType:new()
	local _var_traceResponse = ByteFieldType:new()
	local _var_traceServiceId = String:new('')
	local _var_traceResponseId = String:new('')
	local _var_ecuinout = _imp_doc_5FVehicleInventoryUtils._prc_VehicleEcu()
	
	-- in and inout parameters
	if (argumentsTable._var_ParameterName ~= nil) then _var_ParameterName = tdutil.checkParamType(argumentsTable._var_ParameterName, String:new('')) end
	if (argumentsTable._var_traceID ~= nil) then _var_traceID = tdutil.checkParamType(argumentsTable._var_traceID, 0) end
	if (argumentsTable._var_valueString ~= nil) then _var_valueString = tdutil.checkParamType(argumentsTable._var_valueString, String:new('')) end
	if (argumentsTable._var_valueBF ~= nil) then _var_valueBF = tdutil.checkParamType(argumentsTable._var_valueBF, ByteFieldType:new()) end
	if (argumentsTable._var_traceRequest ~= nil) then _var_traceRequest = tdutil.checkParamType(argumentsTable._var_traceRequest, ByteFieldType:new()) end
	if (argumentsTable._var_traceResponse ~= nil) then _var_traceResponse = tdutil.checkParamType(argumentsTable._var_traceResponse, ByteFieldType:new()) end
	if (argumentsTable._var_traceServiceId ~= nil) then _var_traceServiceId = tdutil.checkParamType(argumentsTable._var_traceServiceId, String:new('')) end
	if (argumentsTable._var_traceResponseId ~= nil) then _var_traceResponseId = tdutil.checkParamType(argumentsTable._var_traceResponseId, String:new('')) end
	if (argumentsTable._var_ecuinout ~= nil) then _var_ecuinout = tdutil.checkParamType(argumentsTable._var_ecuinout, _imp_doc_5FVehicleInventoryUtils._prc_VehicleEcu()) end
	
	-- inout and out parameters
	getReturnTable = function() return {_var_ecuinout=_var_ecuinout} end
	
	-- procedure declarations
	local _var_ecu = _imp_doc_5FVehicleInventoryUtils._prc_VehicleEcu()
	local _var_trace = _imp_doc_5FVehicleInventoryUtils._prc_TraceMessage()
	
	-- NODE-ID: branch6
	OtxDebug.setCurrentNodeId('branch6')
	if ((Equals(_var_ParameterName, String:new('EcuSWVersion')))) then
		-- NODE-ID: action143
		OtxDebug.setCurrentNodeId('action143')
		_var_ecuinout[String:new('swVersion')][String:new('name')] = String:new('EcuSWVersion')
		
		-- NODE-ID: action147
		OtxDebug.setCurrentNodeId('action147')
		_var_ecuinout[String:new('swVersion')][String:new('traceRef')] = _var_traceID
		
		-- NODE-ID: action148
		OtxDebug.setCurrentNodeId('action148')
		_var_ecuinout[String:new('swVersion')][String:new('path')] = String:new('/')
		
		-- NODE-ID: action149
		OtxDebug.setCurrentNodeId('action149')
		_var_ecuinout[String:new('swVersion')][String:new('value')][String:new('valueType')] = _imp_doc_5FVehicleInventoryUtils._prc_ScalarValueType('STRING')
		
		-- NODE-ID: action150
		OtxDebug.setCurrentNodeId('action150')
		_var_ecuinout[String:new('swVersion')][String:new('value')][String:new('string_value')] = _var_valueString
		
		-- NODE-ID: action151
		OtxDebug.setCurrentNodeId('action151')
		_var_ecuinout[String:new('swVersion')][String:new('internal_value')] = _var_valueBF:getCopy()
		
		-- NODE-ID: action152
		OtxDebug.setCurrentNodeId('action152')
		writeLog(SeverityLevel.INFO, String:new('EcuSWVersion =').._var_valueString)
		
	elseif ((Equals(_var_ParameterName, String:new('EcuHWVersion')))) then
		-- NODE-ID: action13
		OtxDebug.setCurrentNodeId('action13')
		_var_ecuinout[String:new('hwVersion')][String:new('name')] = String:new('EcuHWVersion')
		
		-- NODE-ID: action128
		OtxDebug.setCurrentNodeId('action128')
		_var_ecuinout[String:new('hwVersion')][String:new('traceRef')] = _var_traceID
		
		-- NODE-ID: action129
		OtxDebug.setCurrentNodeId('action129')
		_var_ecuinout[String:new('hwVersion')][String:new('path')] = String:new('/')
		
		-- NODE-ID: action158
		OtxDebug.setCurrentNodeId('action158')
		_var_ecuinout[String:new('hwVersion')][String:new('value')][String:new('valueType')] = _imp_doc_5FVehicleInventoryUtils._prc_ScalarValueType('STRING')
		
		-- NODE-ID: action131
		OtxDebug.setCurrentNodeId('action131')
		_var_ecuinout[String:new('hwVersion')][String:new('value')][String:new('string_value')] = _var_valueString
		
		-- NODE-ID: action133
		OtxDebug.setCurrentNodeId('action133')
		_var_ecuinout[String:new('hwVersion')][String:new('internal_value')] = _var_valueBF:getCopy()
		
		-- NODE-ID: action134
		OtxDebug.setCurrentNodeId('action134')
		writeLog(SeverityLevel.INFO, _var_valueString)
		
	elseif ((Equals(_var_ParameterName, String:new('SerialNumber')))) then
		-- NODE-ID: action154
		OtxDebug.setCurrentNodeId('action154')
		_var_ecuinout[String:new('serialNumber')][String:new('name')] = String:new('SerialNumber')
		
		-- NODE-ID: action155
		OtxDebug.setCurrentNodeId('action155')
		_var_ecuinout[String:new('serialNumber')][String:new('traceRef')] = _var_traceID
		
		-- NODE-ID: action156
		OtxDebug.setCurrentNodeId('action156')
		_var_ecuinout[String:new('serialNumber')][String:new('path')] = String:new('/')
		
		-- NODE-ID: action160
		OtxDebug.setCurrentNodeId('action160')
		_var_ecuinout[String:new('serialNumber')][String:new('value')][String:new('valueType')] = _imp_doc_5FVehicleInventoryUtils._prc_ScalarValueType('STRING')
		
		-- NODE-ID: action130
		OtxDebug.setCurrentNodeId('action130')
		_var_ecuinout[String:new('serialNumber')][String:new('value')][String:new('string_value')] = _var_valueString
		
		-- NODE-ID: action159
		OtxDebug.setCurrentNodeId('action159')
		_var_ecuinout[String:new('serialNumber')][String:new('internal_value')] = _var_valueBF:getCopy()
		
		-- NODE-ID: action157
		OtxDebug.setCurrentNodeId('action157')
		writeLog(SeverityLevel.INFO, _var_valueString)
		
	elseif ((Equals(_var_ParameterName, String:new('EcuVendorId')))) then
		-- NODE-ID: action126
		OtxDebug.setCurrentNodeId('action126')
		_var_ecuinout[String:new('vendorId')][String:new('name')] = String:new('EcuVendorId')
		
		-- NODE-ID: action161
		OtxDebug.setCurrentNodeId('action161')
		_var_ecuinout[String:new('vendorId')][String:new('traceRef')] = _var_traceID
		
		-- NODE-ID: action162
		OtxDebug.setCurrentNodeId('action162')
		_var_ecuinout[String:new('vendorId')][String:new('path')] = String:new('/')
		
		-- NODE-ID: action164
		OtxDebug.setCurrentNodeId('action164')
		_var_ecuinout[String:new('vendorId')][String:new('value')][String:new('valueType')] = _imp_doc_5FVehicleInventoryUtils._prc_ScalarValueType('STRING')
		
		-- NODE-ID: action163
		OtxDebug.setCurrentNodeId('action163')
		_var_ecuinout[String:new('vendorId')][String:new('value')][String:new('string_value')] = _var_valueString
		
		-- NODE-ID: action165
		OtxDebug.setCurrentNodeId('action165')
		_var_ecuinout[String:new('vendorId')][String:new('internal_value')] = _var_valueBF:getCopy()
		
		-- NODE-ID: action166
		OtxDebug.setCurrentNodeId('action166')
		writeLog(SeverityLevel.INFO, _var_valueString)
		
	else
	end
	
	-- NODE-ID: group1
	OtxDebug.setCurrentNodeId('group1')
	do
		-- NODE-ID: action32
		OtxDebug.setCurrentNodeId('action32')
		_var_trace[String:new('traceId')] = _var_traceID
		
		-- NODE-ID: action33
		OtxDebug.setCurrentNodeId('action33')
		_var_trace[String:new('timestamp')] = DateTime.GetTimestamp()
		
		-- NODE-ID: action101
		OtxDebug.setCurrentNodeId('action101')
		_var_trace[String:new('request')] = _var_traceRequest:getCopy()
		
		-- NODE-ID: action35
		OtxDebug.setCurrentNodeId('action35')
		_var_trace[String:new('response')] = _var_traceResponse:getCopy()
		
		-- NODE-ID: action40
		OtxDebug.setCurrentNodeId('action40')
		_var_trace[String:new('serviceId')] = _var_traceServiceId
		
		-- NODE-ID: action66
		OtxDebug.setCurrentNodeId('action66')
		_var_trace[String:new('responseId')] = _var_traceResponseId
		
		-- NODE-ID: action67
		OtxDebug.setCurrentNodeId('action67')
		_var_ecuinout[String:new('trace')]:append({tdutil.CopyStructure(_var_trace)})
		
	end
	
	-- NODE-ID: return3
	OtxDebug.setCurrentNodeId('return3')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

function _prc_ReduceECUs(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_ECU_5FID = String:new('')
	local _var_VIT1 = ListType:new({}, {'list',{'map','OTXString','OTXString'}})
	local _var_VIT2 = ListType:new({}, {'list',{'map','OTXString','OTXString'}})
	
	-- in and inout parameters
	if (argumentsTable._var_ECU_5FID ~= nil) then _var_ECU_5FID = tdutil.checkParamType(argumentsTable._var_ECU_5FID, String:new('')) end
	if (argumentsTable._var_VIT1 ~= nil) then _var_VIT1 = tdutil.checkParamType(argumentsTable._var_VIT1, ListType:new({}, {'list',{'map','OTXString','OTXString'}})) end
	
	-- inout and out parameters
	getReturnTable = function() return {_var_VIT2=_var_VIT2} end
	
	-- procedure declarations
	local _var_i1 = 0
	local _var_ComParams = MapUtils.createMap({},{'map','OTXString','OTXString'})
	local _var_VITa = ListType:new({}, {'list',{'map','OTXString','OTXString'}})
	local _var_VITb = ListType:new({}, {'list',{'map','OTXString','OTXString'}})
	local _var_i2 = 0
	
	-- NODE-ID: action28
	OtxDebug.setCurrentNodeId('action28')
	_var_VITa = _var_VIT1
	
	-- NODE-ID: action22
	OtxDebug.setCurrentNodeId('action22')
	_var_VITb = _var_VIT1
	
	-- NODE-ID: branch3
	OtxDebug.setCurrentNodeId('branch3')
	if ((_var_ECU_5FID:len() > 0)) then
		-- NODE-ID: loop3
		OtxDebug.setCurrentNodeId('loop3')
		for _key in pairs(_var_VITa) do
			_var_i1 = _key
			
			-- NODE-ID: action34
			OtxDebug.setCurrentNodeId('action34')
			_var_ComParams = _var_VITa[_var_i1]
			
			-- NODE-ID: branch7
			OtxDebug.setCurrentNodeId('branch7')
			if ((Equals(_var_ComParams[String:new('memberLogicalLink')], _var_ECU_5FID))) then
			else
				-- NODE-ID: action24
				OtxDebug.setCurrentNodeId('action24')
				_var_i2 = _var_i1
				
				-- NODE-ID: action36
				OtxDebug.setCurrentNodeId('action36')
				_var_VITb:remove(_var_i2, 1)
				
			end
			
		end
		
	end
	
	-- NODE-ID: action23
	OtxDebug.setCurrentNodeId('action23')
	_var_VIT2 = _var_VITb
	
	-- NODE-ID: return4
	OtxDebug.setCurrentNodeId('return4')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

local _var_seq_result = OtxModule.defineMainAndExecute(_ENV, function()
	local mainArgs = {_var_ECU_5FID=String:new('')}
	local outArgTypes = {_var_scriptResult='Integer'}
	return tdutil.runMain(_prc_main, mainArgs, outArgTypes)
end)

return _var_seq_result
