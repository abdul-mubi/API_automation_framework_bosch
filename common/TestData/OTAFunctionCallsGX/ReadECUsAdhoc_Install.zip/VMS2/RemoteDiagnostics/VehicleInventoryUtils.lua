if (tdutil == nil) then
	-- Publisher version: 2.0.0.202004031512
	local common_paths_available = type(package.searchers[2]('RdaLualibPaths')) == "function"
	if (common_paths_available) then
		require('RdaLualibPaths')
	else
	end
	package.path = './_lib/?.lua;./_odx/?.lua;' .. package.path
	package.cpath = './_lib/?.dll;./_lib/?.so;' .. package.cpath
	
	local RDCOM_NAME = 'RDCOM'
	local common_rdcom_available = type(package.searchers[2](RDCOM_NAME)) == "function"
	if (not common_rdcom_available) then
		print("Note: Common RDCOM.lua not available, using explicit platform version as fallback")
		RDCOM_NAME = 'RDCOM_PLCS'
	end
	require('loadLibrary')
	require('TDLIB')
end

tdutil.registerOtxNamespaceModules({['http://iso.org/OTX/ProprietaryInterface/BackendCallback']='BackendCallback',['http://iso.org/OTX/1.0.0/DiagCom']='DiagCom',['http://iso.org/OTX/1.0.0/Flash']='Flash',['http://iso.org/OTX/1.0.0/StringUtil']='StringUtil',['http://iso.org/OTX/1.0.0/DateTime']='DateTime',['http://iso.org/OTX/1.0.0/Event']='EventHandling',['http://iso.org/OTX/1.0.0/Quantities']='Quantities',['http://iso.org/OTX/1.0.0/HMI']='HMI',['http://iso.org/OTX/1.0.0/DiagDataBrowsing']='DiagDataBrowsing',['http://iso.org/OTX/1.0.0/File']='File',['http://iso.org/OTX/1.0.0/FlashPlus']='FlashPlus',['http://iso.org/OTX/ProprietaryInterface/FaultCodeSetting']='FaultCodeSetting',['http://iso.org/OTX/ExtensionInterface/Inventory']='Inventory',['http://iso.org/OTX/ExtensionInterface/Persistence']='Persistency',['http://iso.org/OTX/ProprietaryInterface/RemoteMeasurement']='RemoteMeasurement',['http://www.bosch.com/OTX/GX_SECURITY']='Security',['http://gradex.bosch.com/OTX/1.0.0/Telediagnosis']='Tele',['http://iso.org/OTX/ProprietaryInterface/UnifiedReturnStructures']='UnifiedReturnStructures',['http://iso.org/OTX/ProprietaryInterface/VehicleProperties']='VehicleProperties'})

tdutil.loadOtxNamespaceModule({'http://iso.org/OTX/1.0.0/DataType'})

local _ENV  = OtxModule.declare('VMS2.RemoteDiagnostics', 'VehicleInventoryUtils', '0.14.0', _ENV)
OtxModule.setPublic('_prc_VehicleInventory', _ENV)
_prc_VehicleInventory = function() local s = {}  setmetatable(s, tdutil.StructureMT)  s['ecu'] = ListType:new({}, {'list','Structure'}) return s end
OtxModule.setPublic('_prc_TraceMessage', _ENV)
_prc_TraceMessage = function() local s = {}  setmetatable(s, tdutil.StructureMT)  s['traceId'] = 0 s['timestamp'] = 0 s['request'] = ByteFieldType:new() s['response'] = ByteFieldType:new() s['serviceId'] = String:new('') s['responseId'] = String:new('') return s end
OtxModule.setPublic('_prc_VehicleEcu', _ENV)
_prc_VehicleEcu = function() local s = {}  setmetatable(s, tdutil.StructureMT)  s['ecuAddress'] = 0 s['ecuId'] = String:new('') s['ecuVariantId'] = String:new('') s['name'] = String:new('') s['swVersion'] = _prc_Parameter() s['hwVersion'] = _prc_Parameter() s['serialNumber'] = _prc_Parameter() s['vendorId'] = _prc_Parameter() s['otherParameter'] = ListType:new({}, {'list','Structure'}) s['trace'] = ListType:new({}, {'list','Structure'}) s['timestamp'] = 0 return s end
OtxModule.setPublic('_prc_Parameter', _ENV)
_prc_Parameter = function() local s = {}  setmetatable(s, tdutil.StructureMT)  s['name'] = String:new('') s['traceRef'] = 0 s['path'] = String:new('') s['value'] = _prc_ScalarValue() s['unit'] = String:new('') s['internal_value'] = ByteFieldType:new() return s end
OtxModule.setPublic('_prc_ScalarValue', _ENV)
_prc_ScalarValue = function() local s = {}  setmetatable(s, tdutil.StructureMT)  s['valueType'] = _prc_ScalarValueType('BOOL') s['bool_value'] = false s['bytes_value'] = ByteFieldType:new() s['double_value'] = 0.0 s['int_value'] = 0 s['string_value'] = String:new('') return s end
OtxModule.setPublic('_prc_ScalarValueType', _ENV)
_prc_ScalarValueType = function(init) local e = {}  setmetatable(e, tdutil.EnumerationMT)  e['BOOL'] = {name='BOOL', value=0} e['BYTES'] = {name='BYTES', value=1} e['DOUBLE'] = {name='DOUBLE', value=2} e['INTEGER'] = {name='INTEGER', value=3} e['STRING'] = {name='STRING', value=4} if (init) then e.current = init end  return e end
OtxModule.setPublic('_prc_Snapshot', _ENV)
_prc_Snapshot = function() local s = {}  setmetatable(s, tdutil.StructureMT)  s['snapshotNumber'] = 0 s['traceRef'] = 0 s['parameter'] = ListType:new({}, {'list','Structure'}) return s end
OtxModule.setPublic('_prc_DTC', _ENV)
_prc_DTC = function() local s = {}  setmetatable(s, tdutil.StructureMT)  s['dtcId'] = 0 s['dtcIdDescription'] = String:new('') s['dtcStatus'] = 0 s['dtcStatusText'] = String:new('') s['milStatus'] = false s['snapshot'] = ListType:new({}, {'list','Structure'}) return s end
OtxModule.setPublic('_prc_EcuDTCs', _ENV)
_prc_EcuDTCs = function() local s = {}  setmetatable(s, tdutil.StructureMT)  s['ecuId'] = String:new('') s['traceRef'] = ListType:new({}, {'list','number'}) s['dtc'] = ListType:new({}, {'list','Structure'}) s['trace'] = ListType:new({}, {'list','Structure'}) return s end
OtxModule.setPublic('_prc_VehicleDTCs', _ENV)
_prc_VehicleDTCs = function() local s = {}  setmetatable(s, tdutil.StructureMT)  s['ecu'] = ListType:new({}, {'list','Structure'}) return s end

OtxModule.setPublic('_prc_main', _ENV)
function _prc_main(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- inout and out parameters
	getReturnTable = function() return {} end
	
	-- NODE-ID: return
	OtxDebug.setCurrentNodeId('return')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

local _var_seq_result = OtxModule.defineMainAndExecute(_ENV, function()
	local mainArgs = {}
	local outArgTypes = {}
	return tdutil.runMain(_prc_main, mainArgs, outArgTypes)
end)

return _var_seq_result
