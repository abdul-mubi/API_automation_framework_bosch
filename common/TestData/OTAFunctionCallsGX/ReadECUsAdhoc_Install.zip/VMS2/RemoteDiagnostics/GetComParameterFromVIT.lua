if (tdutil == nil) then
	-- Publisher version: 2.0.0.202004031512
	local common_paths_available = type(package.searchers[2]('RdaLualibPaths')) == "function"
	if (common_paths_available) then
		require('RdaLualibPaths')
	else
	end
	package.path = './_lib/?.lua;./_odx/?.lua;' .. package.path
	package.cpath = './_lib/?.dll;./_lib/?.so;' .. package.cpath
	
	local RDCOM_NAME = 'RDCOM'
	local common_rdcom_available = type(package.searchers[2](RDCOM_NAME)) == "function"
	if (not common_rdcom_available) then
		print("Note: Common RDCOM.lua not available, using explicit platform version as fallback")
		RDCOM_NAME = 'RDCOM_PLCS'
	end
	require('loadLibrary')
	require('TDLIB')
end

tdutil.registerOtxNamespaceModules({['http://iso.org/OTX/ProprietaryInterface/BackendCallback']='BackendCallback',['http://iso.org/OTX/1.0.0/DiagCom']='DiagCom',['http://iso.org/OTX/1.0.0/Flash']='Flash',['http://iso.org/OTX/1.0.0/StringUtil']='StringUtil',['http://iso.org/OTX/1.0.0/DateTime']='DateTime',['http://iso.org/OTX/1.0.0/Event']='EventHandling',['http://iso.org/OTX/1.0.0/Quantities']='Quantities',['http://iso.org/OTX/1.0.0/HMI']='HMI',['http://iso.org/OTX/1.0.0/DiagDataBrowsing']='DiagDataBrowsing',['http://iso.org/OTX/1.0.0/File']='File',['http://iso.org/OTX/1.0.0/FlashPlus']='FlashPlus',['http://iso.org/OTX/ProprietaryInterface/FaultCodeSetting']='FaultCodeSetting',['http://iso.org/OTX/ExtensionInterface/Inventory']='Inventory',['http://iso.org/OTX/ExtensionInterface/Persistence']='Persistency',['http://iso.org/OTX/ProprietaryInterface/RemoteMeasurement']='RemoteMeasurement',['http://www.bosch.com/OTX/GX_SECURITY']='Security',['http://gradex.bosch.com/OTX/1.0.0/Telediagnosis']='Tele',['http://iso.org/OTX/ProprietaryInterface/UnifiedReturnStructures']='UnifiedReturnStructures',['http://iso.org/OTX/ProprietaryInterface/VehicleProperties']='VehicleProperties'})

tdutil.loadOtxNamespaceModule({'http://iso.org/OTX/1.0.0/DiagCom','http://iso.org/OTX/1.0.0/File','http://iso.org/OTX/1.0.0/Logging','http://iso.org/OTX/1.0.0/StringUtil'})

local _ENV  = OtxModule.declare('VMS2.RemoteDiagnostics', 'GetComParameterFromVIT', '0.11.0', _ENV)
OtxModule.setPublic('_prc_main', _ENV)
function _prc_main(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_VITout = ListType:new({}, {'list',{'map','OTXString','OTXString'}})
	
	-- inout and out parameters
	getReturnTable = function() return {_var_VITout=_var_VITout} end
	
	-- procedure declarations
	local _var_ComParamsTable = ListType:new({}, {'list','OTXString'})
	local _var_VIT = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_line = String:new('')
	local _var_subLine1 = String:new('')
	local _var_subLine2 = String:new('')
	local _var_subLine3 = String:new('')
	local _var_LlShortName = String:new('')
	local _var_lineParameters = ListType:new({}, {'list','OTXString'})
	local _var_tmpParameterMap = MapUtils.createMap({},{'map','OTXString','OTXString'})
	local _var_i1 = 0
	local _var_tmpParameterList = ListType:new({}, {'list','OTXString'})
	local _var_ParameterList = ListType:new({}, {'list',{'map','OTXString','OTXString'}})
	local _var_i2 = 0
	local _var_comChannel = nil
	local _var_e1 = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	
	-- NODE-ID: group4
	OtxDebug.setCurrentNodeId('group4')
	do
		-- NODE-ID: action59
		OtxDebug.setCurrentNodeId('action59')
		_var_ComParamsTable = ListType:new({String:new('CP_RCByteOffset'),String:new('CP_SuspendQueueOnError'),String:new('CP_P3Phys'),String:new('CP_TesterPresentSendType'),String:new('CP_CanTransmissionTime'),String:new('CP_BlockSize'),String:new('CP_SyncJumpWidth'),String:new('CP_RC21RequestTime'),String:new('CP_CanBaudrateRecord'),String:new('CP_Loopback'),String:new('CP_TransmitIndEnable'),String:new('CP_CanFirstConsecutiveFrameValue'),String:new('CP_TesterPresentExpNegResp'),String:new('CP_TesterPresentAddrMode'),String:new('CP_CanDataSizeOffset'),String:new('CP_P2Max'),String:new('CP_TerminationType'),String:new('CP_RepeatReqCountApp'),String:new('CP_As'),String:new('CP_RC23RequestTime'),String:new('CP_Ar'),String:new('CP_CanFuncReqFormat'),String:new('CP_TesterPresentMessage'),String:new('CP_TesterPresentTime'),String:new('CP_BlockSizeOverride'),String:new('CP_CanMaxNumWaitFrames'),String:new('CP_RC78Handling'),String:new('CP_P2Min'),String:new('CP_StartMsgIndEnable'),String:new('CP_P2Star'),String:new('CP_ChangeSpeedResCtrl'),String:new('CP_ModifyTiming'),String:new('CP_TesterPresentHandling'),String:new('CP_RepeatReqCountTrans'),String:new('CP_ChangeSpeedTxDelay'),String:new('CP_RC21Handling'),String:new('CP_RC23CompletionTimeout'),String:new('CP_Bs'),String:new('CP_Br'),String:new('CP_ListenOnly'),String:new('CP_RC23Handling'),String:new('CP_CanFillerByteHandling'),String:new('CP_SendRemoteFrame'),String:new('CP_CanFuncReqExtAddr'),String:new('CP_RC78CompletionTimeout'),String:new('CP_TesterPresentReqRsp'),String:new('CP_StMinOverride'),String:new('CP_CyclicRespTimeout'),String:new('CP_SamplesPerBit'),String:new('CP_CanFillerByte'),String:new('CP_RequestAddrMode'),String:new('CP_EnablePerformanceTest'),String:new('CP_ChangeSpeedRate'),String:new('CP_P3Func'),String:new('CP_RC21CompletionTimeout'),String:new('CP_BitSamplePoint'),String:new('CP_Cr'),String:new('CP_ChangeSpeedCtrl'),String:new('CP_CanFuncReqId'),String:new('CP_Cs'),String:new('CP_StMin'),String:new('CP_Baudrate'),String:new('CP_ChangeSpeedMessage'),String:new('CP_SwCan_HighVoltage'),String:new('CP_TesterPresentExpPosResp'),String:new('CP_SessionTimingOverride'),String:new('CP_SessionTimingOverride_P2Star_High'),String:new('CP_SessionTimingOverride_SessionNumber'),String:new('CP_SessionTimingOverride_P2Max_High'),String:new('CP_SessionTimingOverride_P2Max_Low'),String:new('CP_SessionTimingOverride_P2Star_Low'),String:new('CP_CanRespUUDTFormat'),String:new('CP_CanRespUUDTId'),String:new('CP_ECULayerShortName'),String:new('CP_CanPhysReqId'),String:new('CP_CanRespUUDTExtAddr'),String:new('CP_CanRespUSDTId'),String:new('CP_CanRespUSDTExtAddr'),String:new('CP_CanPhysReqFormat'),String:new('CP_CanRespUSDTFormat'),String:new('CP_CanPhysReqExtAddr')},{'list','OTXString'})
		
		-- NODE-ID: action47
		OtxDebug.setCurrentNodeId('action47')
		writeLog(SeverityLevel.INFO, ToString(String:new('open file job://scripts/_odx/VIT.lua')))
		
		-- NODE-ID: action48
		OtxDebug.setCurrentNodeId('action48')
		_var_VIT = File.OpenFileForRead(StringEncodings.UTF_8, String:new('job://scripts/_odx/VIT.lua'))
		
		-- NODE-ID: handler6
		OtxDebug.setCurrentNodeId('handler6')
		OtxExceptions.handler(
			function() --try
					-- NODE-ID: loop11
					OtxDebug.setCurrentNodeId('loop11')
					while (true) do
						-- NODE-ID: action51
						OtxDebug.setCurrentNodeId('action51')
						_var_line = _var_VIT:readLine()
						
						-- NODE-ID: branch2
						OtxDebug.setCurrentNodeId('branch2')
						if ((StringUtil.IndexOf(_var_line, String:new('LogicalLinks.')) > 0)) then
							-- NODE-ID: action52
							OtxDebug.setCurrentNodeId('action52')
							_var_LlShortName = StringUtil.SubString(_var_line, (StringUtil.IndexOf(_var_line, String:new('VIT.LogicalLinks.')) + 17), (StringUtil.IndexOf(_var_line, String:new(' = ')) - 17))
							
							-- NODE-ID: action53
							OtxDebug.setCurrentNodeId('action53')
							writeLog(SeverityLevel.INFO, String:new('new Logical Link ').._var_LlShortName)
							
							-- NODE-ID: group5
							OtxDebug.setCurrentNodeId('group5')
							OtxDebug.logSpecification('normalize parameter line')
							do
								-- NODE-ID: action55
								OtxDebug.setCurrentNodeId('action55')
								_var_subLine1 = StringUtil.SubString(_var_line, (StringUtil.IndexOf(_var_line, String:new('{')) + 1), ((StringUtil.IndexOf(_var_line, String:new('CP_SessionTimingOverride=')) - 2) - StringUtil.IndexOf(_var_line, String:new('{'))))
								
								-- NODE-ID: action56
								OtxDebug.setCurrentNodeId('action56')
								_var_subLine2 = StringUtil.SubString(_var_line, StringUtil.IndexOf(_var_line, String:new('CP_SessionTimingOverride_P2Star_High')), ((StringUtil.IndexOf(_var_line, String:new('URID=')) - 2) - StringUtil.IndexOf(_var_line, String:new('CP_SessionTimingOverride_P2Star_High'))))
								
								-- NODE-ID: action54
								OtxDebug.setCurrentNodeId('action54')
								_var_subLine3 = StringUtil.SubString(_var_line, StringUtil.IndexOf(_var_line, String:new('CP_CanRespUUDTFormat=')), (StringUtil.IndexOf(_var_line, String:new('}}})')) - StringUtil.IndexOf(_var_line, String:new('CP_CanRespUUDTFormat='))))
								
								-- NODE-ID: action57
								OtxDebug.setCurrentNodeId('action57')
								_var_lineParameters = StringUtil.SplitString(_var_subLine1..String:new(',').._var_subLine2..String:new(',').._var_subLine3, String:new(','))
								
								-- NODE-ID: action58
								OtxDebug.setCurrentNodeId('action58')
								writeLog(SeverityLevel.INFO, _var_LlShortName..String:new(' contains ')..ToString(_var_lineParameters))
								
								-- NODE-ID: action9
								OtxDebug.setCurrentNodeId('action9')
								_var_tmpParameterMap = MapUtils.createMap({[String:new('memberLogicalLink')]=_var_LlShortName},{'map','OTXString','OTXString'})
								
								-- NODE-ID: action4
								-- DISABLED!
								
								-- NODE-ID: loop2
								OtxDebug.setCurrentNodeId('loop2')
								for _key in pairs(_var_lineParameters) do
									_var_i1 = _key
									
									-- NODE-ID: branch4
									OtxDebug.setCurrentNodeId('branch4')
									if ((StringUtil.IndexOf(_var_lineParameters[_var_i1], String:new('=')) > 0)) then
										-- NODE-ID: action5
										OtxDebug.setCurrentNodeId('action5')
										_var_tmpParameterList = StringUtil.SplitString(_var_lineParameters[_var_i1], String:new('='))
										
										-- NODE-ID: action7
										OtxDebug.setCurrentNodeId('action7')
										MapUtils.insertItems(_var_tmpParameterMap, {[_var_tmpParameterList[0]]=_var_tmpParameterList[1]})
										
									else
									end
									
								end
								
								-- NODE-ID: action8
								OtxDebug.setCurrentNodeId('action8')
								writeLog(SeverityLevel.INFO, _var_LlShortName..String:new(' contains ')..ToString(_var_tmpParameterMap))
								
								-- NODE-ID: action1
								OtxDebug.setCurrentNodeId('action1')
								_var_ParameterList:append({_var_tmpParameterMap})
								
							end
							
						else
						end
						
					end
					
			end, { --catch
				OtxExceptions.createCatch('OutOfBoundsException', 
					function(exception)
							-- NODE-ID: action50
							OtxDebug.setCurrentNodeId('action50')
							writeLog(SeverityLevel.INFO, ToString(String:new('end of file job://scripts/_odx/VIT.lua')))
							
							-- NODE-ID: action49
							OtxDebug.setCurrentNodeId('action49')
							_var_VIT:close()
							
					end
				),
				OtxExceptions.createCatch('Exception', 
					function(exception)
						_var_e1 = exception
						
					end
				),
			}, function() --finally
			end
		)
		
		-- NODE-ID: group1
		OtxDebug.setCurrentNodeId('group1')
		do
			-- NODE-ID: loop1
			OtxDebug.setCurrentNodeId('loop1')
			for _key in pairs(_var_ParameterList) do
				_var_i2 = _key
				
				-- NODE-ID: action2
				OtxDebug.setCurrentNodeId('action2')
				writeLog(SeverityLevel.INFO, ToString(_var_i2)..ToString(_var_ParameterList[_var_i2]))
				
			end
			
			-- NODE-ID: action14
			-- DISABLED!
			
			-- NODE-ID: action3
			OtxDebug.setCurrentNodeId('action3')
			DiagCom.CloseComChannel(_var_comChannel)
			
			-- NODE-ID: action6
			OtxDebug.setCurrentNodeId('action6')
			_var_VITout = _var_ParameterList
			
		end
		
	end
	
	-- NODE-ID: return
	OtxDebug.setCurrentNodeId('return')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

local _var_seq_result = OtxModule.defineMainAndExecute(_ENV, function()
	local mainArgs = {}
	local outArgTypes = {_var_VITout='List'}
	return tdutil.runMain(_prc_main, mainArgs, outArgTypes)
end)

return _var_seq_result
