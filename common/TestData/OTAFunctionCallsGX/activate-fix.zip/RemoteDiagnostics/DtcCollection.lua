if (tdutil == nil) then
	-- Publisher version: 1.4.0.201811210340
	local common_paths_available = type(package.searchers[2]('RdaLualibPaths')) == "function"
	if (common_paths_available) then
		require('RdaLualibPaths')
	else
	end
	package.path = './_lib/?.lua;./_odx/?.lua;' .. package.path
	package.cpath = './_lib/?.dll;./_lib/?.so;' .. package.cpath
	
	local RDCOM_NAME = 'RDCOM'
	local common_rdcom_available = type(package.searchers[2](RDCOM_NAME)) == "function"
	if (not common_rdcom_available) then
		print("Note: Common RDCOM.lua not available, using explicit platform version as fallback")
		RDCOM_NAME = 'RDCOM_PLCS'
	end
	require('loadLibrary')
	require('TDLIB')
end

tdutil.registerOtxNamespaceModules({['http://iso.org/OTX/1.0.0/DiagCom']='DiagCom',['http://iso.org/OTX/1.0.0/Flash']='Flash',['http://iso.org/OTX/1.0.0/StringUtil']='StringUtil',['http://iso.org/OTX/1.0.0/DateTime']='DateTime',['http://iso.org/OTX/1.0.0/Event']='EventHandling',['http://iso.org/OTX/1.0.0/Quantities']='Quantities',['http://iso.org/OTX/1.0.0/DiagDataBrowsing']='DiagDataBrowsing',['http://iso.org/OTX/ExtensionInterface/Inventory']='Inventory',['http://iso.org/OTX/ExtensionInterface/Persistence']='Persistency',['http://gradex.bosch.com/OTX/1.0.0/Telediagnosis']='Tele',['http://iso.org/OTX/ProprietaryInterface/UnifiedReturnStructures']='UnifiedReturnStructures',['http://iso.org/OTX/ProprietaryInterface/VehicleProperties']='VehicleProperties'})

tdutil.loadOtxNamespaceModule({'http://iso.org/OTX/1.0.0/DataType','http://iso.org/OTX/1.0.0/DateTime','http://iso.org/OTX/1.0.0/DiagCom','http://iso.org/OTX/1.0.0/StringUtil'})
tdutil.loadCustomerNamespaceModule({'http://iso.org/OTX/ProprietaryInterface/UnifiedReturnStructures'})

local _ENV  = OtxModule.declare('RemoteDiagnostics', 'DtcCollection', '0.52.0', _ENV)
_imp_doc_5FVehicleInventoryUtils = OtxModule.import('RemoteDiagnostics', 'VehicleInventoryUtils', _ENV, {major=0,minor=10,revision=0})

OtxModule.setPublic('_prc_main', _ENV)
function _prc_main(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_scriptResult = 0
	
	-- inout and out parameters
	getReturnTable = function() return {_var_scriptResult=_var_scriptResult} end
	
	-- procedure declarations
	local _var_ecu = _imp_doc_5FVehicleInventoryUtils._prc_EcuDTCs()
	local _var_trace = _imp_doc_5FVehicleInventoryUtils._prc_TraceMessage()
	local _var_dtcs = _imp_doc_5FVehicleInventoryUtils._prc_VehicleDTCs()
	local _var_comChannel = nil
	local _var_dtc = _imp_doc_5FVehicleInventoryUtils._prc_DTC()
	local _var_snapshot = _imp_doc_5FVehicleInventoryUtils._prc_Snapshot()
	local _var_traceSnapshot = _imp_doc_5FVehicleInventoryUtils._prc_TraceMessage()
	local _var_parameter = _imp_doc_5FVehicleInventoryUtils._prc_Parameter()
	local _var__5Fresult = nil
	local _var_ListOfDTC = ListType:new({}, {'list','ByteField'})
	local _var_i1 = 0
	local _var_dtcStatusByte = ByteFieldType:new()
	local _var__5Fresult2 = nil
	local _var_i2 = 0
	local _var_dtcIdBytes = ByteFieldType:new()
	local _var_traceNr = 0
	local _var_nrOfParameters = 0
	local _var_i3 = 0
	local _var_dtcStatusAvailabilityMask = 0
	local _var_listOfDtcAndStatus = ListType:new({}, {'list','ByteField'})
	local _var_dtcIdInt = 0
	local _var_dtcStatusInt = 0
	local _var_listOfSnapshots = ListType:new({}, {'list','ByteField'})
	
	-- NODE-ID: action52
	OtxDebug.setCurrentNodeId('action52')
	_var_dtcs[String:new('ecu')]:clear()
	
	-- NODE-ID: action51
	OtxDebug.setCurrentNodeId('action51')
	_var_ecu[String:new('traceRef')]:clear()
	
	-- NODE-ID: action53
	OtxDebug.setCurrentNodeId('action53')
	_var_ecu[String:new('trace')]:clear()
	
	-- NODE-ID: action5
	OtxDebug.setCurrentNodeId('action5')
	_var_comChannel = DiagCom.GetComChannel(String:new('UDSonCAN_Bosch'), nil, false)
	
	-- NODE-ID: action4
	OtxDebug.setCurrentNodeId('action4')
	_var_ecu[String:new('traceRef')]:append({0})
	
	-- NODE-ID: action13
	OtxDebug.setCurrentNodeId('action13')
	_var_trace[String:new('traceId')] = 0
	
	-- NODE-ID: action14
	OtxDebug.setCurrentNodeId('action14')
	_var_trace[String:new('timestamp')] = DateTime.GetTimestamp()
	
	-- NODE-ID: _macro1_action1
	OtxDebug.setCurrentNodeId('_macro1_action1')
	local _tmp_1
	_var__5Fresult, _tmp_1 = DiagCom.ExecuteDiagService(DiagCom.CreateDiagServiceByName(_var_comChannel, String:new('ReadDTCByStatusMask_19_02')), {[tostring(String:new('DTCStatusMask'))]=172}, {[String:new('PR_ReadDTCByStatusMask_19_02')]=function (r) _var_dtcStatusAvailabilityMask=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('DTCStatusAvailabilityMask')}})); _var_listOfDtcAndStatus=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('LIST_OF_DTC_AND_STATUS')}}));  end}, false, false)
	
	-- NODE-ID: action43
	OtxDebug.setCurrentNodeId('action43')
	_var_ecu[String:new('ecuId')] = ToString(DiagCom.GetComChannelIdentifierFromResponse(DiagCom.GetFirstResponse(_var__5Fresult)))
	
	-- NODE-ID: action15
	OtxDebug.setCurrentNodeId('action15')
	_var_trace[String:new('serviceId')] = String:new(DiagCom.GetDiagServiceFromResult(_var__5Fresult).name)
	
	-- NODE-ID: action16
	OtxDebug.setCurrentNodeId('action16')
	_var_trace[String:new('responseId')] = String:new(DiagCom.GetFirstResponse(_var__5Fresult).name)
	
	-- NODE-ID: action17
	OtxDebug.setCurrentNodeId('action17')
	_var_trace[String:new('request')] = ByteFieldType:new({25,2,255}):getCopy()
	
	-- NODE-ID: action18
	OtxDebug.setCurrentNodeId('action18')
	_var_trace[String:new('response')] = ByteFieldType:new(DiagCom.GetFirstResponse(_var__5Fresult).pdu):getCopy()
	
	-- NODE-ID: action42
	OtxDebug.setCurrentNodeId('action42')
	_var_ecu[String:new('trace')]:append({tdutil.CopyStructure(_var_trace)})
	
	-- NODE-ID: branch35
	OtxDebug.setCurrentNodeId('branch35')
	if (((Equals(_var__5Fresult:getState(), DiagCom.ResultState.ALL_POSITIVE)) or (Equals(_var__5Fresult:getState(), DiagCom.ResultState.POSITIVE)))) then
		-- NODE-ID: action208
		OtxDebug.setCurrentNodeId('action208')
		_var_ListOfDTC:clear()
		
		-- NODE-ID: action2
		OtxDebug.setCurrentNodeId('action2')
		_var_i1 = 3
		
		-- NODE-ID: action21
		OtxDebug.setCurrentNodeId('action21')
		_var_traceNr = 1
		
		-- NODE-ID: action50
		OtxDebug.setCurrentNodeId('action50')
		_var_ecu[String:new('dtc')]:clear()
		
		-- NODE-ID: loop1
		OtxDebug.setCurrentNodeId('loop1')
		while ((_var_i1 < #_var_trace[String:new('response')])) do
			-- NODE-ID: action46
			OtxDebug.setCurrentNodeId('action46')
			_var_dtcIdBytes = _var_trace[String:new('response')]:getSubByteField(_var_i1, 3):getCopy()
			
			-- NODE-ID: action10
			OtxDebug.setCurrentNodeId('action10')
			_var_i1 = (_var_i1 + 3)
			
			-- NODE-ID: action9
			OtxDebug.setCurrentNodeId('action9')
			_var_dtc[String:new('dtcId')] = OtxMath.ByteFieldToInteger('UNSIGNED', 'BIG-ENDIAN', _var_dtcIdBytes)
			
			-- NODE-ID: action11
			OtxDebug.setCurrentNodeId('action11')
			_var_dtcStatusByte = _var_trace[String:new('response')]:getSubByteField(_var_i1, 1):getCopy()
			
			-- NODE-ID: action6
			OtxDebug.setCurrentNodeId('action6')
			_var_i1 = (_var_i1 + 1)
			
			-- NODE-ID: action8
			OtxDebug.setCurrentNodeId('action8')
			_var_dtc[String:new('dtcStatus')] = OtxMath.ByteFieldToInteger('UNSIGNED', 'BIG-ENDIAN', _var_dtcStatusByte)
			
			-- NODE-ID: action3
			OtxDebug.setCurrentNodeId('action3')
			_var_dtc[String:new('milStatus')] = _var_dtcStatusByte:getBit(0, 7)
			
			-- NODE-ID: action34
			OtxDebug.setCurrentNodeId('action34')
			_var_traceSnapshot[String:new('traceId')] = _var_traceNr
			
			-- NODE-ID: action35
			OtxDebug.setCurrentNodeId('action35')
			_var_traceSnapshot[String:new('timestamp')] = DateTime.GetTimestamp()
			
	
		
			-- NODE-ID: action44
			OtxDebug.setCurrentNodeId('action44')
			_var_ecu[String:new('dtc')]:append({tdutil.CopyStructure(_var_dtc)})
			
		end
		
	end
	
	-- NODE-ID: action1
	OtxDebug.setCurrentNodeId('action1')
	_var_dtcs[String:new('ecu')]:append({tdutil.CopyStructure(_var_ecu)})
	
	-- NODE-ID: action12
	OtxDebug.setCurrentNodeId('action12')
	UnifiedReturnStructures.EnableDebug(true)
	UnifiedReturnStructures.SaveVehicleDTCs(_var_dtcs)
	
	-- NODE-ID: return
	OtxDebug.setCurrentNodeId('return')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

local _var_seq_result = OtxModule.defineMainAndExecute(_ENV, function()
	local mainArgs = {}
	local outArgTypes = {_var_scriptResult='Integer'}
	return tdutil.runMain(_prc_main, mainArgs, outArgTypes)
end)

return _var_seq_result
