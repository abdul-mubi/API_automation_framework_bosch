if (tdutil == nil) then
	-- Publisher version: 1.3.0.201708021402
	package.path = './_lib/?.lua;./_odx/?.lua;/data/encrypted/rda_app/LIBS/?.lua;' .. package.path
	package.cpath = './_lib/?.dll;./_lib/?.so;' .. package.cpath
	
	require('loadLibrary')
	require('TDLIB')
end

tdutil.registerOtxNamespaceModules({['http://iso.org/OTX/1.0.0/DiagCom']='DiagCom',['http://iso.org/OTX/1.0.0/Flash']='Flash',['http://iso.org/OTX/1.0.0/StringUtil']='StringUtil',['http://iso.org/OTX/1.0.0/DateTime']='DateTime',['http://iso.org/OTX/1.0.0/Event']='EventHandling',['http://iso.org/OTX/1.0.0/Quantities']='Quantities',['http://iso.org/OTX/1.0.0/DiagDataBrowsing']='DiagDataBrowsing',['http://iso.org/OTX/ProprietaryInterface/CanRecording']='canRaw',['http://gradex.bosch.com/OTX/1.0.0/Firewall']='Firewall',['http://iso.org/OTX/ExtensionInterface/Persistence']='Persistency',['http://gradex.bosch.com/OTX/1.0.0/Telediagnosis']='Tele',['http://iso.org/OTX/ProprietaryInterface/UnifiedReturnStructures']='UnifiedReturnStructures',['http://iso.org/OTX/ProprietaryInterface/VehicleProperties']='VehicleProperties'})

tdutil.loadOtxNamespaceModule({'http://iso.org/OTX/1.0.0/DiagCom','http://iso.org/OTX/1.0.0/Logging','http://iso.org/OTX/1.0.0/StringUtil'})

local _ENV  = OtxModule.declare('OtxLib', 'LibrariesSolutionDesign', '0.10.0', _ENV)
OtxModule.setPublic('_prc_ExceptionHandler', _ENV)
function _prc_ExceptionHandler(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_ServiceResponseByte = ByteFieldType:new({})
	local _var_ServiceResponseString = String:new(' ')
	
	-- in and inout parameters
	if (argumentsTable._var_ServiceResponseByte ~= nil) then _var_ServiceResponseByte = tdutil.checkParamType(argumentsTable._var_ServiceResponseByte, ByteFieldType:new({})) end
	if (argumentsTable._var_ServiceResponseString ~= nil) then _var_ServiceResponseString = tdutil.checkParamType(argumentsTable._var_ServiceResponseString, String:new(' ')) end
	
	-- inout and out parameters
	getReturnTable = function() return {} end
	
	-- procedure declarations
	local _var_UserException = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_SubField = ByteFieldType:new()
	
	-- NODE-ID: branch3
	OtxDebug.setCurrentNodeId('branch3')
	if (((_var_ServiceResponseString:len() > 0) and not ((Equals(_var_ServiceResponseString, String:new(' ')))))) then
		-- NODE-ID: action169
		OtxDebug.setCurrentNodeId('action169')
		_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), _var_ServiceResponseString)
		
		-- NODE-ID: throw1
		OtxDebug.setCurrentNodeId('throw1')
		OtxExceptions.throw(_var_UserException)
		
	elseif (((#_var_ServiceResponseByte > 0) and (Equals(_var_ServiceResponseByte:getSubByteField(0, 1), ByteFieldType:new({127}))))) then
		-- NODE-ID: action173
		OtxDebug.setCurrentNodeId('action173')
		_var_SubField = _var_ServiceResponseByte:getSubByteField((#_var_ServiceResponseByte - 1), 1):getCopy()
		
		-- NODE-ID: branch4
		OtxDebug.setCurrentNodeId('branch4')
		if ((Equals(_var_SubField, ByteFieldType:new({16})))) then
			-- NODE-ID: action174
			OtxDebug.setCurrentNodeId('action174')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   General Reject'))
			
			-- NODE-ID: throw3
			OtxDebug.setCurrentNodeId('throw3')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({17})))) then
			-- NODE-ID: action175
			OtxDebug.setCurrentNodeId('action175')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Service not supported'))
			
			-- NODE-ID: throw4
			OtxDebug.setCurrentNodeId('throw4')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({18})))) then
			-- NODE-ID: action176
			OtxDebug.setCurrentNodeId('action176')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Subfunction not supported - invalid format'))
			
			-- NODE-ID: throw5
			OtxDebug.setCurrentNodeId('throw5')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({33})))) then
			-- NODE-ID: action178
			OtxDebug.setCurrentNodeId('action178')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Busy - repeat request'))
			
			-- NODE-ID: throw6
			OtxDebug.setCurrentNodeId('throw6')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({34})))) then
			-- NODE-ID: action184
			OtxDebug.setCurrentNodeId('action184')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Conditions not correct or request sequence error'))
			
			-- NODE-ID: throw8
			OtxDebug.setCurrentNodeId('throw8')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({35})))) then
			-- NODE-ID: action185
			OtxDebug.setCurrentNodeId('action185')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Request correctly received - response pending 0x23'))
			
			-- NODE-ID: throw9
			OtxDebug.setCurrentNodeId('throw9')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({49})))) then
			-- NODE-ID: action186
			OtxDebug.setCurrentNodeId('action186')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Request out of range'))
			
			-- NODE-ID: throw10
			OtxDebug.setCurrentNodeId('throw10')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({51})))) then
			-- NODE-ID: action187
			OtxDebug.setCurrentNodeId('action187')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Security access denied - security access requested'))
			
			-- NODE-ID: throw11
			OtxDebug.setCurrentNodeId('throw11')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({53})))) then
			-- NODE-ID: action189
			OtxDebug.setCurrentNodeId('action189')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Invalid key'))
			
			-- NODE-ID: throw13
			OtxDebug.setCurrentNodeId('throw13')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({54})))) then
			-- NODE-ID: action190
			OtxDebug.setCurrentNodeId('action190')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Exceed number of attempts'))
			
			-- NODE-ID: throw14
			OtxDebug.setCurrentNodeId('throw14')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({55})))) then
			-- NODE-ID: action192
			OtxDebug.setCurrentNodeId('action192')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Required time delay not expired'))
			
			-- NODE-ID: throw15
			OtxDebug.setCurrentNodeId('throw15')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({64})))) then
			-- NODE-ID: action193
			OtxDebug.setCurrentNodeId('action193')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Download not accepted'))
			
			-- NODE-ID: throw16
			OtxDebug.setCurrentNodeId('throw16')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({80})))) then
			-- NODE-ID: action194
			OtxDebug.setCurrentNodeId('action194')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Upload not accepted'))
			
			-- NODE-ID: throw17
			OtxDebug.setCurrentNodeId('throw17')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({113})))) then
			-- NODE-ID: action195
			OtxDebug.setCurrentNodeId('action195')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Transfer suspended'))
			
			-- NODE-ID: throw18
			OtxDebug.setCurrentNodeId('throw18')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({120})))) then
			-- NODE-ID: action197
			OtxDebug.setCurrentNodeId('action197')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Request correctly received - response pending'))
			
			-- NODE-ID: throw19
			OtxDebug.setCurrentNodeId('throw19')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({128})))) then
			-- NODE-ID: action201
			OtxDebug.setCurrentNodeId('action201')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Service not supported in active diagnostic session'))
			
			-- NODE-ID: throw20
			OtxDebug.setCurrentNodeId('throw20')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({251})))) then
			-- NODE-ID: action202
			OtxDebug.setCurrentNodeId('action202')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Request correctly received - response pending 0xFB'))
			
			-- NODE-ID: throw21
			OtxDebug.setCurrentNodeId('throw21')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({136})))) then
			-- NODE-ID: action1
			OtxDebug.setCurrentNodeId('action1')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Vehicle speed is too high'))
			
			-- NODE-ID: throw2
			OtxDebug.setCurrentNodeId('throw2')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({146})))) then
			-- NODE-ID: action2
			OtxDebug.setCurrentNodeId('action2')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Voltage is too high'))
			
			-- NODE-ID: throw7
			OtxDebug.setCurrentNodeId('throw7')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({147})))) then
			-- NODE-ID: action3
			OtxDebug.setCurrentNodeId('action3')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Voltage is too low'))
			
			-- NODE-ID: throw12
			OtxDebug.setCurrentNodeId('throw12')
			OtxExceptions.throw(_var_UserException)
			
		else
			-- NODE-ID: action207
			OtxDebug.setCurrentNodeId('action207')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:  ')..StringUtil.Decode('HEX', _var_ServiceResponseByte))
			
			-- NODE-ID: throw22
			OtxDebug.setCurrentNodeId('throw22')
			OtxExceptions.throw(_var_UserException)
			
		end
		
	end
	
	-- NODE-ID: return12
	OtxDebug.setCurrentNodeId('return12')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

OtxModule.setPublic('_prc_ExecuteAndDecodeHexServices', _ENV)
function _prc_ExecuteAndDecodeHexServices(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_ComChannel1 = nil
	local _var_Input = ListType:new({}, {'list','ByteField'})
	local _var_Encoding1 = 'US-ASCII'
	local _var_Output = ListType:new({}, {'list','OTXString'})
	
	-- in and inout parameters
	if (argumentsTable._var_ComChannel1 ~= nil) then _var_ComChannel1 = tdutil.checkParamType(argumentsTable._var_ComChannel1, nil) end
	if (argumentsTable._var_Input ~= nil) then _var_Input = tdutil.checkParamType(argumentsTable._var_Input, ListType:new({}, {'list','ByteField'})) end
	if (argumentsTable._var_Encoding1 ~= nil) then _var_Encoding1 = tdutil.checkParamType(argumentsTable._var_Encoding1, 'US-ASCII') end
	
	-- inout and out parameters
	getReturnTable = function() return {_var_Output=_var_Output} end
	
	-- procedure declarations
	local _var_counter = 0
	local _var_response = ByteFieldType:new()
	
	-- NODE-ID: loop2
	OtxDebug.setCurrentNodeId('loop2')
	for _key in pairs(_var_Input) do
		_var_counter = _key
		
		-- NODE-ID: action22
		OtxDebug.setCurrentNodeId('action22')
		_var_response = DiagCom.ExecuteHexDiagService(_var_ComChannel1, _var_Input[_var_counter])
		
		-- NODE-ID: action23
		OtxDebug.setCurrentNodeId('action23')
		_var_Output[_var_counter] = StringUtil.Decode(_var_Encoding1, _var_response:getSubByteField(2, (#_var_response - 2)))
		
	end
	
	-- NODE-ID: return2
	OtxDebug.setCurrentNodeId('return2')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

OtxModule.setPublic('_prc_Logging', _ENV)
function _prc_Logging(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_SeverityLevel1 = SeverityLevel.INFO
	local _var_FileName = String:new('')
	local _var_LogInput = ListType:new({}, {'list','OTXString'})
	
	-- in and inout parameters
	if (argumentsTable._var_SeverityLevel1 ~= nil) then _var_SeverityLevel1 = tdutil.checkParamType(argumentsTable._var_SeverityLevel1, SeverityLevel.INFO) end
	if (argumentsTable._var_FileName ~= nil) then _var_FileName = tdutil.checkParamType(argumentsTable._var_FileName, String:new('')) end
	if (argumentsTable._var_LogInput ~= nil) then _var_LogInput = tdutil.checkParamType(argumentsTable._var_LogInput, ListType:new({}, {'list','OTXString'})) end
	
	-- inout and out parameters
	getReturnTable = function() return {} end
	
	-- procedure declarations
	local _var_counter = 0
	
	-- NODE-ID: loop1
	OtxDebug.setCurrentNodeId('loop1')
	for _key in pairs(_var_LogInput) do
		_var_counter = _key
		
		-- NODE-ID: action21
		OtxDebug.setCurrentNodeId('action21')
		writeDomainLog(_var_FileName, _var_SeverityLevel1, _var_LogInput[_var_counter])
		
	end
	
	-- NODE-ID: return1
	OtxDebug.setCurrentNodeId('return1')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

OtxModule.setPublic('_prc_screensupport', _ENV)
function _prc_screensupport(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_ScreenValue = String:new('')
	local _var_ID = String:new('')
	local _var_Value = String:new('')
	local _var_oldValue = String:new('')
	
	-- in and inout parameters
	if (argumentsTable._var_ScreenValue ~= nil) then _var_ScreenValue = tdutil.checkParamType(argumentsTable._var_ScreenValue, String:new('')) end
	
	-- inout and out parameters
	getReturnTable = function() return {_var_ID=_var_ID, _var_Value=_var_Value, _var_oldValue=_var_oldValue} end
	
	-- procedure declarations
	local _var_StringSeperation = ListType:new({}, {'list','OTXString'})
	
	-- NODE-ID: action24
	OtxDebug.setCurrentNodeId('action24')
	_var_StringSeperation = StringUtil.SplitString(_var_ScreenValue, String:new('@;@'))
	
	-- NODE-ID: handler1
	OtxDebug.setCurrentNodeId('handler1')
	OtxExceptions.handler(
		function() --try
				-- NODE-ID: action25
				OtxDebug.setCurrentNodeId('action25')
				_var_ID = _var_StringSeperation[0]
				
		end, { --catch
			OtxExceptions.createCatch('Exception', 
				function(exception)
				end
			),
		}, function() --finally
		end
	)
	
	-- NODE-ID: handler2
	OtxDebug.setCurrentNodeId('handler2')
	OtxExceptions.handler(
		function() --try
				-- NODE-ID: action26
				OtxDebug.setCurrentNodeId('action26')
				_var_Value = _var_StringSeperation[1]
				
		end, { --catch
			OtxExceptions.createCatch('Exception', 
				function(exception)
				end
			),
		}, function() --finally
		end
	)
	
	-- NODE-ID: handler3
	OtxDebug.setCurrentNodeId('handler3')
	OtxExceptions.handler(
		function() --try
				-- NODE-ID: action27
				OtxDebug.setCurrentNodeId('action27')
				_var_oldValue = _var_StringSeperation[2]
				
		end, { --catch
			OtxExceptions.createCatch('Exception', 
				function(exception)
				end
			),
		}, function() --finally
		end
	)
	
	-- NODE-ID: return3
	OtxDebug.setCurrentNodeId('return3')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

local _var_seq_result = nil
return _var_seq_result
