if (tdutil == nil) then
	-- Publisher version: 1.3.0.201708021402
	package.path = './_lib/?.lua;./_odx/?.lua;/data/encrypted/rda_app/LIBS/?.lua;' .. package.path
	package.cpath = './_lib/?.dll;./_lib/?.so;' .. package.cpath
	
	require('loadLibrary')
	require('TDLIB')
end

tdutil.registerOtxNamespaceModules({['http://iso.org/OTX/1.0.0/DiagCom']='DiagCom',['http://iso.org/OTX/1.0.0/Flash']='Flash',['http://iso.org/OTX/1.0.0/StringUtil']='StringUtil',['http://iso.org/OTX/1.0.0/DateTime']='DateTime',['http://iso.org/OTX/1.0.0/Event']='EventHandling',['http://iso.org/OTX/1.0.0/Quantities']='Quantities',['http://iso.org/OTX/1.0.0/DiagDataBrowsing']='DiagDataBrowsing',['http://iso.org/OTX/ProprietaryInterface/CanRecording']='canRaw',['http://gradex.bosch.com/OTX/1.0.0/Firewall']='Firewall',['http://iso.org/OTX/ExtensionInterface/Persistence']='Persistency',['http://gradex.bosch.com/OTX/1.0.0/Telediagnosis']='Tele',['http://iso.org/OTX/ProprietaryInterface/UnifiedReturnStructures']='UnifiedReturnStructures',['http://iso.org/OTX/ProprietaryInterface/VehicleProperties']='VehicleProperties'})

tdutil.loadOtxNamespaceModule({'http://iso.org/OTX/1.0.0/DateTime','http://iso.org/OTX/1.0.0/DiagCom','http://iso.org/OTX/1.0.0/Flash','http://iso.org/OTX/1.0.0/Logging','http://iso.org/OTX/1.0.0/Quantities','http://iso.org/OTX/1.0.0/StringUtil'})
tdutil.loadCustomerNamespaceModule({'http://iso.org/OTX/ProprietaryInterface/CanRecording','http://www.spx.com/OTX/1.0.0/GRADEX','http://iso.org/OTX/ExtensionInterface/Persistence','http://gradex.bosch.com/OTX/1.0.0/Telediagnosis'})

local _ENV  = OtxModule.declare('Procedures', 'Flash_Telematik_CC', '0.426.0', _ENV)
_var_memAddr = 0
_var_memSize = 0
_var_downloadedSize = 0
_var_step = String:new('')
_var_LogName = String:new('')
_var_Status = ByteFieldType:new()
_var_totaldownloadedSize = 0
_var_BoxVersionSendChannel = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
_var_Request = ByteFieldType:new()
_var_Response = ByteFieldType:new()
_imp_doc_5FLibrariesSolutionDesign = OtxModule.import('OtxLib', 'LibrariesSolutionDesign', _ENV, {major=0,minor=10,revision=0})

OtxModule.setPublic('_prc_main', _ENV)
function _prc_main(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_Fingerprint = ByteFieldType:new({1,2,3,4,5})
	local _var_triggerName = String:new('')
	local _var_scriptResult = 1
	local _var_newSoftwareVersion = ByteFieldType:new({1,1})
	
	-- in and inout parameters
	if (argumentsTable._var_Fingerprint ~= nil) then _var_Fingerprint = tdutil.checkParamType(argumentsTable._var_Fingerprint, ByteFieldType:new({1,2,3,4,5})) end
	if (argumentsTable._var_triggerName ~= nil) then _var_triggerName = tdutil.checkParamType(argumentsTable._var_triggerName, String:new('')) end
	if (argumentsTable._var_scriptResult ~= nil) then _var_scriptResult = tdutil.checkParamType(argumentsTable._var_scriptResult, 1) end
	if (argumentsTable._var_newSoftwareVersion ~= nil) then _var_newSoftwareVersion = tdutil.checkParamType(argumentsTable._var_newSoftwareVersion, ByteFieldType:new({1,1})) end
	
	-- inout and out parameters
	getReturnTable = function() return {_var_scriptResult=_var_scriptResult, _var_newSoftwareVersion=_var_newSoftwareVersion} end
	
	-- procedure declarations
	local _var_ComChannel = nil
	local _var_Exception = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_FlashSession = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_time_5Fstart = 0
	local _var_q1 = Quantities.Quantity:new()
	local _var_q2 = Quantities.Quantity:new()
	local _var_EcuID = ByteFieldType:new({1,2,3,4})
	local _var_SoftwareID = ByteFieldType:new({0,1})
	
	-- NODE-ID: handler1
	OtxDebug.setCurrentNodeId('handler1')
	OtxExceptions.handler(
		function() --try
				-- NODE-ID: group9
				OtxDebug.setCurrentNodeId('group9')
				OtxDebug.logSpecification('Adapt')
				do
					-- NODE-ID: action114
					OtxDebug.setCurrentNodeId('action114')
					_var_scriptResult = 1
					
					-- NODE-ID: action99
					OtxDebug.setCurrentNodeId('action99')
					_var_LogName = String:new('reflash')
					
					-- NODE-ID: action2
					OtxDebug.setCurrentNodeId('action2')
					_var_ComChannel = DiagCom.GetComChannel(String:new('CC_UDSonCAN'), nil, false)
					
					-- NODE-ID: action83
					OtxDebug.setCurrentNodeId('action83')
					--DiagCom.SetComParameter(_var_ComChannel, String:new('CP_UseRemoteChannel'), String:new('true'))					
					
				end
				
				-- NODE-ID: action9
				OtxDebug.setCurrentNodeId('action9')
				OtxDebug.addStackLevel('CheckValidSessions')
				local _tmp_returnTable1
				_tmp_returnTable1 = _prc_CheckValidSessions({_var_ComChannel = _var_ComChannel})
				OtxDebug.decrementStackLevel()
				if (_tmp_returnTable1 ~= nil) then
					_var_FlashSession = _tmp_returnTable1._var_FlashSession
				end
				
				-- NODE-ID: group11
				OtxDebug.setCurrentNodeId('group11')
				OtxDebug.logSpecification('Logging \\n ')
				do
					-- NODE-ID: action101
					OtxDebug.setCurrentNodeId('action101')
					writeDomainLog(_var_LogName, SeverityLevel.INFO, String:new('ECU: ')..DiagCom.GetComChannelEcuVariantName(_var_ComChannel))
					
					-- NODE-ID: action102
					OtxDebug.setCurrentNodeId('action102')
					writeDomainLog(_var_LogName, SeverityLevel.INFO, String:new('ECU condition before reflash: '))
					
				end
				
				-- NODE-ID: action146
				OtxDebug.setCurrentNodeId('action146')
				_var_time_5Fstart = DateTime.GetTimestamp()
				
				-- NODE-ID: action93
				OtxDebug.setCurrentNodeId('action93')
				OtxDebug.addStackLevel('PreFlash')
				local _tmp_returnTable2
				_tmp_returnTable2 = _prc_PreFlash({_var_ComChannel = _var_ComChannel, _var_Fingerprint = _var_Fingerprint})
				OtxDebug.decrementStackLevel()
				
				-- NODE-ID: action3
				OtxDebug.setCurrentNodeId('action3')
				OtxDebug.addStackLevel('flashBlocks')
				local _tmp_returnTable3
				_tmp_returnTable3 = _prc_flashBlocks({_var_channel = _var_ComChannel, _var_flashSession = _var_FlashSession})
				OtxDebug.decrementStackLevel()
				
				-- NODE-ID: action123
				OtxDebug.setCurrentNodeId('action123')
				OtxDebug.addStackLevel('PostFlash')
				local _tmp_returnTable4
				_tmp_returnTable4 = _prc_PostFlash({_var_ComChannel = _var_ComChannel})
				OtxDebug.decrementStackLevel()
				
				-- NODE-ID: group12
				OtxDebug.setCurrentNodeId('group12')
				OtxDebug.logSpecification('Logging \\n ')
				do
					-- NODE-ID: action77
					OtxDebug.setCurrentNodeId('action77')
					writeDomainLog(_var_LogName, SeverityLevel.INFO, String:new('Flashduration [mm:ss]: ')..DateTime.FormatDuration((DateTime.GetTimestamp() - _var_time_5Fstart), String:new('mm:ss')))
					
					-- NODE-ID: action105
					OtxDebug.setCurrentNodeId('action105')
					writeDomainLog(_var_LogName, SeverityLevel.INFO, String:new('ECU condition after reflash: '))

					
					-- NODE-ID: action201
					OtxDebug.setCurrentNodeId('action201')
					Persistency.Save('_var_EcuID', _var_EcuID)
					
					-- NODE-ID: action203
					OtxDebug.setCurrentNodeId('action203')
					_var_SoftwareID = _var_newSoftwareVersion:getCopy()
					
					-- NODE-ID: action202
					OtxDebug.setCurrentNodeId('action202')
					Persistency.Save('_var_SoftwareID', _var_SoftwareID)
					
					-- NODE-ID: action37
					OtxDebug.setCurrentNodeId('action37')
					_var_scriptResult = 0
					
				end
				
		end, { --catch
			OtxExceptions.createCatch('Exception', 
				function(exception)
					_var_Exception = exception
					
						-- NODE-ID: action107
						OtxDebug.setCurrentNodeId('action107')
						DiagCom.CloseComChannel(_var_ComChannel)
						
						-- NODE-ID: action126
						OtxDebug.setCurrentNodeId('action126')
						writeDomainLog(_var_LogName, SeverityLevel.INFO, String:new('Flash failed')..String:new(' - ')..String:new('   Exception Type: ').._var_Exception.qualifier..String:new('   Exception Text: ').._var_Exception.text)
						
				end
			),
		}, function() --finally
		end
	)
	
	-- NODE-ID: return
	OtxDebug.setCurrentNodeId('return')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

function _prc_PreFlash(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_ComChannel = nil
	local _var_Fingerprint = ByteFieldType:new()
	
	-- in and inout parameters
	if (argumentsTable._var_ComChannel ~= nil) then _var_ComChannel = tdutil.checkParamType(argumentsTable._var_ComChannel, nil) end
	if (argumentsTable._var_Fingerprint ~= nil) then _var_Fingerprint = tdutil.checkParamType(argumentsTable._var_Fingerprint, ByteFieldType:new()) end
	
	-- inout and out parameters
	getReturnTable = function() return {} end
	
	-- procedure declarations
	local _var_exception = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_userException = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_Request = ByteFieldType:new()
	local _var_Response = ByteFieldType:new()
	local _var_securityPassed = true
	local _var_P2 = Quantities.Quantity:new()
	local _var_P2Ex = Quantities.Quantity:new()
	local _var_Result1 = nil
	local _var_ResultState1 = DiagCom.ResultState.ALL_FAILED
	
	-- NODE-ID: action116
	OtxDebug.setCurrentNodeId('action116')
	setLogLevel(LogLevel.ALL)
	
	-- NODE-ID: handler7
	OtxDebug.setCurrentNodeId('handler7')
	OtxExceptions.handler(
		function() --try
				-- NODE-ID: group10
				OtxDebug.setCurrentNodeId('group10')
				OtxDebug.logSpecification('Implement all pre-flash services')
				do
					-- NODE-ID: group8
					OtxDebug.setCurrentNodeId('group8')
					OtxDebug.logSpecification('Diagnostic Session Control \\n ')
					do
						-- NODE-ID: group17
						OtxDebug.setCurrentNodeId('group17')
						OtxDebug.logSpecification('odx')
						do
							-- NODE-ID: macro1
							-- DISABLED!
							
							-- NODE-ID: action175
							OtxDebug.setCurrentNodeId('action175')
							_var_Response = ByteFieldType:new({0}):getCopy()
							
							-- NODE-ID: action185
							OtxDebug.setCurrentNodeId('action185')
							_var_Request = ByteFieldType:new({16,2}):getCopy()
							
							-- NODE-ID: action186
							OtxDebug.setCurrentNodeId('action186')
							_var_Response = DiagCom.ExecuteHexDiagService(_var_ComChannel, _var_Request)
							
							-- NODE-ID: macro2
							OtxDebug.setCurrentNodeId('macro2')
							do
								-- NODE-ID: _macro2_action1
								OtxDebug.setCurrentNodeId('_macro2_action1')
								local _tmp_1
								_tmp_1, _var_ResultState1 = DiagCom.ExecuteDiagService(DiagCom.CreateDiagServiceByName(DiagCom.GetComChannel(String:new('CC_UDSonCAN'), nil, false), String:new('ProgrammingSession_Start')), {}, {[String:new('PR_ProgrammingSession_Start')]=function (r) _var_P2=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('P2')}})); _var_P2Ex=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('P2Ex')}}));  end}, false, false)
								
								-- NODE-ID: branch7
								OtxDebug.setCurrentNodeId('branch7')
								if (((Equals(_var_ResultState1, DiagCom.ResultState.ALL_POSITIVE)) or (Equals(_var_ResultState1, DiagCom.ResultState.POSITIVE)))) then
									-- NODE-ID: action153
									OtxDebug.setCurrentNodeId('action153')
									writeLog(SeverityLevel.FATAL, ToString(_var_ResultState1))
									
								else
									-- NODE-ID: throw35
									OtxDebug.setCurrentNodeId('throw35')
									OtxExceptions.throw(OtxExceptions.createException('UserException', String:new('Procedure: Pre-Flash'), _var_exception.text))
									
								end
								
							end
							
						end
						
						-- NODE-ID: group18
						-- DISABLED!
						
					end
					
				end
				
				-- NODE-ID: action96
				OtxDebug.setCurrentNodeId('action96')
				OtxDebug.addStackLevel('SecurityAccess')
				local _tmp_returnTable5
				_tmp_returnTable5 = _prc_SecurityAccess({_var_ComChannel = _var_ComChannel})
				OtxDebug.decrementStackLevel()
				if (_tmp_returnTable5 ~= nil) then
					_var_securityPassed = _tmp_returnTable5._var_SecurityPassed
				end
				
				-- NODE-ID: branch2
				OtxDebug.setCurrentNodeId('branch2')
				if (_var_securityPassed) then
					-- NODE-ID: group15
					OtxDebug.setCurrentNodeId('group15')
					OtxDebug.logSpecification('Fingerprint')
					do
						-- NODE-ID: action92
						OtxDebug.setCurrentNodeId('action92')
						_var_Response = ByteFieldType:new({0}):getCopy()
						
						-- NODE-ID: action112
						OtxDebug.setCurrentNodeId('action112')
						_var_Request = ByteFieldType:new({46,241,90}):getCopy()
						
						-- NODE-ID: action120
						OtxDebug.setCurrentNodeId('action120')
						_var_Request:append(_var_Fingerprint)
						
						-- NODE-ID: action113
						OtxDebug.setCurrentNodeId('action113')
						_var_Response = DiagCom.ExecuteHexDiagService(_var_ComChannel, _var_Request)
						
					end
					
				else
					-- NODE-ID: throw33
					OtxDebug.setCurrentNodeId('throw33')
					OtxExceptions.throw(_var_userException)
					
				end
				
		end, { --catch
			OtxExceptions.createCatch('UserException', 
				function(exception)
					_var_exception = exception
					
						-- NODE-ID: action11
						OtxDebug.setCurrentNodeId('action11')
						_var_userException = OtxExceptions.createException('UserException', String:new('Procedure: Pre-Flash'), String:new('Exception Type: ').._var_exception.qualifier..String:new('   Exception Text: ').._var_exception.text)
												
						-- NODE-ID: throw34
						OtxDebug.setCurrentNodeId('throw34')
						OtxExceptions.throw()
						
				end
			),
			OtxExceptions.createCatch('LossOfComException', 
				function(exception)
						-- NODE-ID: action154
						OtxDebug.setCurrentNodeId('action154')
						writeLog(SeverityLevel.FATAL, ToString(_var_ResultState1))
						
						-- NODE-ID: throw8
						OtxDebug.setCurrentNodeId('throw8')
						OtxExceptions.throw()
						
				end
			),
			OtxExceptions.createCatch('Exception', 
				function(exception)
						-- NODE-ID: throw7
						OtxDebug.setCurrentNodeId('throw7')
						OtxExceptions.throw(OtxExceptions.createException('UserException', String:new('Procedure: Pre-Flash'), _var_exception.text))
						
				end
			),
		}, function() --finally
		end
	)
	
	-- NODE-ID: return1
	OtxDebug.setCurrentNodeId('return1')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

function _prc_PostFlash(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_ComChannel = nil
	
	-- in and inout parameters
	if (argumentsTable._var_ComChannel ~= nil) then _var_ComChannel = tdutil.checkParamType(argumentsTable._var_ComChannel, nil) end
	
	-- inout and out parameters
	getReturnTable = function() return {} end
	
	-- procedure declarations
	local _var_exception = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_Request = ByteFieldType:new()
	local _var_Response = ByteFieldType:new()
	local _var_q1 = Quantities.Quantity:new()
	local _var_q2 = Quantities.Quantity:new()
	local _var_i1 = 0
	
	-- NODE-ID: handler9
	OtxDebug.setCurrentNodeId('handler9')
	OtxExceptions.handler(
		function() --try
				-- NODE-ID: group13
				OtxDebug.setCurrentNodeId('group13')
				OtxDebug.logSpecification('Implement all post-flash services')
				do
					-- NODE-ID: group23
					OtxDebug.setCurrentNodeId('group23')
					OtxDebug.logSpecification('Standard Diagnostic Session')
					do
						-- NODE-ID: action177
						OtxDebug.setCurrentNodeId('action177')
						Tele.Sleep(500)
						_var_i1 = 0
						
						-- NODE-ID: action106
						OtxDebug.setCurrentNodeId('action106')
						_var_Response = ByteFieldType:new({0}):getCopy()
						
						-- NODE-ID: action124
						OtxDebug.setCurrentNodeId('action124')
						_var_Request = ByteFieldType:new({16,1}):getCopy()
						
						-- NODE-ID: action125
						OtxDebug.setCurrentNodeId('action125')
						_var_Response = DiagCom.ExecuteHexDiagService(_var_ComChannel, _var_Request)
						
					end
					
				end
				
		end, { --catch
			OtxExceptions.createCatch('LossOfComException', 
				function(exception)
					_var_exception = exception
					
						-- NODE-ID: action187
						OtxDebug.setCurrentNodeId('action187')
						DiagCom.ExecuteDiagService(DiagCom.CreateDiagServiceByName(DiagCom.GetComChannel(String:new('CC_UDSonCAN'), nil, false), String:new('DefaultSession_Start')), {}, {[String:new('PR_DefaultSession_Start')]=function (r) _var_q1=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('P2')}})); _var_q2=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('P2Ex')}}));  end}, false, false)
						
				end
			),
			OtxExceptions.createCatch('Exception', 
				function(exception)
					_var_exception = exception
					
						-- NODE-ID: throw10
						OtxDebug.setCurrentNodeId('throw10')
						OtxExceptions.throw(OtxExceptions.createException('UserException', String:new('Procedure: Post-Flash'), _var_exception.text))
						
				end
			),
		}, function() --finally
		end
	)
	
	-- NODE-ID: return2
	OtxDebug.setCurrentNodeId('return2')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

function _prc_Erase(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_ComChannel = nil
	local _var_FlashSession = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_BlockNumber = 0
	
	-- in and inout parameters
	if (argumentsTable._var_ComChannel ~= nil) then _var_ComChannel = tdutil.checkParamType(argumentsTable._var_ComChannel, nil) end
	if (argumentsTable._var_FlashSession ~= nil) then _var_FlashSession = tdutil.checkParamType(argumentsTable._var_FlashSession, nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]) end
	if (argumentsTable._var_BlockNumber ~= nil) then _var_BlockNumber = tdutil.checkParamType(argumentsTable._var_BlockNumber, 0) end
	
	-- inout and out parameters
	getReturnTable = function() return {} end
	
	-- procedure declarations
	local _var_exception = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_StartAddress = ByteFieldType:new()
	local _var_StopAddress = ByteFieldType:new()
	local _var_Request = ByteFieldType:new()
	local _var_Response = ByteFieldType:new()
	local _var_data = ByteFieldType:new()
	local _var_i1 = 0
	
	-- NODE-ID: handler10
	OtxDebug.setCurrentNodeId('handler10')
	OtxExceptions.handler(
		function() --try
				-- NODE-ID: branch6
				OtxDebug.setCurrentNodeId('branch6')
				if (true) then
					-- NODE-ID: action130
					OtxDebug.setCurrentNodeId('action130')
					Flash.GetDownloadData(_var_FlashSession, _var_BlockNumber, 0, 0, 4, _var_data)
					
					-- NODE-ID: action121
					OtxDebug.setCurrentNodeId('action121')
					_var_Request = ByteFieldType:new({49,1}):getCopy()
					
					-- NODE-ID: action131
					OtxDebug.setCurrentNodeId('action131')
					_var_Request:append(_var_data)
					
					-- NODE-ID: action122
					OtxDebug.setCurrentNodeId('action122')
					_var_Response = DiagCom.ExecuteHexDiagService(_var_ComChannel, _var_Request)
					
					-- NODE-ID: action129
					-- DISABLED!
					
				else
					-- NODE-ID: action110
					OtxDebug.setCurrentNodeId('action110')
					_var_memAddr = Flash.GetStartAddress(_var_FlashSession, _var_BlockNumber, 0)
					
					-- NODE-ID: action111
					OtxDebug.setCurrentNodeId('action111')
					_var_memSize = Flash.GetUncompressedSize(_var_FlashSession, _var_BlockNumber, 0)
					
					-- NODE-ID: group14
					OtxDebug.setCurrentNodeId('group14')
					OtxDebug.logSpecification('Implement all Erase memory services')
					do
						-- NODE-ID: action66
						OtxDebug.setCurrentNodeId('action66')
						_var_StartAddress = OtxMath.IntegerToByteField('UNSIGNED', 4, 'BIG-ENDIAN', _var_memAddr):getCopy()
						
						-- NODE-ID: action67
						OtxDebug.setCurrentNodeId('action67')
						_var_StopAddress = OtxMath.IntegerToByteField('UNSIGNED', 4, 'BIG-ENDIAN', _var_memSize):getCopy()
						
						-- NODE-ID: action69
						OtxDebug.setCurrentNodeId('action69')
						_var_Request = ByteFieldType:new({49,1,255,0}):getCopy()
						
						-- NODE-ID: action70
						OtxDebug.setCurrentNodeId('action70')
						_var_Request:append(_var_StartAddress)
						_var_Request:append(_var_StopAddress)
						
						-- NODE-ID: action71
						OtxDebug.setCurrentNodeId('action71')
						_var_Response = DiagCom.ExecuteHexDiagService(_var_ComChannel, _var_Request)
						
						-- NODE-ID: action72
						-- DISABLED!
						
					end
					
				end
				
		end, { --catch
			OtxExceptions.createCatch('Exception', 
				function(exception)
					_var_exception = exception
					
						-- NODE-ID: throw11
						OtxDebug.setCurrentNodeId('throw11')
						OtxExceptions.throw(OtxExceptions.createException('UserException', String:new('Procedure: Erase'), _var_exception.text))
						
				end
			),
		}, function() --finally
		end
	)
	
	-- NODE-ID: return4
	OtxDebug.setCurrentNodeId('return4')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

function _prc_CheckValidSessions(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_ComChannel = nil
	local _var_FlashSession = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	
	-- in and inout parameters
	if (argumentsTable._var_ComChannel ~= nil) then _var_ComChannel = tdutil.checkParamType(argumentsTable._var_ComChannel, nil) end
	
	-- inout and out parameters
	getReturnTable = function() return {_var_FlashSession=_var_FlashSession} end
	
	-- procedure declarations
	local _var_validSessions = ListType:new({}, {'list','FlashSession'})
	local _var_validSessionsNames = ListType:new({}, {'list','OTXString'})
	local _var_sessions = ListType:new({}, {'list','OTXString'})
	local _var_exception = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_unknownIssue = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_counter = 0
	
	-- NODE-ID: handler2
	OtxDebug.setCurrentNodeId('handler2')
	OtxExceptions.handler(
		function() --try
				-- NODE-ID: action14
				OtxDebug.setCurrentNodeId('action14')
				_var_sessions = Flash.GetListOfValidFlashSessions(_var_ComChannel, Flash.Direction.DOWNLOAD, nil)
				
				-- NODE-ID: branch8
				OtxDebug.setCurrentNodeId('branch8')
				if ((#_var_sessions > 0)) then
					-- NODE-ID: loop10
					OtxDebug.setCurrentNodeId('loop10')
					_var_counter = 0
					while (_var_counter <= (#_var_sessions - 1)) do
						-- NODE-ID: action15
						OtxDebug.setCurrentNodeId('action15')
						_var_FlashSession = Flash.GetFlashSession(_var_sessions[_var_counter])
						
						-- NODE-ID: action64
						OtxDebug.setCurrentNodeId('action64')
						_var_validSessions:append({_var_FlashSession})
						
						-- NODE-ID: action68
						OtxDebug.setCurrentNodeId('action68')
						_var_validSessionsNames:append({Flash.GetSessionID(_var_FlashSession)})
						
						-- NODE-ID: group4
						OtxDebug.setCurrentNodeId('group4')
						OtxDebug.logSpecification('Implement expected idents here')
						do
						end
						
						_var_counter = _var_counter + 1
					end
					
					-- NODE-ID: branch13
					OtxDebug.setCurrentNodeId('branch13')
					if ((#_var_validSessions > 1)) then
					elseif ((Equals(#_var_validSessions, 0))) then
						-- NODE-ID: throw13
						OtxDebug.setCurrentNodeId('throw13')
						OtxExceptions.throw(OtxExceptions.createException('UserException', String:new('CheckValidSession'), String:new('No valid flash sessios found')))
						
					else
						-- NODE-ID: action65
						OtxDebug.setCurrentNodeId('action65')
						_var_FlashSession = _var_validSessions[0]
						
					end
					
				else
					-- NODE-ID: action19
					OtxDebug.setCurrentNodeId('action19')
					_var_exception = OtxExceptions.createException('UserException', String:new('Procedure: CheckValid Session'), String:new('No valid flash session found'))
					
					-- NODE-ID: throw4
					OtxDebug.setCurrentNodeId('throw4')
					OtxExceptions.throw(_var_exception)
					
				end
				
		end, { --catch
			OtxExceptions.createCatch('UserException', 
				function(exception)
					_var_exception = exception
					
						-- NODE-ID: throw5
						OtxDebug.setCurrentNodeId('throw5')
						OtxExceptions.throw(_var_exception)
						
				end
			),
			OtxExceptions.createCatch('Exception', 
				function(exception)
					_var_unknownIssue = exception
					
						-- NODE-ID: throw6
						OtxDebug.setCurrentNodeId('throw6')
						OtxExceptions.throw(OtxExceptions.createException('UserException', String:new('Procedure: Check Valid Session'), String:new('Exception Type: ').._var_unknownIssue.qualifier..String:new('   Exception Text: ').._var_unknownIssue.text))
						
				end
			),
		}, function() --finally
		end
	)
	
	-- NODE-ID: return6
	OtxDebug.setCurrentNodeId('return6')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

function _prc_flashBlocks(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_channel = nil
	local _var_flashSession = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	
	-- in and inout parameters
	if (argumentsTable._var_channel ~= nil) then _var_channel = tdutil.checkParamType(argumentsTable._var_channel, nil) end
	if (argumentsTable._var_flashSession ~= nil) then _var_flashSession = tdutil.checkParamType(argumentsTable._var_flashSession, nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]) end
	
	-- inout and out parameters
	getReturnTable = function() return {} end
	
	-- procedure declarations
	local _var_noOfBlocks = 0
	local _var_loop = 0
	local _var_exception = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_Response = ByteFieldType:new()
	local _var_Request = ByteFieldType:new()
	local _var_totalSize = 0
	local _var_ProgressSendChannel = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	
	-- NODE-ID: action174
	OtxDebug.setCurrentNodeId('action174')
	OtxDebug.addStackLevel('GetTotalFlashSize')
	local _tmp_returnTable6
	_tmp_returnTable6 = _prc_GetTotalFlashSize({_var_flashSession = _var_flashSession})
	OtxDebug.decrementStackLevel()
	if (_tmp_returnTable6 ~= nil) then
		_var_totalSize = _tmp_returnTable6._var_totalSize
	end
	
	-- NODE-ID: action169
	OtxDebug.setCurrentNodeId('action169')
	writeLog(SeverityLevel.INFO, String:new('Total flash size ')..ToString(_var_totalSize))
	
	-- NODE-ID: handler6
	OtxDebug.setCurrentNodeId('handler6')
	OtxExceptions.handler(
		function() --try
				-- NODE-ID: action38
				OtxDebug.setCurrentNodeId('action38')
				OtxDebug.logSpecification('mumber of Blocks')
				-- SPEC: mumber of Blocks
				_var_noOfBlocks = Flash.GetNumberOfBlocks(_var_flashSession)
				
				-- NODE-ID: loop1
				OtxDebug.setCurrentNodeId('loop1')
				_var_loop = 0
				while (_var_loop <= (_var_noOfBlocks - 1)) do
					-- NODE-ID: action85
					OtxDebug.setCurrentNodeId('action85')
					OtxDebug.logSpecification('get the Step')
					-- SPEC: get the Step
					_var_step = ToString((_var_loop + 1))..String:new(' / ')..ToString((_var_noOfBlocks + 1))
					
					-- NODE-ID: branch3
					OtxDebug.setCurrentNodeId('branch3')
					if ((Equals(Flash.GetType(_var_flashSession, _var_loop), String:new('ERASELOGBLOCK1')))) then
						-- NODE-ID: action6
						OtxDebug.setCurrentNodeId('action6')
						OtxDebug.logSpecification('call erase')
						-- SPEC: call erase
						OtxDebug.addStackLevel('Erase')
						local _tmp_returnTable7
						_tmp_returnTable7 = _prc_Erase({_var_ComChannel = _var_channel, _var_FlashSession = _var_flashSession, _var_BlockNumber = _var_loop})
						OtxDebug.decrementStackLevel()
						
					elseif ((Equals(Flash.GetType(_var_flashSession, _var_loop), String:new('CODEFILE1_1')))) then
						-- NODE-ID: action97
						OtxDebug.setCurrentNodeId('action97')
						_var_downloadedSize = 0
						
						-- NODE-ID: action39
						OtxDebug.setCurrentNodeId('action39')
						OtxDebug.logSpecification('call Flash')
						-- SPEC: call Flash
						OtxDebug.addStackLevel('flashSegment')
						local _tmp_returnTable8
						_tmp_returnTable8 = _prc_flashSegment({_var_channel = _var_channel, _var_flashSession = _var_flashSession, _var_block = _var_loop, _var_segment = 0, _var_totalFlashSize = _var_totalSize})
						OtxDebug.decrementStackLevel()
						
					elseif ((Equals(Flash.GetType(_var_flashSession, _var_loop), String:new('CHECKLOGBLOCK1')))) then
						-- NODE-ID: action7
						OtxDebug.setCurrentNodeId('action7')
						OtxDebug.logSpecification('call erase')
						-- SPEC: call erase
						OtxDebug.addStackLevel('Check')
						local _tmp_returnTable9
						_tmp_returnTable9 = _prc_Check({_var_ComChannel = _var_channel, _var_FlashSession = _var_flashSession, _var_BlockNumber = _var_loop})
						OtxDebug.decrementStackLevel()
						
					elseif ((Equals(Flash.GetType(_var_flashSession, _var_loop), String:new('ERASELOGBLOCK2')))) then
						-- NODE-ID: action117
						OtxDebug.setCurrentNodeId('action117')
						OtxDebug.logSpecification('call erase')
						-- SPEC: call erase
						OtxDebug.addStackLevel('Erase')
						local _tmp_returnTable10
						_tmp_returnTable10 = _prc_Erase({_var_ComChannel = _var_channel, _var_FlashSession = _var_flashSession, _var_BlockNumber = _var_loop})
						OtxDebug.decrementStackLevel()
						
					elseif ((Equals(Flash.GetType(_var_flashSession, _var_loop), String:new('CODEFILE2_1')))) then
						-- NODE-ID: action103
						OtxDebug.setCurrentNodeId('action103')
						_var_downloadedSize = 0
						
						-- NODE-ID: action118
						OtxDebug.setCurrentNodeId('action118')
						OtxDebug.logSpecification('call Flash')
						-- SPEC: call Flash
						OtxDebug.addStackLevel('flashSegment')
						local _tmp_returnTable11
						_tmp_returnTable11 = _prc_flashSegment({_var_channel = _var_channel, _var_flashSession = _var_flashSession, _var_block = _var_loop, _var_segment = 0, _var_totalFlashSize = _var_totalSize})
						OtxDebug.decrementStackLevel()
						
					elseif ((Equals(Flash.GetType(_var_flashSession, _var_loop), String:new('CHECKLOGBLOCK2')))) then
						-- NODE-ID: action58
						OtxDebug.setCurrentNodeId('action58')
						OtxDebug.logSpecification('call erase')
						-- SPEC: call erase
						OtxDebug.addStackLevel('Check')
						local _tmp_returnTable12
						_tmp_returnTable12 = _prc_Check({_var_ComChannel = _var_channel, _var_FlashSession = _var_flashSession, _var_BlockNumber = _var_loop})
						OtxDebug.decrementStackLevel()
						
					elseif ((Equals(Flash.GetType(_var_flashSession, _var_loop), String:new('CHECKDEPENDENCIES')))) then
						-- NODE-ID: action59
						OtxDebug.setCurrentNodeId('action59')
						OtxDebug.logSpecification('call erase')
						-- SPEC: call erase
						OtxDebug.addStackLevel('Check')
						local _tmp_returnTable13
						_tmp_returnTable13 = _prc_Check({_var_ComChannel = _var_channel, _var_FlashSession = _var_flashSession, _var_BlockNumber = _var_loop})
						OtxDebug.decrementStackLevel()
						
					end
					
					_var_loop = _var_loop + 1
				end
				
		end, { --catch
			OtxExceptions.createCatch('Exception', 
				function(exception)
					_var_exception = exception
					
						-- NODE-ID: throw3
						OtxDebug.setCurrentNodeId('throw3')
						OtxExceptions.throw(_var_exception)
						
				end
			),
		}, function() --finally
		end
	)
	
	-- NODE-ID: return9
	OtxDebug.setCurrentNodeId('return9')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

function _prc_flashBlock(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_channel = nil
	local _var_flashSession = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_block = 0
	
	-- in and inout parameters
	if (argumentsTable._var_channel ~= nil) then _var_channel = tdutil.checkParamType(argumentsTable._var_channel, nil) end
	if (argumentsTable._var_flashSession ~= nil) then _var_flashSession = tdutil.checkParamType(argumentsTable._var_flashSession, nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]) end
	if (argumentsTable._var_block ~= nil) then _var_block = tdutil.checkParamType(argumentsTable._var_block, 0) end
	
	-- inout and out parameters
	getReturnTable = function() return {} end
	
	-- procedure declarations
	local _var_noOfSegments = 0
	local _var_loop = 0
	local _var_exception = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	
	-- NODE-ID: handler4
	OtxDebug.setCurrentNodeId('handler4')
	OtxExceptions.handler(
		function() --try
				-- NODE-ID: action42
				OtxDebug.setCurrentNodeId('action42')
				_var_noOfSegments = (Flash.GetNumberOfSegments(_var_flashSession, _var_block) - 1)
				
				-- NODE-ID: loop4
				OtxDebug.setCurrentNodeId('loop4')
				_var_loop = 0
				while (_var_loop <= _var_noOfSegments) do
					-- NODE-ID: action1
					OtxDebug.setCurrentNodeId('action1')
					OtxDebug.addStackLevel('flashSegment')
					local _tmp_returnTable14
					_tmp_returnTable14 = _prc_flashSegment({_var_channel = _var_channel, _var_flashSession = _var_flashSession, _var_block = _var_block, _var_segment = 0})
					OtxDebug.decrementStackLevel()
					
					_var_loop = _var_loop + 1
				end
				
		end, { --catch
			OtxExceptions.createCatch('Exception', 
				function(exception)
					_var_exception = exception
					
						-- NODE-ID: throw1
						OtxDebug.setCurrentNodeId('throw1')
						OtxExceptions.throw(_var_exception)
						
				end
			),
		}, function() --finally
		end
	)
	
	-- NODE-ID: return10
	OtxDebug.setCurrentNodeId('return10')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

function _prc_flashSegment(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_channel = nil
	local _var_flashSession = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_block = 0
	local _var_segment = 0
	local _var_totalFlashSize = 0
	
	-- in and inout parameters
	if (argumentsTable._var_channel ~= nil) then _var_channel = tdutil.checkParamType(argumentsTable._var_channel, nil) end
	if (argumentsTable._var_flashSession ~= nil) then _var_flashSession = tdutil.checkParamType(argumentsTable._var_flashSession, nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]) end
	if (argumentsTable._var_block ~= nil) then _var_block = tdutil.checkParamType(argumentsTable._var_block, 0) end
	if (argumentsTable._var_segment ~= nil) then _var_segment = tdutil.checkParamType(argumentsTable._var_segment, 0) end
	if (argumentsTable._var_totalFlashSize ~= nil) then _var_totalFlashSize = tdutil.checkParamType(argumentsTable._var_totalFlashSize, 0) end
	
	-- inout and out parameters
	getReturnTable = function() return {} end
	
	-- procedure declarations
	local _var_blockSize = 1024
	local _var_data = ByteFieldType:new()
	local _var_exception = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_retry = false
	local _var_counter = 0
	local _var_StartAddress = ByteFieldType:new()
	local _var_Request = ByteFieldType:new()
	local _var_Response = ByteFieldType:new()
	local _var_MemSize = ByteFieldType:new()
	local _var_numBlocks = 0
	local _var_TDCounter = 0
	local _var_i1 = 0
	local _var_LogBlock = ByteFieldType:new()
	local _var_s1 = String:new('')
	local _var_noOfSegments = 0
	local _var_blockSize2 = 0
	local _var_blocksequence = 0
	local _var_ResultState1 = DiagCom.ResultState.ALL_FAILED
	local _var_flashProgress = 0.0
	
	-- NODE-ID: handler5
	OtxDebug.setCurrentNodeId('handler5')
	OtxExceptions.handler(
		function() --try
				
				-- NODE-ID: action108
				OtxDebug.setCurrentNodeId('action108')
				_var_memSize = 0
				
				-- NODE-ID: action142
				OtxDebug.setCurrentNodeId('action142')
				_var_downloadedSize = 0
				
				-- NODE-ID: action45
				OtxDebug.setCurrentNodeId('action45')
				_var_memAddr = Flash.GetStartAddress(_var_flashSession, _var_block, _var_counter)
				
				-- NODE-ID: action4
				OtxDebug.setCurrentNodeId('action4')
				_var_noOfSegments = Flash.GetNumberOfSegments(_var_flashSession, _var_block)
				
				-- NODE-ID: loop7
				OtxDebug.setCurrentNodeId('loop7')
				_var_counter = 0
				while (_var_counter <= (_var_noOfSegments - 1)) do
					-- NODE-ID: action143
					OtxDebug.setCurrentNodeId('action143')
					_var_memSize = (_var_memSize + Flash.GetUncompressedSize(_var_flashSession, _var_block, _var_counter))
					
					_var_counter = _var_counter + 1
				end
				
				-- NODE-ID: action188
				OtxDebug.setCurrentNodeId('action188')
				Tele.Sleep(3000)
				_var_i1 = 0
				
				-- NODE-ID: group1
				OtxDebug.setCurrentNodeId('group1')
				OtxDebug.logSpecification('Implement Request Download')
				do
					-- NODE-ID: action140
					OtxDebug.setCurrentNodeId('action140')
					_var_MemSize = OtxMath.IntegerToByteField('SIGNED-BINARY', 4, 'BIG-ENDIAN', _var_memSize):getCopy()
					
					-- NODE-ID: action41
					OtxDebug.setCurrentNodeId('action41')
					_var_Request = ByteFieldType:new({52,32,68}):getCopy()
					
					-- NODE-ID: action134
					OtxDebug.setCurrentNodeId('action134')
					_var_s1 = Flash.GetOwnIdent(_var_flashSession, _var_block, 0)
					
					-- NODE-ID: action132
					OtxDebug.setCurrentNodeId('action132')
					writeLog(SeverityLevel.INFO, _var_s1)
					
					-- NODE-ID: action136
					OtxDebug.setCurrentNodeId('action136')
					_var_LogBlock = ByteFieldType:fromInteger(OtxMath.ToInteger(_var_s1)):getCopy()
					
					-- NODE-ID: action43
					OtxDebug.setCurrentNodeId('action43')
					_var_Request:append(ByteFieldType:new({00,02,00,00}):getCopy())
					_var_Request:append(_var_MemSize)
					
					-- NODE-ID: action46
					OtxDebug.setCurrentNodeId('action46')
					_var_Response = DiagCom.ExecuteHexDiagService(_var_channel, _var_Request)
					
					-- NODE-ID: action47
					-- DISABLED!
					
					-- NODE-ID: action48
					OtxDebug.setCurrentNodeId('action48')
					-- _var_blockSize = (OtxMath.ByteFieldToInteger('UNSIGNED', 'BIG-ENDIAN', _var_Response:getSubByteField(2, 2)) - 2)
					_var_blockSize = 2048
					
					-- NODE-ID: action139
					OtxDebug.setCurrentNodeId('action139')
					_var_blockSize2 = _var_blockSize
					
					-- NODE-ID: action36
					-- DISABLED!
					
				end
				
				-- NODE-ID: loop5
				OtxDebug.setCurrentNodeId('loop5')
				_var_counter = 0
				while (_var_counter <= (_var_noOfSegments - 1)) do
					-- NODE-ID: action40
					-- DISABLED!
					
					-- NODE-ID: action55
					OtxDebug.setCurrentNodeId('action55')
					_var_memSize = Flash.GetCompressedSize(_var_flashSession, _var_block, _var_counter)
					
					-- NODE-ID: action138
					OtxDebug.setCurrentNodeId('action138')
					_var_downloadedSize = 0
					
					-- NODE-ID: action141
					OtxDebug.setCurrentNodeId('action141')
					_var_blockSize = _var_blockSize2
					
					-- NODE-ID: loop9
					OtxDebug.setCurrentNodeId('loop9')
					while ((_var_memSize > _var_downloadedSize)) do
						-- NODE-ID: branch4
						OtxDebug.setCurrentNodeId('branch4')
						if ((_var_blockSize > (_var_memSize - _var_downloadedSize))) then
							-- NODE-ID: action50
							OtxDebug.setCurrentNodeId('action50')
							_var_blockSize = (_var_memSize - _var_downloadedSize)
							
						end
						
						-- NODE-ID: action8
						OtxDebug.setCurrentNodeId('action8')
						_var_numBlocks = Flash.GetNumberOfBlocks(_var_flashSession)
						
						-- NODE-ID: action137
						OtxDebug.setCurrentNodeId('action137')
						writeLog(SeverityLevel.INFO, String:new('block ')..ToString(_var_block)..String:new(' counter ')..ToString(_var_counter)..String:new(' downloadedSize ')..ToString(_var_downloadedSize)..String:new(' blocksize ')..ToString(_var_blockSize))
						
						-- NODE-ID: action52
						OtxDebug.setCurrentNodeId('action52')
						Flash.GetDownloadData(_var_flashSession, _var_block, _var_counter, _var_downloadedSize, _var_blockSize, _var_data)
						
						-- NODE-ID: group2
						OtxDebug.setCurrentNodeId('group2')
						do
							-- NODE-ID: action95
							OtxDebug.setCurrentNodeId('action95')
							_var_retry = true
							
							-- NODE-ID: loop3
							OtxDebug.setCurrentNodeId('loop3')
							while (_var_retry) do
								-- NODE-ID: handler12
								OtxDebug.setCurrentNodeId('handler12')
								OtxExceptions.handler(
									function() --try
											-- NODE-ID: action119
											OtxDebug.setCurrentNodeId('action119')
											_var_retry = false
											
											-- NODE-ID: branch5
											OtxDebug.setCurrentNodeId('branch5')
											if ((_var_TDCounter >= 255)) then
												-- NODE-ID: action109
												OtxDebug.setCurrentNodeId('action109')
												_var_TDCounter = 0
												
											else
												-- NODE-ID: action44
												OtxDebug.setCurrentNodeId('action44')
												_var_TDCounter = (_var_TDCounter + 1)
												
											end
											
											-- NODE-ID: group16
											-- DISABLED!
											
											-- NODE-ID: group21
											OtxDebug.setCurrentNodeId('group21')
											OtxDebug.logSpecification('implement transfer data odx')
											do
												-- NODE-ID: macro5
												OtxDebug.setCurrentNodeId('macro5')
												do
													-- NODE-ID: action89
													OtxDebug.setCurrentNodeId('action89')
													writeLog(SeverityLevel.INFO, String:new(' data length ')..ToString(#_var_data)..String:new(' block counter ')..ToString(_var_TDCounter))
													
													-- NODE-ID: _macro5_action1
													OtxDebug.setCurrentNodeId('_macro5_action1')
													local _tmp_2
													_tmp_2, _var_ResultState1 = DiagCom.ExecuteDiagService(DiagCom.CreateDiagServiceByName(DiagCom.GetComChannel(String:new('CC_UDSonCAN'), nil, false), String:new('Download_Transfer_Data')), {[tostring(String:new('BlockSequenceCounter'))]=_var_TDCounter, [tostring(String:new('TransferRequestData'))]=_var_data}, {[String:new('PR_Download_TransferData')]=function (r) _var_blocksequence=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('BlockSequenceCounter')}}));  end}, false, false)
													
													-- NODE-ID: branch12
													OtxDebug.setCurrentNodeId('branch12')
													if (((Equals(_var_ResultState1, DiagCom.ResultState.ALL_POSITIVE)) or (Equals(_var_ResultState1, DiagCom.ResultState.POSITIVE)))) then
														-- NODE-ID: action163
														OtxDebug.setCurrentNodeId('action163')
														writeLog(SeverityLevel.FATAL, ToString(_var_ResultState1))
														
														-- NODE-ID: action164
														OtxDebug.setCurrentNodeId('action164')
														_var_flashProgress = (100 * (OtxMath.ToFloat(_var_totaldownloadedSize) / OtxMath.ToFloat(_var_totalFlashSize)))
																												
													else
														-- NODE-ID: throw40
														OtxDebug.setCurrentNodeId('throw40')
														OtxExceptions.throw(OtxExceptions.createException('UserException', String:new('Procedure: Flash-Segment'), _var_exception.text))
														
													end
													
												end
												
											end
											
									end, { --catch
										OtxExceptions.createCatch('Exception', 
											function(exception)
												_var_exception = exception
												
													-- NODE-ID: throw14
													OtxDebug.setCurrentNodeId('throw14')
													OtxExceptions.throw(_var_exception)
													
											end
										),
									}, function() --finally
									end
								)
								
							end
							
						end
						
						-- NODE-ID: action54
						OtxDebug.setCurrentNodeId('action54')
						_var_downloadedSize = (_var_downloadedSize + _var_blockSize)
						
						-- NODE-ID: action170
						OtxDebug.setCurrentNodeId('action170')
						_var_totaldownloadedSize = (_var_totaldownloadedSize + _var_blockSize)
						
					end
					
					_var_counter = _var_counter + 1
				end
				
				-- NODE-ID: group3
				OtxDebug.setCurrentNodeId('group3')
				OtxDebug.logSpecification('Implement Transfer Exit')
				do
					-- NODE-ID: action60
					OtxDebug.setCurrentNodeId('action60')
					_var_Response = ByteFieldType:new({0}):getCopy()
					
					-- NODE-ID: action61
					OtxDebug.setCurrentNodeId('action61')
					_var_Request = ByteFieldType:new({55}):getCopy()
					
					-- NODE-ID: action62
					OtxDebug.setCurrentNodeId('action62')
					_var_Response = DiagCom.ExecuteHexDiagService(_var_channel, _var_Request)
					
					-- NODE-ID: action63
					-- DISABLED!
					
					-- NODE-ID: action84
					OtxDebug.setCurrentNodeId('action84')
					_var_TDCounter = 0
					
				end
				
		end, { --catch
			OtxExceptions.createCatch('Exception', 
				function(exception)
					_var_exception = exception
					
						-- NODE-ID: throw2
						OtxDebug.setCurrentNodeId('throw2')
						OtxExceptions.throw(OtxExceptions.createException('UserException', String:new('Procedure: flash Segment'), _var_exception.text))
						
				end
			),
		}, function() --finally
		end
	)
	
	-- NODE-ID: return13
	OtxDebug.setCurrentNodeId('return13')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

OtxModule.setPublic('_prc_ExceptionHandler', _ENV)
function _prc_ExceptionHandler(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_ServiceResponseByte = ByteFieldType:new({})
	local _var_ServiceResponseString = String:new(' ')
	
	-- in and inout parameters
	if (argumentsTable._var_ServiceResponseByte ~= nil) then _var_ServiceResponseByte = tdutil.checkParamType(argumentsTable._var_ServiceResponseByte, ByteFieldType:new({})) end
	if (argumentsTable._var_ServiceResponseString ~= nil) then _var_ServiceResponseString = tdutil.checkParamType(argumentsTable._var_ServiceResponseString, String:new(' ')) end
	
	-- inout and out parameters
	getReturnTable = function() return {} end
	
	-- procedure declarations
	local _var_UserException = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_SubField = ByteFieldType:new()
	
	-- NODE-ID: branch1
	OtxDebug.setCurrentNodeId('branch1')
	if (((_var_ServiceResponseString:len() > 0) and not ((Equals(_var_ServiceResponseString, String:new(' ')))))) then
		-- NODE-ID: action5
		OtxDebug.setCurrentNodeId('action5')
		_var_UserException = OtxExceptions.createException('UserException', String:new('Communication Exception'), _var_ServiceResponseString)
		
		-- NODE-ID: throw9
		OtxDebug.setCurrentNodeId('throw9')
		OtxExceptions.throw(_var_UserException)
		
	elseif (((#_var_ServiceResponseByte > 0) and (Equals(_var_ServiceResponseByte:getSubByteField(0, 1), ByteFieldType:new({127}))))) then
		-- NODE-ID: action10
		OtxDebug.setCurrentNodeId('action10')
		_var_SubField = _var_ServiceResponseByte:getSubByteField((#_var_ServiceResponseByte - 1), 1):getCopy()
		
		-- NODE-ID: branch10
		OtxDebug.setCurrentNodeId('branch10')
		if ((Equals(_var_SubField, ByteFieldType:new({16})))) then
			-- NODE-ID: action12
			OtxDebug.setCurrentNodeId('action12')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   General Reject'))
			
			-- NODE-ID: throw15
			OtxDebug.setCurrentNodeId('throw15')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({17})))) then
			-- NODE-ID: action13
			OtxDebug.setCurrentNodeId('action13')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Service not supported'))
			
			-- NODE-ID: throw16
			OtxDebug.setCurrentNodeId('throw16')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({18})))) then
			-- NODE-ID: action16
			OtxDebug.setCurrentNodeId('action16')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Subfunction not supported - invalid format'))
			
			-- NODE-ID: throw17
			OtxDebug.setCurrentNodeId('throw17')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({33})))) then
			-- NODE-ID: action17
			OtxDebug.setCurrentNodeId('action17')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Busy - repeat request'))
			
			-- NODE-ID: throw18
			OtxDebug.setCurrentNodeId('throw18')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({34})))) then
			-- NODE-ID: action18
			OtxDebug.setCurrentNodeId('action18')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Conditions not correct or request sequence error'))
			
			-- NODE-ID: throw19
			OtxDebug.setCurrentNodeId('throw19')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({35})))) then
			-- NODE-ID: action20
			OtxDebug.setCurrentNodeId('action20')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Request correctly received - response pending 0x23'))
			
			-- NODE-ID: throw20
			OtxDebug.setCurrentNodeId('throw20')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({49})))) then
			-- NODE-ID: action21
			OtxDebug.setCurrentNodeId('action21')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Request out of range'))
			
			-- NODE-ID: throw21
			OtxDebug.setCurrentNodeId('throw21')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({51})))) then
			-- NODE-ID: action22
			OtxDebug.setCurrentNodeId('action22')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Security access denied - security access requested'))
			
			-- NODE-ID: throw22
			OtxDebug.setCurrentNodeId('throw22')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({53})))) then
			-- NODE-ID: action23
			OtxDebug.setCurrentNodeId('action23')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Invalid key'))
			
			-- NODE-ID: throw23
			OtxDebug.setCurrentNodeId('throw23')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({54})))) then
			-- NODE-ID: action24
			OtxDebug.setCurrentNodeId('action24')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Exceed number of attempts'))
			
			-- NODE-ID: throw24
			OtxDebug.setCurrentNodeId('throw24')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({55})))) then
			-- NODE-ID: action25
			OtxDebug.setCurrentNodeId('action25')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Required time delay not expired'))
			
			-- NODE-ID: throw25
			OtxDebug.setCurrentNodeId('throw25')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({64})))) then
			-- NODE-ID: action26
			OtxDebug.setCurrentNodeId('action26')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Download not accepted'))
			
			-- NODE-ID: throw26
			OtxDebug.setCurrentNodeId('throw26')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({80})))) then
			-- NODE-ID: action27
			OtxDebug.setCurrentNodeId('action27')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Upload not accepted'))
			
			-- NODE-ID: throw27
			OtxDebug.setCurrentNodeId('throw27')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({113})))) then
			-- NODE-ID: action28
			OtxDebug.setCurrentNodeId('action28')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Transfer suspended'))
			
			-- NODE-ID: throw28
			OtxDebug.setCurrentNodeId('throw28')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({120})))) then
			-- NODE-ID: action29
			OtxDebug.setCurrentNodeId('action29')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Request correctly received - response pending'))
			
			-- NODE-ID: throw29
			OtxDebug.setCurrentNodeId('throw29')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({128})))) then
			-- NODE-ID: action30
			OtxDebug.setCurrentNodeId('action30')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Service not supported in active diagnostic session'))
			
			-- NODE-ID: throw30
			OtxDebug.setCurrentNodeId('throw30')
			OtxExceptions.throw(_var_UserException)
			
		elseif ((Equals(_var_SubField, ByteFieldType:new({251})))) then
			-- NODE-ID: action31
			OtxDebug.setCurrentNodeId('action31')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:   ')..StringUtil.Decode('HEX', _var_ServiceResponseByte)..String:new(':   Request correctly received - response pending 0xFB'))
			
			-- NODE-ID: throw31
			OtxDebug.setCurrentNodeId('throw31')
			OtxExceptions.throw(_var_UserException)
			
		else
			-- NODE-ID: action32
			OtxDebug.setCurrentNodeId('action32')
			_var_UserException = OtxExceptions.createException('UserException', String:new('Service Exception'), String:new('Negative Response:  ')..StringUtil.Decode('HEX', _var_ServiceResponseByte))
			
			-- NODE-ID: throw32
			OtxDebug.setCurrentNodeId('throw32')
			OtxExceptions.throw(_var_UserException)
			
		end
		
	end
	
	-- NODE-ID: return11
	OtxDebug.setCurrentNodeId('return11')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

OtxModule.setPublic('_prc_Logging', _ENV)
function _prc_Logging(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_SeverityLevel1 = SeverityLevel.INFO
	local _var_FileName = String:new('')
	local _var_LogInput = ListType:new({}, {'list','OTXString'})
	
	-- in and inout parameters
	if (argumentsTable._var_SeverityLevel1 ~= nil) then _var_SeverityLevel1 = tdutil.checkParamType(argumentsTable._var_SeverityLevel1, SeverityLevel.INFO) end
	if (argumentsTable._var_FileName ~= nil) then _var_FileName = tdutil.checkParamType(argumentsTable._var_FileName, String:new('')) end
	if (argumentsTable._var_LogInput ~= nil) then _var_LogInput = tdutil.checkParamType(argumentsTable._var_LogInput, ListType:new({}, {'list','OTXString'})) end
	
	-- inout and out parameters
	getReturnTable = function() return {} end
	
	-- procedure declarations
	local _var_counter = 0
	
	-- NODE-ID: loop2
	OtxDebug.setCurrentNodeId('loop2')
	for _key in pairs(_var_LogInput) do
		_var_counter = _key
		
		-- NODE-ID: action33
		OtxDebug.setCurrentNodeId('action33')
		writeDomainLog(_var_FileName, _var_SeverityLevel1, _var_LogInput[_var_counter])
		
	end
	
	-- NODE-ID: return12
	OtxDebug.setCurrentNodeId('return12')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

function _prc_SecurityAccess(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_ComChannel = nil
	local _var_SecurityPassed = false
	
	-- in and inout parameters
	if (argumentsTable._var_ComChannel ~= nil) then _var_ComChannel = tdutil.checkParamType(argumentsTable._var_ComChannel, nil) end
	
	-- inout and out parameters
	getReturnTable = function() return {_var_SecurityPassed=_var_SecurityPassed} end
	
	-- procedure declarations
	local _var_Request = ByteFieldType:new()
	local _var_Response = ByteFieldType:new()
	local _var_SEED = ByteFieldType:new()
	local _var_SEED2 = 0
	local _var_ResultState1 = DiagCom.ResultState.ALL_FAILED
	local _var_KEY = 0
	local _var_exception = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_userException = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_lossOfCom = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	
	-- NODE-ID: group19
	OtxDebug.setCurrentNodeId('group19')
	OtxDebug.logSpecification('odx')
	do
		-- NODE-ID: handler8
		OtxDebug.setCurrentNodeId('handler8')
		OtxExceptions.handler(
			function() --try
					-- NODE-ID: macro3
					OtxDebug.setCurrentNodeId('macro3')
					OtxDebug.logSpecification('Request SEED')
					do
						-- NODE-ID: _macro3_action1
						OtxDebug.setCurrentNodeId('_macro3_action1')
						local _tmp_3
						_tmp_3, _var_ResultState1 = DiagCom.ExecuteDiagService(DiagCom.CreateDiagServiceByName(DiagCom.GetComChannel(String:new('CC_UDSonCAN'), nil, false), String:new('Ser_Request_Seed_Level_02')), {}, {[String:new('PR_Ser_Request_Seed_Level_02')]=function (r) _var_SEED2=DiagCom.GetParameterValue(DiagCom.GetParameterByPath(r, {{name=String:new('Param_Seed')}}));  end}, false, false)
						
					end
					
					-- NODE-ID: branch9
					OtxDebug.setCurrentNodeId('branch9')
					if (((Equals(_var_ResultState1, DiagCom.ResultState.ALL_POSITIVE)) or (Equals(_var_ResultState1, DiagCom.ResultState.POSITIVE)))) then
						-- NODE-ID: action151
						OtxDebug.setCurrentNodeId('action151')
						writeLog(SeverityLevel.FATAL, ToString(_var_ResultState1))
						
					else
						-- NODE-ID: throw36
						OtxDebug.setCurrentNodeId('throw36')
						OtxExceptions.throw(OtxExceptions.createException('UserException', String:new('Procedure: Pre-Flash'), _var_exception.text))
						
					end
					
					-- NODE-ID: action152
					OtxDebug.setCurrentNodeId('action152')
					_var_KEY = _var_SEED2
					
					-- NODE-ID: macro4
					OtxDebug.setCurrentNodeId('macro4')
					do
						-- NODE-ID: _macro4_action1
						OtxDebug.setCurrentNodeId('_macro4_action1')
						local _tmp_4
						_tmp_4, _var_ResultState1 = DiagCom.ExecuteDiagService(DiagCom.CreateDiagServiceByName(DiagCom.GetComChannel(String:new('CC_UDSonCAN'), nil, false), String:new('Ser_Send_Key_Level_02')), {[tostring(String:new('Param_key'))]=_var_KEY}, {[String:new('PR_Ser_Send_Key_Level_02')]=function (r)  end}, false, false)
						
					end
					
					-- NODE-ID: branch11
					OtxDebug.setCurrentNodeId('branch11')
					if (((Equals(_var_ResultState1, DiagCom.ResultState.ALL_POSITIVE)) or (Equals(_var_ResultState1, DiagCom.ResultState.POSITIVE)))) then
						-- NODE-ID: action155
						OtxDebug.setCurrentNodeId('action155')
						writeLog(SeverityLevel.FATAL, ToString(_var_ResultState1))
						
						-- NODE-ID: action156
						OtxDebug.setCurrentNodeId('action156')
						_var_SecurityPassed = true
						
					else
						-- NODE-ID: throw37
						OtxDebug.setCurrentNodeId('throw37')
						OtxExceptions.throw(OtxExceptions.createException('UserException', String:new('Procedure: Pre-Flash'), _var_exception.text))
						
					end
					
			end, { --catch
				OtxExceptions.createCatch('LossOfComException', 
					function(exception)
						_var_lossOfCom = exception
						
							-- NODE-ID: action157
							OtxDebug.setCurrentNodeId('action157')
							writeLog(SeverityLevel.FATAL, ToString(_var_ResultState1))
							
							-- NODE-ID: throw38
							OtxDebug.setCurrentNodeId('throw38')
							OtxExceptions.throw()
							
					end
				),
				OtxExceptions.createCatch('UserException', 
					function(exception)
						_var_userException = exception
						
							-- NODE-ID: action160
							OtxDebug.setCurrentNodeId('action160')
							_var_userException = OtxExceptions.createException('UserException', String:new('Procedure: Pre-Flash'), String:new('Exception Type: ').._var_exception.qualifier..String:new('   Exception Text: ').._var_exception.text)
							
							-- NODE-ID: throw39
							OtxDebug.setCurrentNodeId('throw39')
							OtxExceptions.throw()
							
					end
				),
				OtxExceptions.createCatch('Exception', 
					function(exception)
						_var_exception = exception
						
					end
				),
			}, function() --finally
			end
		)
		
	end
	
	-- NODE-ID: group20
	-- DISABLED!
	
	-- NODE-ID: return3
	OtxDebug.setCurrentNodeId('return3')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

function _prc_Check(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_ComChannel = nil
	local _var_FlashSession = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_BlockNumber = 0
	
	-- in and inout parameters
	if (argumentsTable._var_ComChannel ~= nil) then _var_ComChannel = tdutil.checkParamType(argumentsTable._var_ComChannel, nil) end
	if (argumentsTable._var_FlashSession ~= nil) then _var_FlashSession = tdutil.checkParamType(argumentsTable._var_FlashSession, nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]) end
	if (argumentsTable._var_BlockNumber ~= nil) then _var_BlockNumber = tdutil.checkParamType(argumentsTable._var_BlockNumber, 0) end
	
	-- inout and out parameters
	getReturnTable = function() return {} end
	
	-- procedure declarations
	local _var_exception = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_StartAddress = ByteFieldType:new()
	local _var_StopAddress = ByteFieldType:new()
	local _var_Request = ByteFieldType:new()
	local _var_Response = ByteFieldType:new()
	local _var_data = ByteFieldType:new()
	local _var_memSize = 0
	
	-- NODE-ID: handler3
	OtxDebug.setCurrentNodeId('handler3')
	OtxExceptions.handler(
		function() --try
				-- NODE-ID: action35
				OtxDebug.setCurrentNodeId('action35')
				_var_memSize = (_var_memSize + Flash.GetUncompressedSize(_var_FlashSession, _var_BlockNumber, 0))
				
				-- NODE-ID: action34
				OtxDebug.setCurrentNodeId('action34')
				Flash.GetDownloadData(_var_FlashSession, _var_BlockNumber, 0, 0, _var_memSize, _var_data)
				
				-- NODE-ID: action49
				OtxDebug.setCurrentNodeId('action49')
				_var_Request = ByteFieldType:new({49,1}):getCopy()
				
				-- NODE-ID: action98
				OtxDebug.setCurrentNodeId('action98')
				_var_Request:append(_var_data)
				
				-- NODE-ID: action133
				OtxDebug.setCurrentNodeId('action133')
				_var_Response = DiagCom.ExecuteHexDiagService(_var_ComChannel, _var_Request)
				
				-- NODE-ID: action135
				-- DISABLED!
				
		end, { --catch
			OtxExceptions.createCatch('Exception', 
				function(exception)
					_var_exception = exception
					
						-- NODE-ID: throw12
						OtxDebug.setCurrentNodeId('throw12')
						OtxExceptions.throw(OtxExceptions.createException('UserException', String:new('Procedure: Erase'), _var_exception.text))
						
				end
			),
		}, function() --finally
		end
	)
	
	-- NODE-ID: return5
	OtxDebug.setCurrentNodeId('return5')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

function _prc_GetTotalFlashSize(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_flashSession = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
	local _var_totalSize = 0
	
	-- in and inout parameters
	if (argumentsTable._var_flashSession ~= nil) then _var_flashSession = tdutil.checkParamType(argumentsTable._var_flashSession, nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]) end
	
	-- inout and out parameters
	getReturnTable = function() return {_var_totalSize=_var_totalSize} end
	
	-- procedure declarations
	local _var_noOfBlocks = 0
	local _var_loop = 0
	local _var_noOfSegments = 0
	local _var_memSize = 0
	local _var_counter = 0
	
	-- NODE-ID: action165
	OtxDebug.setCurrentNodeId('action165')
	OtxDebug.logSpecification('mumber of Blocks')
	-- SPEC: mumber of Blocks
	_var_noOfBlocks = Flash.GetNumberOfBlocks(_var_flashSession)
	
	-- NODE-ID: loop6
	OtxDebug.setCurrentNodeId('loop6')
	_var_loop = 0
	while (_var_loop <= (_var_noOfBlocks - 1)) do
		-- NODE-ID: action176
		OtxDebug.setCurrentNodeId('action176')
		_var_noOfSegments = Flash.GetNumberOfSegments(_var_flashSession, _var_loop)
		
		-- NODE-ID: loop8
		OtxDebug.setCurrentNodeId('loop8')
		_var_counter = 0
		while (_var_counter <= (_var_noOfSegments - 1)) do
			-- NODE-ID: action180
			OtxDebug.setCurrentNodeId('action180')
			_var_memSize = (_var_memSize + Flash.GetCompressedSize(_var_flashSession, _var_loop, _var_counter))
			
			_var_counter = _var_counter + 1
		end
		
		_var_loop = _var_loop + 1
	end
	
	-- NODE-ID: action168
	OtxDebug.setCurrentNodeId('action168')
	_var_totalSize = (_var_memSize - 18)
	
	-- NODE-ID: return7
	OtxDebug.setCurrentNodeId('return7')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

local _var_seq_result = OtxModule.defineMainAndExecute(_ENV, function()
	local mainArgs = {_var_Fingerprint=ByteFieldType:new({1,2,3,4,5}),_var_triggerName=String:new(''),_var_scriptResult=1,_var_newSoftwareVersion=ByteFieldType:new({1,1})}
	local outArgTypes = {_var_scriptResult='Integer',_var_newSoftwareVersion='ByteField'}
	return tdutil.runMain(_prc_main, mainArgs, outArgTypes)
end)

return _var_seq_result
