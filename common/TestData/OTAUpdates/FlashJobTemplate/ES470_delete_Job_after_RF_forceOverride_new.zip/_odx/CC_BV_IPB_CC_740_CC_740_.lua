
local Flash = tdutil.loadLibrary("Flash")

writeLog(SeverityLevel.INFO, 'Loading flash data : ' .. 'CC_BV_IPB.odx-f')

local CC_BV_IPB_CC_740_CC_740_ = {}

CC_BV_IPB_CC_740_CC_740_.CC_740_ = {Sessions={}, Blocks={}, FlashDatas={}}

CC_BV_IPB_CC_740_CC_740_.CC_740_.FlashDatas.CODEDATAPART1_CB1BB93833 = {dataFormat=Flash.FlashDataFormat.BINARY,dataFile="CB1BB93833.bin"}
CC_BV_IPB_CC_740_CC_740_.CC_740_.FlashDatas.CODEDATAPART2_CB2BB93833 = {dataFormat=Flash.FlashDataFormat.BINARY,dataFile="CB2BB93833.bin"}
CC_BV_IPB_CC_740_CC_740_.CC_740_.FlashDatas.ERASELOGBLOCK1_ERASE1 = {dataFormat=Flash.FlashDataFormat.BINARY,data={255,0,1,1}}
CC_BV_IPB_CC_740_CC_740_.CC_740_.FlashDatas.ERASELOGBLOCK2_ERASE2 = {dataFormat=Flash.FlashDataFormat.BINARY,data={255,0,1,2}}
CC_BV_IPB_CC_740_CC_740_.CC_740_.FlashDatas.CHECKLOGBLOCK1_CHECK1 = {dataFormat=Flash.FlashDataFormat.BINARY,data={2,2,1,1}}
CC_BV_IPB_CC_740_CC_740_.CC_740_.FlashDatas.CHECKLOGBLOCK2_CHECK2 = {dataFormat=Flash.FlashDataFormat.BINARY,data={2,2,1,2}}
CC_BV_IPB_CC_740_CC_740_.CC_740_.FlashDatas.CHECKDEPENDENCIES_CHECK3 = {dataFormat=Flash.FlashDataFormat.BINARY,data={255,1}}

CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["ERASELOGBLOCK1"] = {name="ERASELOGBLOCK1",blockType="ERASELOGBLOCK1",Segments={},OwnIdents={}}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["ERASELOGBLOCK1"].FlashData = CC_BV_IPB_CC_740_CC_740_.CC_740_.FlashDatas.ERASELOGBLOCK1_ERASE1
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["ERASELOGBLOCK1"].Segments[1] = {segId=0,startAddress=0x00000000,uncompressedSize=4,compressedSize=4}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["ERASELOGBLOCK1"].Security = {}

CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CODEDATAPART1"] = {name="CODEDATAPART1",blockType="CODEFILE1_1",Segments={},OwnIdents={}}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CODEDATAPART1"].FlashData = CC_BV_IPB_CC_740_CC_740_.CC_740_.FlashDatas.CODEDATAPART1_CB1BB93833
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CODEDATAPART1"].Segments[1] = {name="BLOCK01_ID",startAddress=0x00020000,uncompressedSize=6160384,compressedSize=1268214}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CODEDATAPART1"].Security = {}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CODEDATAPART1"].OwnIdents[1] = {name="LogBlock",value="1"}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CODEDATAPART1"].OwnIdents[2] = {name="AppSW",value="PRJ_CodeBlock1_BB93833_11_5_2_05_IPBBSW.hex"}

CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CHECKLOGBLOCK1"] = {name="CHECKLOGBLOCK1",blockType="CHECKLOGBLOCK1",Segments={},OwnIdents={}}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CHECKLOGBLOCK1"].FlashData = CC_BV_IPB_CC_740_CC_740_.CC_740_.FlashDatas.CHECKLOGBLOCK1_CHECK1
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CHECKLOGBLOCK1"].Segments[1] = {segId=0,startAddress=0x00000000,uncompressedSize=4,compressedSize=4}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CHECKLOGBLOCK1"].Security = {}

CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["ERASELOGBLOCK2"] = {name="ERASELOGBLOCK2",blockType="ERASELOGBLOCK2",Segments={},OwnIdents={}}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["ERASELOGBLOCK2"].FlashData = CC_BV_IPB_CC_740_CC_740_.CC_740_.FlashDatas.ERASELOGBLOCK2_ERASE2
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["ERASELOGBLOCK2"].Segments[1] = {segId=0,startAddress=0x00000000,uncompressedSize=4,compressedSize=4}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["ERASELOGBLOCK2"].Security = {}

CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CODEDATAPART2"] = {name="CODEDATAPART2",blockType="CODEFILE2_1",Segments={},OwnIdents={}}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CODEDATAPART2"].FlashData = CC_BV_IPB_CC_740_CC_740_.CC_740_.FlashDatas.CODEDATAPART2_CB2BB93833
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CODEDATAPART2"].Segments[1] = {name="BLOCK01_ID",startAddress=0x00020000,uncompressedSize=4194304,compressedSize=7281}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CODEDATAPART2"].Security = {}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CODEDATAPART2"].OwnIdents[1] = {name="LogBlock",value="2"}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CODEDATAPART2"].OwnIdents[2] = {name="AppSW",value="PRJ_CodeBlock2_BB93833_11_5_2_05_IPBBSW.hex"}

CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CHECKLOGBLOCK2"] = {name="CHECKLOGBLOCK2",blockType="CHECKLOGBLOCK2",Segments={},OwnIdents={}}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CHECKLOGBLOCK2"].FlashData = CC_BV_IPB_CC_740_CC_740_.CC_740_.FlashDatas.CHECKLOGBLOCK2_CHECK2
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CHECKLOGBLOCK2"].Segments[1] = {segId=0,startAddress=0x00000000,uncompressedSize=4,compressedSize=4}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CHECKLOGBLOCK2"].Security = {}

CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CHECKDEPENDENCIES"] = {name="CHECKDEPENDENCIES",blockType="CHECKDEPENDENCIES",Segments={},OwnIdents={}}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CHECKDEPENDENCIES"].FlashData = CC_BV_IPB_CC_740_CC_740_.CC_740_.FlashDatas.CHECKDEPENDENCIES_CHECK3
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CHECKDEPENDENCIES"].Segments[1] = {segId=0,startAddress=0x00000000,uncompressedSize=2,compressedSize=2}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CHECKDEPENDENCIES"].Security = {}

CC_BV_IPB_CC_740_CC_740_.CC_740_.Sessions.CC_740_Flash = {name="CC_740_Flash",key='Session3'}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Sessions.CC_740_Flash.Security = {{SecurityMethod="SEGMENT_CHECKSUM",FwChecksum="CRC16CCITT"}}
CC_BV_IPB_CC_740_CC_740_.CC_740_.Sessions.CC_740_Flash.Blocks = {CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["ERASELOGBLOCK1"],CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CODEDATAPART1"],CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CHECKLOGBLOCK1"],CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["ERASELOGBLOCK2"],CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CODEDATAPART2"],CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CHECKLOGBLOCK2"],CC_BV_IPB_CC_740_CC_740_.CC_740_.Blocks["CHECKDEPENDENCIES"]}


function CC_BV_IPB_CC_740_CC_740_.getFlash()
	return CC_BV_IPB_CC_740_CC_740_.CC_740_
end

return CC_BV_IPB_CC_740_CC_740_