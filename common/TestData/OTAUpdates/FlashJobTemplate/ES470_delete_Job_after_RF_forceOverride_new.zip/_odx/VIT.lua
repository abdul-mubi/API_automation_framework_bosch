
local ODX = tdutil.loadLibrary("ODX")

VIT = {PhysicalLinks={}, LogicalLinks={}}

VIT.PhysicalLinks.HIGH_SPEED_BUS = {busType="ISO_11898_2_DWCAN",pins={{pin=6,pinType="HI"},{pin=14,pinType="LOW"}}}

VIT.LogicalLinks.CC_UDSonCAN = ODX.LogicalLink:new("CC_UDSonCAN", VIT.PhysicalLinks.HIGH_SPEED_BUS, ODX.getBaseVariant("CC_BV_IPB"), "UDS", {CP_RCByteOffset=4294967295,CP_SuspendQueueOnError=0,CP_P3Phys=30000,CP_TesterPresentSendType=1,CP_CanTransmissionTime=100000,CP_BlockSize=0,CP_SyncJumpWidth=19,CP_RC21RequestTime=200000,CP_CanBaudrateRecord={0x00,0x07,0xA1,0x20,0x00,0x03,0xD0,0x90},CP_Loopback=0,NL_buffer_FlashProgramming=4095,CP_TransmitIndEnable=0,CP_CanFirstConsecutiveFrameValue=1,CP_TesterPresentExpNegResp={},CP_RxBufferDim=0,CP_TesterPresentAddrMode=1,CP_P2Max_Ecu=50000,CP_CanDataSizeOffset=0,NL_buffer_NormalCommunication=255,CP_P2Max=5000000,CP_TerminationType=0,CP_RepeatReqCountApp=0,CP_As=50000,CP_RC23RequestTime=200000,CP_Ar=50000,CP_CanFuncReqFormat=4,CP_TesterPresentMessage={0x3E,0x80},CP_TesterPresentTime=4000000,CP_BlockSizeOverride=65535,CP_CanMaxNumWaitFrames=0,CP_RC78Handling=2,CP_P2Min=0,CP_StartMsgIndEnable=0,CP_P2Star=5200000,CP_ChangeSpeedResCtrl=0,CP_ModifyTiming=0,CP_TesterPresentHandling=1,CP_RepeatReqCountTrans=0,CP_TP_Mode=0,CP_ChangeSpeedTxDelay=0,CP_RC21Handling=0,CP_P2Star_Ecu=5100000,CP_RC23CompletionTimeout=0,CP_Bs=75000,CP_Br=42000,CP_ListenOnly=0,CP_RC23Handling=0,CP_CanFillerByteHandling=1,CP_SendRemoteFrame=0,Protocol=0,CP_CanFuncReqExtAddr=0,CP_StMin_Ecu=0,CP_RC78CompletionTimeout=52000000,CP_TesterPresentReqRsp=0,CP_StMinOverride=4294967295,CP_CyclicRespTimeout=0,CP_SamplesPerBit=0,CP_CanFillerByte=0,CP_RequestAddrMode=1,CP_EnablePerformanceTest=0,CP_ChangeSpeedRate=0,CP_P3Func=30000,CP_RC21CompletionTimeout=1300000,CP_TesterPresentTime_Ecu=5000000,NL_buffer_DownLoad=1024,CP_BitSamplePoint=81,CP_Cr=150000,CP_ChangeSpeedCtrl=0,CP_CanFuncReqId=2000,CP_Cs=110000,CP_StMin=0,CP_Baudrate=500000,CP_ChangeSpeedMessage={},CP_SwCan_HighVoltage=0,CP_TesterPresentExpPosResp={},CP_SessionTimingOverride={CP_SessionTimingOverride_P2Star_High=0,CP_SessionTimingOverride_SessionNumber=0,CP_SessionTimingOverride_P2Max_High=0,CP_SessionTimingOverride_P2Max_Low=0,CP_SessionTimingOverride_P2Star_Low=0},URID={{CP_PhysReqIdReprog=10,CP_CanRespUUDTFormat=0,CP_CanRespUUDTId=1626,CP_ECULayerShortName="CC_BV_IPB",CP_CanPhysReqId=1888,CP_CanRespUUDTExtAddr=0,CP_CanRespUSDTId=1856,CP_CanRespUSDTExtAddr=0,CP_CanPhysReqFormat=5,CP_CanRespUSDTFormat=5,CP_CanPhysReqExtAddr=0}}})


function VIT.getLogicalLink(name)
	return VIT.LogicalLinks[name]
end

return VIT