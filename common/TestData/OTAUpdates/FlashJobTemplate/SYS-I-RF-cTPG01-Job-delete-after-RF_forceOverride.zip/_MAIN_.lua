-- Publisher version: 1.3.0.201708021402
package.path = './_lib/?.lua;./_odx/?.lua;/data/encrypted/rda_app/LIBS/?.lua;' .. package.path
package.cpath = './_lib/?.dll;./_lib/?.so;' .. package.cpath

require('loadLibrary')
require('TDLIB')

RDCOM = tdutil.loadLibrary('RDCOM_CTP')
RDCOM.initializePlatform()

local _var_seq_result = OtxModule.executeMain('Procedures', 'Flash_Telematik_CC', _ENV)
RDCOM.releasePlatform()
return _var_seq_result
