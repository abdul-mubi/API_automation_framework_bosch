
local CC_BV_IPB_EcuMem = {}

CC_BV_IPB_EcuMem.Sessions = {}

local function loadFlash(modName)
	local status, mod = pcall(tdutil.loadLibrary, modName)
	if (status and mod ~= nil and mod.getFlash ~= nil) then
		writeLog(SeverityLevel.TRACE, 'Loading flash module ' .. modName)
		for k,s in pairs(mod.getFlash().Sessions) do
			CC_BV_IPB_EcuMem.Sessions[#CC_BV_IPB_EcuMem.Sessions+1] = s
		end
	else
		writeLog(SeverityLevel.WARN, 'Cannot find flash module ' .. modName)
	end
end

function CC_BV_IPB_EcuMem.getFlash()
	if (#CC_BV_IPB_EcuMem.Sessions == 0) then
		loadFlash('CC_BV_IPB_CC_740_CC_740_')
	end
	
	return CC_BV_IPB_EcuMem
end

return CC_BV_IPB_EcuMem
