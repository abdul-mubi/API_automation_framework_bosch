
local ODX = tdutil.loadLibrary("ODX")

VIT = {PhysicalLinks={}, LogicalLinks={}}

VIT.PhysicalLinks.CAN_D = {busType="ISO_11898_2_DWCAN",pins={{pin=6,pinType="HI"},{pin=14,pinType="LOW"}}}

VIT.LogicalLinks.UDSonCAN_Bosch = ODX.LogicalLink:new("UDSonCAN_Bosch", VIT.PhysicalLinks.CAN_D, ODX.getBaseVariant("UDSonCAN_Bosch"), "UDS", {CP_RCByteOffset=4294967295,CP_SuspendQueueOnError=0,CP_P3Phys=50000,CP_TesterPresentSendType=0,CP_CanTransmissionTime=100000,CP_BlockSize=0,CP_SyncJumpWidth=15,CP_RC21RequestTime=200000,CP_CanBaudrateRecord={0x00,0x07,0xA1,0x20,0x00,0x03,0xD0,0x90},CP_Loopback=0,CP_TransmitIndEnable=0,CP_CanFirstConsecutiveFrameValue=1,CP_TesterPresentExpNegResp={},CP_TesterPresentAddrMode=1,CP_CanDataSizeOffset=0,CP_P2Max=150000,CP_TerminationType=0,CP_RepeatReqCountApp=0,CP_As=1000000,CP_RC23RequestTime=200000,CP_Ar=1000000,CP_CanFuncReqFormat=5,CP_TesterPresentMessage={0x3E,0x80},CP_TesterPresentTime=2000000,CP_BlockSizeOverride=65535,CP_CanMaxNumWaitFrames=255,CP_RC78Handling=2,CP_P2Min=0,CP_StartMsgIndEnable=0,CP_P2Star=5050000,CP_ChangeSpeedResCtrl=0,CP_ModifyTiming=0,CP_TesterPresentHandling=1,CP_RepeatReqCountTrans=0,CP_ChangeSpeedTxDelay=0,CP_RC21Handling=0,CP_RC23CompletionTimeout=0,CP_Bs=1000000,CP_Br=10000,CP_ListenOnly=0,CP_RC23Handling=0,CP_CanFillerByteHandling=1,CP_SendRemoteFrame=0,CP_CanFuncReqExtAddr=0,CP_RC78CompletionTimeout=25000000,CP_TesterPresentReqRsp=0,CP_StMinOverride=65535,CP_CyclicRespTimeout=0,CP_SamplesPerBit=0,CP_CanFillerByte=85,CP_RequestAddrMode=1,CP_EnablePerformanceTest=0,CP_ChangeSpeedRate=0,CP_P3Func=50000,CP_RC21CompletionTimeout=1300000,CP_BitSamplePoint=80,CP_Cr=1000000,CP_ChangeSpeedCtrl=0,CP_CanFuncReqId=2015,CP_Cs=10000,CP_StMin=0,CP_Baudrate=1000000,CP_ChangeSpeedMessage={},CP_SwCan_HighVoltage=0,CP_TesterPresentExpPosResp={},CP_SessionTimingOverride={CP_SessionTimingOverride_P2Star_High=0,CP_SessionTimingOverride_SessionNumber=0,CP_SessionTimingOverride_P2Max_High=0,CP_SessionTimingOverride_P2Max_Low=0,CP_SessionTimingOverride_P2Star_Low=0},URID={{CP_CanRespUUDTFormat=0,CP_CanRespUUDTId=4294967295,CP_ECULayerShortName="None",CP_CanPhysReqId=1812,CP_CanRespUUDTExtAddr=0,CP_CanRespUSDTId=1918,CP_CanRespUSDTExtAddr=0,CP_CanPhysReqFormat=5,CP_CanRespUSDTFormat=5,CP_CanPhysReqExtAddr=0}}})


function VIT.getLogicalLink(name)
	return VIT.LogicalLinks[name]
end

return VIT