
local DiagCom = tdutil.loadLibrary("DiagCom")
local ODX = tdutil.loadLibrary("ODX")

----------------------------------------------------------------------------------------------------------
-- WARNING: All byte positions follow Lua convention (index starts at 1) !!!!
----------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------
-- BaseVariant
----------------------------------------------------------------------------------------------------------

local RBCD_BV_IPB = ODX.BaseVariant:new("RBCD_BV_IPB", {})

function RBCD_BV_IPB.getBaseVariant()
	return RBCD_BV_IPB
end

function RBCD_BV_IPB.getEcuVariant()
	if (RBCD_BV_IPB[RBCD_BV_IPB:getVariant()] ~= nil) then
		return RBCD_BV_IPB[RBCD_BV_IPB:getVariant()]
	end

	return RBCD_BV_IPB
end

-- DtcDops



-- Dops

RBCD_BV_IPB.Dops.JLR_NRC_DOP_1=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),ODX.TextTable:new(nil,{{low=17,text="Service not supported"}}),ODX.DataType.A_UNICODE2STRING,nil,{},nil,nil)
RBCD_BV_IPB.Dops.DOP_ASCII24=ODX.Dop:new(ODX.MinMaxLengthType:new(ODX.DataType.A_ASCIISTRING, ODX.Encoding.ISO_8859_1, true, 1, 24, ODX.Termination.ZERO),ODX.Identical:new(),ODX.DataType.A_UNICODE2STRING,nil,nil,nil,nil)
RBCD_BV_IPB.Dops.HexDump_1Byte=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),ODX.Identical:new(),ODX.DataType.A_UINT32,nil,nil,nil,nil)
RBCD_BV_IPB.Dops.Read_DOP=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),ODX.TextTable:new(nil,{{low=19,text="Incorrect message length or invalid format"},{low=34,text="Conditions not correct"},{low=49,text="Request out of range"},{low=51,text="Security access denied"},{low=120,text="Request correctly received - response pending"}}),ODX.DataType.A_UNICODE2STRING,nil,{},nil,nil)
RBCD_BV_IPB.Dops.DOP_3byte_identical=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 24, ODX.Encoding.NONE, true, nil, false),ODX.Identical:new(),ODX.DataType.A_UINT32,nil,nil,nil,nil)
RBCD_BV_IPB.Dops.P2=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 16, ODX.Encoding.NONE, true, nil, false),ODX.Identical:new(),ODX.DataType.A_UINT32,"ms",nil,nil,nil)
RBCD_BV_IPB.Dops.P2Ex=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 16, ODX.Encoding.NONE, true, nil, false),ODX.Linear:new(10, 0, 1),ODX.DataType.A_UINT32,"ms",nil,nil,nil)
RBCD_BV_IPB.Dops.Start_NR_DOP=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),ODX.TextTable:new(nil,{{low=18,text="Subfunction not supported"},{low=19,text="Incorrect message length or invalid format"},{low=34,text="Conditions not correct"},{low=49,text="Request out of range"},{low=120,text="Request correctly received - response pending"},{low=126,text="Subfunction not supported in active session"}}),ODX.DataType.A_UNICODE2STRING,nil,nil,nil,nil)
RBCD_BV_IPB.Dops.Start_NR_DOP_1=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),ODX.TextTable:new(nil,{{low=17,text="Service not supported"},{low=18,text="Subfunction not supported"},{low=19,text="Incorrect message length or invalid format"},{low=34,text="Conditions not correct"},{low=49,text="Request out of range"},{low=120,text="Request correctly received - response pending"},{low=126,text="Subfunction not supported in active session"}}),ODX.DataType.A_UNICODE2STRING,nil,{},nil,nil)
RBCD_BV_IPB.Dops.Request_download_NR_DOP=ODX.Dop:new(ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),ODX.TextTable:new(nil,{{low=18,text="Subfunction Not Supported - Invalid Format"},{low=34,text="Conditions not correct"},{low=120,text="Request Correctly Received - Response Pending"},{low=153,text="Ready For Download - DTC Stored"}}),ODX.DataType.A_UNICODE2STRING,nil,nil,nil,nil)
RBCD_BV_IPB.Dops.DataTransfer=ODX.Dop:new(ODX.MinMaxLengthType:new(ODX.DataType.A_BYTEFIELD, ODX.Encoding.NONE, true, 1, 4082, ODX.Termination.END_OF_PDU),ODX.Identical:new(),ODX.DataType.A_BYTEFIELD,nil,nil,nil,nil)

-- Structures



-- Tables



-- Muxs



-- EndOfPduFields



-- DynamicLengthFields



-- EnvDatas



-- EnvDataDescs



-- Requests

function RBCD_BV_IPB.Requests.RQ_Read_ECUMainCalibrationData1Number(context)
	local r = DiagCom.Request:new({34,241,36})
	
	return r
end

function RBCD_BV_IPB.Requests.RQ_Read_VehicleManufacturerECUSoftwareNumber(context)
	local r = DiagCom.Request:new({34,241,136})
	
	return r
end

function RBCD_BV_IPB.Requests.RQ_Ser_Request_Seed(context)
	local r = DiagCom.Request:new({39,1})
	
	return r
end

function RBCD_BV_IPB.Requests.RQ_Download_TransferData(context)
	local r = DiagCom.Request:new({54})
	r:encodeParameter(ODX.ValueParameter:new("BlockSequenceCounter","DATA",2,0,nil,function () return RBCD_BV_IPB.Dops.HexDump_1Byte end),context)
	r:encodeParameter(ODX.ValueParameter:new("TransferRequestData","DATA",3,0,nil,function () return RBCD_BV_IPB.Dops.DataTransfer end),context)

	return r
end

function RBCD_BV_IPB.Requests.RQ_DefaultSession_Start(context)
	local r = DiagCom.Request:new({16,1})
	
	return r
end

function RBCD_BV_IPB.Requests.RQ_ProgrammingSession_Start(context)
	local r = DiagCom.Request:new({16,2})
	
	return r
end

-- PosResponses

function RBCD_BV_IPB.PosResponses.PR_Read_ECUMainCalibrationData1Number(buf, context)
	local params = {}
	
	params.SID_PR = ODX.CodedConstParameter:new("SID_PR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),98)
	params.DID = ODX.CodedConstParameter:new("DID","DATA",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 16, ODX.Encoding.NONE, true, nil, false),61732)
	if (params.SID_PR:matchParameter(buf) and params.DID:matchParameter(buf)) then
		local resp = DiagCom.Response:new("PR_Read_ECUMainCalibrationData1Number", true)
		
		local byteOffset = params.SID_PR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_PR)
		
		byteOffset = params.DID:decodeParameter(buf, nil, context)
		resp:addParameter(params.DID)
		
		params.PRM_ECU_Main_Calibration_Data_1_Number = ODX.ValueParameter:new("PRM_ECU_Main_Calibration_Data_1_Number","DATA",4,0,nil,function () return RBCD_BV_IPB.Dops.DOP_ASCII24 end)
		byteOffset = params.PRM_ECU_Main_Calibration_Data_1_Number:decodeParameter(buf, nil, context)
		resp:addParameter(params.PRM_ECU_Main_Calibration_Data_1_Number)
		
		return resp
	end
end

function RBCD_BV_IPB.PosResponses.PR_Read_VehicleManufacturerECUSoftwareNumber(buf, context)
	local params = {}
	
	params.SID_PR = ODX.CodedConstParameter:new("SID_PR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),98)
	params.DID = ODX.CodedConstParameter:new("DID","DATA",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 16, ODX.Encoding.NONE, true, nil, false),61832)
	if (params.SID_PR:matchParameter(buf) and params.DID:matchParameter(buf)) then
		local resp = DiagCom.Response:new("PR_Read_VehicleManufacturerECUSoftwareNumber", true)
		
		local byteOffset = params.SID_PR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_PR)
		
		byteOffset = params.DID:decodeParameter(buf, nil, context)
		resp:addParameter(params.DID)
		
		params.PRM_Vehicle_Manufacturer_ECU_Software_Number = ODX.ValueParameter:new("PRM_Vehicle_Manufacturer_ECU_Software_Number","DATA",4,0,nil,function () return RBCD_BV_IPB.Dops.DOP_ASCII24 end)
		byteOffset = params.PRM_Vehicle_Manufacturer_ECU_Software_Number:decodeParameter(buf, nil, context)
		resp:addParameter(params.PRM_Vehicle_Manufacturer_ECU_Software_Number)
		
		return resp
	end
end

function RBCD_BV_IPB.PosResponses.PR_Ser_Request_Seed(buf, context)
	local params = {}
	
	params.SID_PR = ODX.CodedConstParameter:new("SID_PR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),103)
	params.DID_PR = ODX.CodedConstParameter:new("DID_PR","DATA-ID",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),1)
	if (params.SID_PR:matchParameter(buf) and params.DID_PR:matchParameter(buf)) then
		local resp = DiagCom.Response:new("PR_Ser_Request_Seed", true)
		
		local byteOffset = params.SID_PR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_PR)
		
		byteOffset = params.DID_PR:decodeParameter(buf, nil, context)
		resp:addParameter(params.DID_PR)
		
		params.Param_Seed = ODX.ValueParameter:new("Param_Seed","DATA",3,0,nil,function () return RBCD_BV_IPB.Dops.DOP_3byte_identical end)
		byteOffset = params.Param_Seed:decodeParameter(buf, nil, context)
		resp:addParameter(params.Param_Seed)
		
		return resp
	end
end

function RBCD_BV_IPB.PosResponses.PR_Download_TransferData(buf, context)
	local params = {}
	
	params.SID_PR = ODX.CodedConstParameter:new("SID_PR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),118)
	if (params.SID_PR:matchParameter(buf)) then
		local resp = DiagCom.Response:new("PR_Download_TransferData", true)
		
		local byteOffset = params.SID_PR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_PR)
		
		params.BlockSequenceCounter = ODX.ValueParameter:new("BlockSequenceCounter","DATA",2,0,nil,function () return RBCD_BV_IPB.Dops.HexDump_1Byte end)
		byteOffset = params.BlockSequenceCounter:decodeParameter(buf, nil, context)
		resp:addParameter(params.BlockSequenceCounter)
		
		return resp
	end
end

function RBCD_BV_IPB.PosResponses.PR_DefaultSession_Start(buf, context)
	local params = {}
	
	params.SID_PR = ODX.CodedConstParameter:new("SID_PR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),80)
	params.DiagSessionType = ODX.CodedConstParameter:new("DiagSessionType","SUBFUNCTION",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),1)
	if (params.SID_PR:matchParameter(buf) and params.DiagSessionType:matchParameter(buf)) then
		local resp = DiagCom.Response:new("PR_DefaultSession_Start", true)
		
		local byteOffset = params.SID_PR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_PR)
		
		byteOffset = params.DiagSessionType:decodeParameter(buf, nil, context)
		resp:addParameter(params.DiagSessionType)
		
		return resp
	end
end

function RBCD_BV_IPB.PosResponses.PR_ProgrammingSession_Start(buf, context)
	local params = {}
	
	params.SID_PR = ODX.CodedConstParameter:new("SID_PR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),80)
	params.DiagSessionType = ODX.CodedConstParameter:new("DiagSessionType","SUBFUNCTION",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),2)
	if (params.SID_PR:matchParameter(buf) and params.DiagSessionType:matchParameter(buf)) then
		local resp = DiagCom.Response:new("PR_ProgrammingSession_Start", true)
		
		local byteOffset = params.SID_PR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_PR)
		
		byteOffset = params.DiagSessionType:decodeParameter(buf, nil, context)
		resp:addParameter(params.DiagSessionType)
		
		params.P2 = ODX.ValueParameter:new("P2","DATA",3,0,nil,function () return RBCD_BV_IPB.Dops.P2 end)
		byteOffset = params.P2:decodeParameter(buf, nil, context)
		resp:addParameter(params.P2)
		
		params.P2Ex = ODX.ValueParameter:new("P2Ex","DATA",5,0,nil,function () return RBCD_BV_IPB.Dops.P2Ex end)
		byteOffset = params.P2Ex:decodeParameter(buf, nil, context)
		resp:addParameter(params.P2Ex)
		
		return resp
	end
end


-- NegResponses

function RBCD_BV_IPB.NegResponses.NR_Read_IDENTIFICATION(buf, context)
	local params = {}
	
	params.SID_NR = ODX.CodedConstParameter:new("SID_NR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	params.SIDRQ_NR = ODX.CodedConstParameter:new("SIDRQ_NR","SERVICEIDRQ",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),34)
	params.NRCConst_Read = ODX.NrcConstParameter:new("NRCConst_Read","DATA",3,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),{19,34,49,51,120})
	if (params.SID_NR:matchParameter(buf) and params.SIDRQ_NR:matchParameter(buf) and params.NRCConst_Read:matchParameter(buf)) then
		local resp = DiagCom.Response:new("NR_Read_IDENTIFICATION", false)
		
		local byteOffset = params.SID_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_NR)
		
		byteOffset = params.SIDRQ_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SIDRQ_NR)
		
		params.PRM_Read = ODX.ValueParameter:new("PRM_Read","DATA",3,0,nil,function () return RBCD_BV_IPB.Dops.Read_DOP end)
		byteOffset = params.PRM_Read:decodeParameter(buf, nil, context)
		resp:addParameter(params.PRM_Read)
		
		byteOffset = params.NRCConst_Read:decodeParameter(buf, nil, context)
		resp:addParameter(params.NRCConst_Read)
		
		return resp
	end
end

function RBCD_BV_IPB.NegResponses.NR_Read_IDENTIFICATION(buf, context)
	local params = {}
	
	params.SID_NR = ODX.CodedConstParameter:new("SID_NR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	params.SIDRQ_NR = ODX.CodedConstParameter:new("SIDRQ_NR","SERVICEIDRQ",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),34)
	params.NRCConst_Read = ODX.NrcConstParameter:new("NRCConst_Read","DATA",3,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),{19,34,49,51,120})
	if (params.SID_NR:matchParameter(buf) and params.SIDRQ_NR:matchParameter(buf) and params.NRCConst_Read:matchParameter(buf)) then
		local resp = DiagCom.Response:new("NR_Read_IDENTIFICATION", false)
		
		local byteOffset = params.SID_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_NR)
		
		byteOffset = params.SIDRQ_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SIDRQ_NR)
		
		params.PRM_Read = ODX.ValueParameter:new("PRM_Read","DATA",3,0,nil,function () return RBCD_BV_IPB.Dops.Read_DOP end)
		byteOffset = params.PRM_Read:decodeParameter(buf, nil, context)
		resp:addParameter(params.PRM_Read)
		
		byteOffset = params.NRCConst_Read:decodeParameter(buf, nil, context)
		resp:addParameter(params.NRCConst_Read)
		
		return resp
	end
end

function RBCD_BV_IPB.NegResponses.NR_DS_SN_75(buf, context)
	local params = {}
	
	params.Param_DS_SN_77 = ODX.CodedConstParameter:new("Param_DS_SN_77",nil,1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	if (params.Param_DS_SN_77:matchParameter(buf)) then
		local resp = DiagCom.Response:new("NR_DS_SN_75", false)
		
		local byteOffset = params.Param_DS_SN_77:decodeParameter(buf, nil, context)
		resp:addParameter(params.Param_DS_SN_77)
		
		return resp
	end
end

function RBCD_BV_IPB.NegResponses.NR_Download_RequestDownload(buf, context)
	local params = {}
	
	params.SID_NR = ODX.CodedConstParameter:new("SID_NR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	params.SID_RQ = ODX.CodedConstParameter:new("SID_RQ","SERVICEIDRQ",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),52)
	params.NRCConst_Request_download_NR = ODX.NrcConstParameter:new("NRCConst_Request_download_NR","DATA",3,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),{18,34,120,153})
	if (params.SID_NR:matchParameter(buf) and params.SID_RQ:matchParameter(buf) and params.NRCConst_Request_download_NR:matchParameter(buf)) then
		local resp = DiagCom.Response:new("NR_Download_RequestDownload", false)
		
		local byteOffset = params.SID_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_NR)
		
		byteOffset = params.SID_RQ:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_RQ)
		
		params.Request_download_NR = ODX.ValueParameter:new("Request_download_NR","DATA",3,0,nil,function () return RBCD_BV_IPB.Dops.Request_download_NR_DOP end)
		byteOffset = params.Request_download_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.Request_download_NR)
		
		byteOffset = params.NRCConst_Request_download_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.NRCConst_Request_download_NR)
		
		return resp
	end
end

function RBCD_BV_IPB.NegResponses.NR_DefaultSession_Start(buf, context)
	local params = {}
	
	params.SID_NR = ODX.CodedConstParameter:new("SID_NR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	params.SIDRQ_NR = ODX.CodedConstParameter:new("SIDRQ_NR","SERVICEIDRQ",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),16)
	params.NRCConst_Start_NR = ODX.NrcConstParameter:new("NRCConst_Start_NR","DATA",3,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),{18,19,34,49,120,126})
	if (params.SID_NR:matchParameter(buf) and params.SIDRQ_NR:matchParameter(buf) and params.NRCConst_Start_NR:matchParameter(buf)) then
		local resp = DiagCom.Response:new("NR_DefaultSession_Start", false)
		
		local byteOffset = params.SID_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_NR)
		
		byteOffset = params.SIDRQ_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SIDRQ_NR)
		
		params.Start_NR = ODX.ValueParameter:new("Start_NR","DATA",3,0,nil,function () return RBCD_BV_IPB.Dops.Start_NR_DOP end)
		byteOffset = params.Start_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.Start_NR)
		
		byteOffset = params.NRCConst_Start_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.NRCConst_Start_NR)
		
		return resp
	end
end

function RBCD_BV_IPB.NegResponses.NR_ProgrammingSession_Start(buf, context)
	local params = {}
	
	params.SID_NR = ODX.CodedConstParameter:new("SID_NR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	params.SIDRQ_NR = ODX.CodedConstParameter:new("SIDRQ_NR","SERVICEIDRQ",2,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),16)
	params.NRCConst_Start_NR = ODX.NrcConstParameter:new("NRCConst_Start_NR","DATA",3,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),{17,18,19,34,49,120,126})
	if (params.SID_NR:matchParameter(buf) and params.SIDRQ_NR:matchParameter(buf) and params.NRCConst_Start_NR:matchParameter(buf)) then
		local resp = DiagCom.Response:new("NR_ProgrammingSession_Start", false)
		
		local byteOffset = params.SID_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_NR)
		
		byteOffset = params.SIDRQ_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SIDRQ_NR)
		
		params.Start_NR = ODX.ValueParameter:new("Start_NR","DATA",3,0,nil,function () return RBCD_BV_IPB.Dops.Start_NR_DOP_1 end)
		byteOffset = params.Start_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.Start_NR)
		
		byteOffset = params.NRCConst_Start_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.NRCConst_Start_NR)
		
		return resp
	end
end


-- GlobalNegResponses

function RBCD_BV_IPB.GlobalNegResponses.UNSUPPORTED_SERVICE_NR(buf, context)
	local params = {}
	
	params.SID_NR = ODX.CodedConstParameter:new("SID_NR","SERVICE-ID",1,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),127)
	params.NRCConst_NRC = ODX.NrcConstParameter:new("NRCConst_NRC","DATA",3,0,nil,ODX.StandardLengthType:new(ODX.DataType.A_UINT32, 8, ODX.Encoding.NONE, true, nil, false),{17})
	if (params.SID_NR:matchParameter(buf) and params.NRCConst_NRC:matchParameter(buf)) then
		local resp = DiagCom.Response:new("UNSUPPORTED_SERVICE_NR", false)
		
		local byteOffset = params.SID_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_NR)
		
		params.SID_RQ_NR = ODX.ReservedParameter:new("SID_RQ_NR",nil,2,0,nil,8)
		byteOffset = params.SID_RQ_NR:decodeParameter(buf, nil, context)
		resp:addParameter(params.SID_RQ_NR)
		
		params.NRC = ODX.ValueParameter:new("NRC","DATA",3,0,nil,function () return RBCD_BV_IPB.Dops.JLR_NRC_DOP_1 end)
		byteOffset = params.NRC:decodeParameter(buf, nil, context)
		resp:addParameter(params.NRC)
		
		byteOffset = params.NRCConst_NRC:decodeParameter(buf, nil, context)
		resp:addParameter(params.NRCConst_NRC)
		
		return resp
	end
end


-- Services

RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number = RBCD_BV_IPB:declareService("Read_ECUMainCalibrationData1Number",RBCD_BV_IPB.Requests.RQ_Read_ECUMainCalibrationData1Number,{PR_Read_ECUMainCalibrationData1Number=RBCD_BV_IPB.PosResponses.PR_Read_ECUMainCalibrationData1Number,NR_Read_IDENTIFICATION=RBCD_BV_IPB.NegResponses.NR_Read_IDENTIFICATION,UNSUPPORTED_SERVICE_NR=RBCD_BV_IPB.GlobalNegResponses.UNSUPPORTED_SERVICE_NR})
RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber = RBCD_BV_IPB:declareService("Read_VehicleManufacturerECUSoftwareNumber",RBCD_BV_IPB.Requests.RQ_Read_VehicleManufacturerECUSoftwareNumber,{PR_Read_VehicleManufacturerECUSoftwareNumber=RBCD_BV_IPB.PosResponses.PR_Read_VehicleManufacturerECUSoftwareNumber,NR_Read_IDENTIFICATION=RBCD_BV_IPB.NegResponses.NR_Read_IDENTIFICATION,UNSUPPORTED_SERVICE_NR=RBCD_BV_IPB.GlobalNegResponses.UNSUPPORTED_SERVICE_NR})
RBCD_BV_IPB.Services.Ser_Request_Seed = RBCD_BV_IPB:declareService("Ser_Request_Seed",RBCD_BV_IPB.Requests.RQ_Ser_Request_Seed,{PR_Ser_Request_Seed=RBCD_BV_IPB.PosResponses.PR_Ser_Request_Seed,NR_DS_SN_75=RBCD_BV_IPB.NegResponses.NR_DS_SN_75,UNSUPPORTED_SERVICE_NR=RBCD_BV_IPB.GlobalNegResponses.UNSUPPORTED_SERVICE_NR})
RBCD_BV_IPB.Services.Download_Transfer_Data = RBCD_BV_IPB:declareService("Download_Transfer_Data",RBCD_BV_IPB.Requests.RQ_Download_TransferData,{PR_Download_TransferData=RBCD_BV_IPB.PosResponses.PR_Download_TransferData,NR_Download_RequestDownload=RBCD_BV_IPB.NegResponses.NR_Download_RequestDownload,UNSUPPORTED_SERVICE_NR=RBCD_BV_IPB.GlobalNegResponses.UNSUPPORTED_SERVICE_NR})
RBCD_BV_IPB.Services.DefaultSession_Start = RBCD_BV_IPB:declareService("DefaultSession_Start",RBCD_BV_IPB.Requests.RQ_DefaultSession_Start,{PR_DefaultSession_Start=RBCD_BV_IPB.PosResponses.PR_DefaultSession_Start,NR_DefaultSession_Start=RBCD_BV_IPB.NegResponses.NR_DefaultSession_Start,UNSUPPORTED_SERVICE_NR=RBCD_BV_IPB.GlobalNegResponses.UNSUPPORTED_SERVICE_NR})
RBCD_BV_IPB.Services.ProgrammingSession_Start = RBCD_BV_IPB:declareService("ProgrammingSession_Start",RBCD_BV_IPB.Requests.RQ_ProgrammingSession_Start,{PR_ProgrammingSession_Start=RBCD_BV_IPB.PosResponses.PR_ProgrammingSession_Start,NR_ProgrammingSession_Start=RBCD_BV_IPB.NegResponses.NR_ProgrammingSession_Start,UNSUPPORTED_SERVICE_NR=RBCD_BV_IPB.GlobalNegResponses.UNSUPPORTED_SERVICE_NR})

-- Semantics

RBCD_BV_IPB.Semantics["IDENTIFICATION"] = function ()
return {RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber}
end


RBCD_BV_IPB.Semantics["SECURITY"] = function ()
return {RBCD_BV_IPB.Services.Ser_Request_Seed}
end


RBCD_BV_IPB.Semantics["UP-DOWNLOAD"] = function ()
return {RBCD_BV_IPB.Services.Download_Transfer_Data}
end


RBCD_BV_IPB.Semantics["SESSION"] = function ()
return {RBCD_BV_IPB.Services.DefaultSession_Start,RBCD_BV_IPB.Services.ProgrammingSession_Start}
end


-- DiagnosticClasses

RBCD_BV_IPB.DiagnosticClasses["VARIANTIDENTIFICATION"] = function ()
return {RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber}
end


----------------------------------------------------------------------------------------------------------
-- Variants
----------------------------------------------------------------------------------------------------------

-- Variant JLR_ECUVariant

RBCD_BV_IPB.JLR_ECUVariant = ODX.EcuVariant:new("JLR_ECUVariant", RBCD_BV_IPB)

-- DtcDops



-- Dops



-- Structures



-- Tables



-- Muxs



-- EndOfPduFields



-- DynamicLengthFields



-- EnvDatas



-- EnvDataDescs



-- Requests



-- PosResponses



-- NegResponses



-- GlobalNegResponses



-- Services



-- Semantics



-- DiagnosticClasses



-- Identification patterns

RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns = {}

RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[1] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[2] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-AA13"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA12"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[3] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-AA14"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA12"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[4] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-AA15"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA13"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[5] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-AA16"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA13"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[6] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-AA17"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA14"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[7] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-AA18"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA15"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[8] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-AA19"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA16"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[9] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-AB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[10] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-AB01"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA17"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[11] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-AC"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[12] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-AD"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AC"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[13] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-AE"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AD"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[14] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-BA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[15] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-BA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AC"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[16] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-BA01"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA17"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[17] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-BA02"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AC01"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[18] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="BJ32-14C609-BB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AD"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[19] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="CPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[20] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="CPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[21] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AA01"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA12"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[22] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AA02"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA13"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[23] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AA03"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA13"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[24] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AA04"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA13"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[25] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AA05"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA17"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[26] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AA06"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="CPLA-14C217-AA01"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[27] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AA07"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="CPLA-14C217-AA02"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[28] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AA07"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="CPLA-14C217-AA02"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[29] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AA09"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="CPLA-14C217-AA04"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[30] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AA10"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="CPLA-14C217-AA06"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[31] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AA11"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="CPLA-14C217-AA07"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[32] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="CPLA-14C217-AC"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[33] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="CPLA-14C217-AC"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[34] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="CK52-14C609-AB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="CPLA-14C217-AC"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[35] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[36] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[37] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AA01"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="CPLA-14C217-AA02"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[38] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AA01"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA01"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[39] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AA02"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="CPLA-14C217-AA05"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[40] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AA02"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA02"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[41] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AA03"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA03"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[42] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AA03"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA04"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[43] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AA03"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA04"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[44] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[45] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[46] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[47] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[48] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AC"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[49] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AC"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[50] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK52-14C609-AC"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[51] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK62-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[52] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK62-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[53] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK62-14C609-AA01"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA01"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[54] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK62-14C609-AA02"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA02"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[55] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK62-14C609-AA03"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA03"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[56] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK62-14C609-AA03"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA04"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[57] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK62-14C609-AA03"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA04"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[58] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK62-14C609-AB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[59] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK62-14C609-AB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[60] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK62-14C609-AB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[61] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK62-14C609-AB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[62] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK62-14C609-AC"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[63] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK62-14C609-AC"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[64] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK62-14C609-AC"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[65] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="DK62-14C609-AC"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[66] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="EJ32-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="EJ32-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[67] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="EJ32-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="EJ32-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[68] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="EJ32-14C609-AA01"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="CPLA-14C217-AA05"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[69] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="EJ32-14C609-AA03"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA04"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[70] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="EJ32-14C609-AA03"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA04"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[71] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="EJ32-14C609-AA04"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA06"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[72] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="EJ32-14C609-AA04"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DPLA-14C217-AA06"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[73] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="EJ32-14C609-AB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="EJ32-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[74] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="EJ32-14C609-AB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="EJ32-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[75] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="EJ32-14C609-AC"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="EJ32-14C217-AC"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[76] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="EJ32-14C609-AC"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="EJ32-14C217-AC"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[77] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="EJ32-14C609-AC"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="EJ32-14C217-AC"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[78] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="EJ32-14C609-ESMX"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="EJ32-14C217-ESMX"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[79] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="EJ32-14C609-ESMX"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="EJ32-14C217-ESMX"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[80] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="FK52-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DK52-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[81] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="FK62-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="DK52-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[82] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="FK62-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="FK62-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[83] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="FK62-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="FK62-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[84] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="FK72-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="-FK72-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[85] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="FK72-14C609-AA02"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="FK72-14C217-AA01"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[86] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="FK72-14C609-AA04"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="FK72-14C217-AA03"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[87] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="FK72-14C609-AB"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="FK72-14C217-AB"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[88] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GJ32-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="GJ32-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[89] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GJ32-14C609-AA01"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="BJ32-14C217-AA01"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[90] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GJ32-14C609-AA01"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="GJ32-14C217-AA01"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[91] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GJ32-14C609-AA01X"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="GJ32-14C217-AA01X"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[92] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GJ32-14C609-AA02"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="GJ32-14C217-AA02"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[93] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GK52-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="GPLA-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[94] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GK52-14C609-AA01"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="GPLA-14C217-AA01"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[95] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GK62-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="GPLA-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[96] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GW93-14C609-AA01"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="GX73-14C217-AA05"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[97] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GX53-14C609-AA01"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="GX73-14C217-AA04"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[98] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GX53-14C609-BA01"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="GX73-14C217-AA04"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[99] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GX73-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="GX73-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[100] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GX73-14C609-AA01"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="GX73-14C217-AA01"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[101] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GX73-14C609-AA05"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="GX73-14C217-AA05"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[102] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GX73-14C609-FFF1"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="GX73-14C217-FFF1"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[103] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="GX73-14C609-FFFF"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="GX73-14C217-FFFF"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[104] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="HK72-14C609-AA"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="HK72-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[105] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="HK72-14C609-AA01"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="HK72-14C217-AA"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[106] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="HK83-14C609-AC"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="HK83-14C217-AC"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[107] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="J8A2-14C609-AA02"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="J8A2-14C217-AA01"}}
RBCD_BV_IPB.JLR_ECUVariant.VariantPatterns[108] = {{service=RBCD_BV_IPB.Services.Read_ECUMainCalibrationData1Number,path={{name="PRM_ECU_Main_Calibration_Data_1_Number"}},value="J8A2-14C609-AA03"},{service=RBCD_BV_IPB.Services.Read_VehicleManufacturerECUSoftwareNumber,path={{name="PRM_Vehicle_Manufacturer_ECU_Software_Number"}},value="J8A2-14C217-AA02"}}


function RBCD_BV_IPB.getEcuVariants()
	return {RBCD_BV_IPB.JLR_ECUVariant}
end

return RBCD_BV_IPB