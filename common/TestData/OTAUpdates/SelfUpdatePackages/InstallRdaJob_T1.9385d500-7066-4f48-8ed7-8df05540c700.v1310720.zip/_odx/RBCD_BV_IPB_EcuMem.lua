
local RBCD_BV_IPB_EcuMem = {}

RBCD_BV_IPB_EcuMem.Sessions = {}

local function loadFlash(modName)
	local status, mod = pcall(tdutil.loadLibrary, modName)
	if (status and mod ~= nil and mod.getFlash ~= nil) then
		writeLog(SeverityLevel.TRACE, 'Loading flash module ' .. modName)
		for k,s in pairs(mod.getFlash().Sessions) do
			RBCD_BV_IPB_EcuMem.Sessions[#RBCD_BV_IPB_EcuMem.Sessions+1] = s
		end
	else
		writeLog(SeverityLevel.WARN, 'Cannot find flash module ' .. modName)
	end
end

function RBCD_BV_IPB_EcuMem.getFlash()
	if (#RBCD_BV_IPB_EcuMem.Sessions == 0) then
		loadFlash('RBCD_BV_IPB_RBCD_734_RBCD_734_')
	end
	
	return RBCD_BV_IPB_EcuMem
end

return RBCD_BV_IPB_EcuMem
