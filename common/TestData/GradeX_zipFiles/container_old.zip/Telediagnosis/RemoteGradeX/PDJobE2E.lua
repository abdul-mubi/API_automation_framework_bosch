if (tdutil == nil) then
	-- Publisher version: 1.4.0.201906121138
	local common_paths_available = type(package.searchers[2]('RdaLualibPaths')) == "function"
	if (common_paths_available) then
		require('RdaLualibPaths')
	else
	end
	package.path = './_lib/?.lua;./_odx/?.lua;' .. package.path
	package.cpath = './_lib/?.dll;./_lib/?.so;' .. package.cpath
	
	local RDCOM_NAME = 'RDCOM'
	local common_rdcom_available = type(package.searchers[2](RDCOM_NAME)) == "function"
	if (not common_rdcom_available) then
		print("Note: Common RDCOM.lua not available, using explicit platform version as fallback")
		RDCOM_NAME = 'RDCOM_PLCS'
	end
	require('loadLibrary')
	require('TDLIB')
end

tdutil.registerOtxNamespaceModules({['http://iso.org/OTX/ProprietaryInterface/BackendCallback']='BackendCallback',['http://iso.org/OTX/ProprietaryInterface/CanRecording']='canRaw',['http://iso.org/OTX/1.0.0/DiagCom']='DiagCom',['http://iso.org/OTX/1.0.0/Flash']='Flash',['http://iso.org/OTX/1.0.0/StringUtil']='StringUtil',['http://iso.org/OTX/1.0.0/DateTime']='DateTime',['http://iso.org/OTX/1.0.0/Event']='EventHandling',['http://iso.org/OTX/1.0.0/Quantities']='Quantities',['http://iso.org/OTX/1.0.0/HMI']='HMI',['http://iso.org/OTX/1.0.0/DiagDataBrowsing']='DiagDataBrowsing',['http://iso.org/OTX/1.0.0/File']='File',['http://iso.org/OTX/1.0.0/FlashPlus']='FlashPlus',['http://iso.org/OTX/ProprietaryInterface/DataLogging']='DataLogging',['http://bosch.com/OTX/1.0.0/EcuConfig']='EcuConfig',['http://iso.org/OTX/ProprietaryInterface/EcuList']='EcuList',['http://iso.org/OTX/ProprietaryInterface/FaultCodeSetting']='FaultCodeSetting',['http://gradex.bosch.com/OTX/1.0.0/Firewall']='Firewall',['http://iso.org/OTX/ExtensionInterface/HeadUnit']='HeadUnit',['http://iso.org/OTX/ExtensionInterface/Inventory']='Inventory',['http://iso.org/OTX/ExtensionInterface/Persistence']='Persistency',['http://iso.org/OTX/ProprietaryInterface/RemoteMeasurement']='RemoteMeasurement',['http://www.bosch.com/OTX/GX_SECURITY']='Security',['http://gradex.bosch.com/OTX/1.0.0/Telediagnosis']='Tele',['http://iso.org/OTX/ProprietaryInterface/UnifiedReturnStructures']='UnifiedReturnStructures',['http://iso.org/OTX/ProprietaryInterface/VehicleProperties']='VehicleProperties'})

tdutil.loadOtxNamespaceModule({'http://iso.org/OTX/1.0.0/Event','http://iso.org/OTX/1.0.0/Logging','http://iso.org/OTX/1.0.0/StringUtil'})
tdutil.loadCustomerNamespaceModule({'http://iso.org/OTX/ProprietaryInterface/RemoteMeasurement','http://iso.org/OTX/ProprietaryInterface/UnifiedReturnStructures'})

local _ENV  = OtxModule.declare('Telediagnosis.RemoteGradeX', 'PDJobE2E', '0.90.0', _ENV)
_var_job = nil
OtxModule.setPublic('_var_CDP_5FJOB_5FID', _ENV)
_var_CDP_5FJOB_5FID = String:new('52e1e081-74ff-4a2c-a3dc-36f484e0dfd8')
_var_dataIter = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
_var_seriesName = String:new('')
_var_timestamp = 0
_var_value = 0.0
_var_SigMatrix = ListType:new({}, {'list',{'list','number'}})
_var_Cluster2d = nil --[=[ TODO we might replace those with a dummy-object throwing InvalidReferenceException on access]=]
_var_resulttmp = ListType:new({}, {'list',{'list','number'}})
_var_TimeMatrix = ListType:new({}, {'list',{'list','number'}})
OtxModule.setPublic('_prc_main', _ENV)
function _prc_main(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_sumResultElements = 0
	local _var_scriptResult = 0
	local _var_result = ListType:new({}, {'list',{'list','number'}})
	
	-- inout and out parameters
	getReturnTable = function() return {_var_sumResultElements=_var_sumResultElements, _var_scriptResult=_var_scriptResult, _var_result=_var_result} end
	
	-- procedure declarations
	local _var_seriesIndex = 0
	local _var_dataPointIndex = 0
	local _var_NumOfSerieDataPoints = 0
	local _var_NumOfSerie = 0
	local _var_i1 = 0
	local _var_xWidth = 0
	local _var_yWidth = 0
	local _var_railP_5FpFlt = 0.0
	local _var_Epm_5FnEng = 0.0
	local _var_row = 0
	local _var_column = 0
	
	-- NODE-ID: handler1
	OtxDebug.setCurrentNodeId('handler1')
	OtxExceptions.handler(
		function() --try
				UnifiedReturnStructures.EnableDebug(true)
				-- NODE-ID: group2
				OtxDebug.setCurrentNodeId('group2')
				OtxDebug.logSpecification('CDP Job')
				do
					-- NODE-ID: action3
					OtxDebug.setCurrentNodeId('action3')
					_var_job = RemoteMeasurement.CreateMeasurementJob(_var_CDP_5FJOB_5FID, String:new('cdpjob.xml'), nil, nil, nil)
					
					-- NODE-ID: action13
					OtxDebug.setCurrentNodeId('action13')
					RemoteMeasurement.InstallMeasurementJob(_var_job)
					
				end
				
				-- NODE-ID: action1
				OtxDebug.setCurrentNodeId('action1')
				EventHandling.WaitForEvent({EventHandling.TimerEvent:new(180000)})
				
				-- NODE-ID: action4
				OtxDebug.setCurrentNodeId('action4')
				_var_job = RemoteMeasurement.GetMeasurementJob(_var_CDP_5FJOB_5FID)
				
				-- NODE-ID: action5
				OtxDebug.setCurrentNodeId('action5')
				_var_dataIter = RemoteMeasurement.CreateMeasurementDataIterator(_var_job)
				
				-- NODE-ID: action19
				OtxDebug.setCurrentNodeId('action19')
				OtxDebug.addStackLevel('initialResultMatrix')
				local _tmp_returnTable1
				_tmp_returnTable1 = _prc_initialResultMatrix({})
				OtxDebug.decrementStackLevel()
				if (_tmp_returnTable1 ~= nil) then
					_var_yWidth = _tmp_returnTable1._var_CLASS_5FWIDTH_5FX
					_var_xWidth = _tmp_returnTable1._var_CLASS_5FWIDTH_5FY
				end
				
				-- NODE-ID: loop1
				OtxDebug.setCurrentNodeId('loop1')
				while (RemoteMeasurement.GetNextMeasurementBuffer(_var_dataIter)) do
					-- NODE-ID: action11
					OtxDebug.setCurrentNodeId('action11')
					_var_NumOfSerie = RemoteMeasurement.GetNumberOfSeries(_var_dataIter)
					
					-- NODE-ID: loop2
					OtxDebug.setCurrentNodeId('loop2')
					_var_seriesIndex = 0
					while (_var_seriesIndex <= (_var_NumOfSerie - 1)) do
						-- NODE-ID: action12
						OtxDebug.setCurrentNodeId('action12')
						_var_NumOfSerieDataPoints = RemoteMeasurement.GetNumberOfSeriesDataPoints(_var_dataIter, _var_seriesIndex)
						
						-- NODE-ID: action6
						OtxDebug.setCurrentNodeId('action6')
						_var_seriesName = RemoteMeasurement.GetSeriesName(_var_dataIter, _var_seriesIndex)
						
						-- NODE-ID: action24
						OtxDebug.setCurrentNodeId('action24')
						_var_TimeMatrix:append({ListType:new({ListType:new({0},{'list','number'})},{'list',{'list','number'}})})
						
						-- NODE-ID: action26
						OtxDebug.setCurrentNodeId('action26')
						_var_SigMatrix:append({ListType:new({ListType:new({0.0},{'list','number'})},{'list',{'list','number'}})})
						
						-- NODE-ID: action9
						-- DISABLED!
						
						-- NODE-ID: loop3
						OtxDebug.setCurrentNodeId('loop3')
						_var_dataPointIndex = 0
						while (_var_dataPointIndex <= (_var_NumOfSerieDataPoints - 1)) do
							-- NODE-ID: action7
							OtxDebug.setCurrentNodeId('action7')
							_var_timestamp = RemoteMeasurement.GetSeriesDataPointTimestamp(_var_dataIter, _var_seriesIndex, _var_dataPointIndex)
							
							-- NODE-ID: action8
							OtxDebug.setCurrentNodeId('action8')
							_var_value = RemoteMeasurement.GetSeriesDataPointValueAsFloat(_var_dataIter, _var_seriesIndex, _var_dataPointIndex)
							
							-- NODE-ID: action25
							OtxDebug.setCurrentNodeId('action25')
							_var_TimeMatrix[_var_seriesIndex][_var_dataPointIndex] = _var_timestamp
							
							-- NODE-ID: action15
							OtxDebug.setCurrentNodeId('action15')
							_var_SigMatrix[_var_seriesIndex][_var_dataPointIndex] = _var_value
							
							-- NODE-ID: action10
							-- DISABLED!
							
							_var_dataPointIndex = _var_dataPointIndex + 1
						end
						
						_var_seriesIndex = _var_seriesIndex + 1
					end
					
					-- NODE-ID: loop11
					OtxDebug.setCurrentNodeId('loop11')
					_var_i1 = 0
					while (_var_i1 <= (_var_NumOfSerieDataPoints - 2)) do
						-- NODE-ID: action29
						OtxDebug.setCurrentNodeId('action29')
						_var_Epm_5FnEng = _var_SigMatrix[0][_var_i1]
						
						-- NODE-ID: action30
						OtxDebug.setCurrentNodeId('action30')
						_var_railP_5FpFlt = _var_SigMatrix[1][_var_i1]
						
						-- NODE-ID: action32
						OtxDebug.setCurrentNodeId('action32')
						_var_row = OtxMath.ToInteger((_var_railP_5FpFlt / _var_yWidth))
						
						-- NODE-ID: action31
						OtxDebug.setCurrentNodeId('action31')
						_var_column = OtxMath.ToInteger((_var_Epm_5FnEng / _var_xWidth))
						
						-- NODE-ID: action33
						OtxDebug.setCurrentNodeId('action33')
						_var_resulttmp[_var_row][_var_column] = (_var_resulttmp[_var_row][_var_column] + (_var_TimeMatrix[0][(_var_i1 + 1)] - _var_TimeMatrix[0][_var_i1]))
						
						-- NODE-ID: action34
						OtxDebug.setCurrentNodeId('action34')
						_var_sumResultElements = (_var_sumResultElements + (_var_TimeMatrix[0][(_var_i1 + 1)] - _var_TimeMatrix[0][_var_i1]))
						
						_var_i1 = _var_i1 + 1
					end
					
				end
				
				-- NODE-ID: loop12
				OtxDebug.setCurrentNodeId('loop12')
				_var_i1 = 0
				while (_var_i1 <= (#_var_resulttmp - 1)) do
					-- NODE-ID: action35
					OtxDebug.setCurrentNodeId('action35')
					_var_Cluster2d:addIntegerValues(_var_resulttmp[_var_i1].provider)
					
					_var_i1 = _var_i1 + 1
				end
				
				-- NODE-ID: action36
				OtxDebug.setCurrentNodeId('action36')
				_var_Cluster2d:save()
				
				-- NODE-ID: action37
				OtxDebug.setCurrentNodeId('action37')
				_var_result = _var_resulttmp
				
				-- NODE-ID: action2
				OtxDebug.setCurrentNodeId('action2')
				RemoteMeasurement.UninstallMeasurementJob(_var_job)
				
		end, { --catch
			OtxExceptions.createCatch('ArithmeticException', 
				function(exception)
				end
			),
			OtxExceptions.createCatch('OutOfBoundsException', 
				function(exception)
				end
			),
			OtxExceptions.createCatch('Exception', 
				function(exception)
				end
			),
		}, function() --finally
		end
	)
	
	-- NODE-ID: return
	OtxDebug.setCurrentNodeId('return')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

function _prc_initialResultMatrix(argumentsTable)
	local getReturnTable = function() return nil end
	
	-- parameter declarations
	local _var_MAX_5FPRESS = 3000
	local _var_MIN_5FPRESS = 0
	local _var_NUM_5FCLASS_5FPRESS = 15
	local _var_MAX_5FROT = 6000
	local _var_MIN_5FROT = 0
	local _var_NUM_5FCLASS_5FROT = 30
	local _var_SamplingRate = 10
	local _var_CLASS_5FWIDTH_5FX = 0
	local _var_CLASS_5FWIDTH_5FY = 0
	
	-- in and inout parameters
	if (argumentsTable._var_MAX_5FPRESS ~= nil) then _var_MAX_5FPRESS = tdutil.checkParamType(argumentsTable._var_MAX_5FPRESS, 3000) end
	if (argumentsTable._var_MIN_5FPRESS ~= nil) then _var_MIN_5FPRESS = tdutil.checkParamType(argumentsTable._var_MIN_5FPRESS, 0) end
	if (argumentsTable._var_NUM_5FCLASS_5FPRESS ~= nil) then _var_NUM_5FCLASS_5FPRESS = tdutil.checkParamType(argumentsTable._var_NUM_5FCLASS_5FPRESS, 15) end
	if (argumentsTable._var_MAX_5FROT ~= nil) then _var_MAX_5FROT = tdutil.checkParamType(argumentsTable._var_MAX_5FROT, 6000) end
	if (argumentsTable._var_MIN_5FROT ~= nil) then _var_MIN_5FROT = tdutil.checkParamType(argumentsTable._var_MIN_5FROT, 0) end
	if (argumentsTable._var_NUM_5FCLASS_5FROT ~= nil) then _var_NUM_5FCLASS_5FROT = tdutil.checkParamType(argumentsTable._var_NUM_5FCLASS_5FROT, 30) end
	if (argumentsTable._var_SamplingRate ~= nil) then _var_SamplingRate = tdutil.checkParamType(argumentsTable._var_SamplingRate, 10) end
	
	-- inout and out parameters
	getReturnTable = function() return {_var_CLASS_5FWIDTH_5FX=_var_CLASS_5FWIDTH_5FX, _var_CLASS_5FWIDTH_5FY=_var_CLASS_5FWIDTH_5FY} end
	
	-- procedure declarations
	local _var_i1 = 0
	local _var_Xlabels = ListType:new({}, {'list','OTXString'})
	local _var_Xlimits = ListType:new({}, {'list','number'})
	local _var_i2 = 0
	local _var_Ylabels = ListType:new({}, {'list','OTXString'})
	local _var_Ylimits = ListType:new({}, {'list','number'})
	
	-- NODE-ID: action28
	OtxDebug.setCurrentNodeId('action28')
	OtxDebug.logSpecification('X-Width')
	-- SPEC: X-Width
	_var_CLASS_5FWIDTH_5FY = ((_var_MAX_5FPRESS - _var_MIN_5FPRESS) / _var_NUM_5FCLASS_5FPRESS)
	
	-- NODE-ID: action75
	OtxDebug.setCurrentNodeId('action75')
	OtxDebug.logSpecification('Y-Width')
	-- SPEC: Y-Width
	_var_CLASS_5FWIDTH_5FX = ((_var_MAX_5FROT - _var_MIN_5FROT) / _var_NUM_5FCLASS_5FROT)
	
	-- NODE-ID: group6
	OtxDebug.setCurrentNodeId('group6')
	OtxDebug.logSpecification('Unified Return Structures')
	do
		-- NODE-ID: loop6
		OtxDebug.setCurrentNodeId('loop6')
		_var_i1 = 0
		while (_var_i1 <= (_var_NUM_5FCLASS_5FROT - 1)) do
			-- NODE-ID: action22
			OtxDebug.setCurrentNodeId('action22')
			OtxDebug.logSpecification('X Labels')
			-- SPEC: X Labels
			_var_Xlabels:append({String:new('x')..ToString((_var_i1 + 1))})
			
			-- NODE-ID: action27
			OtxDebug.setCurrentNodeId('action27')
			OtxDebug.logSpecification('X Limits')
			-- SPEC: X Limits
			_var_Xlimits:append({(OtxMath.ToFloat(_var_CLASS_5FWIDTH_5FX) * OtxMath.ToFloat((_var_i1 + 1)))})
			
			_var_i1 = _var_i1 + 1
		end
		
		-- NODE-ID: loop9
		OtxDebug.setCurrentNodeId('loop9')
		_var_i2 = 0
		while (_var_i2 <= (_var_NUM_5FCLASS_5FPRESS - 1)) do
			-- NODE-ID: action76
			OtxDebug.setCurrentNodeId('action76')
			OtxDebug.logSpecification('Y Labels')
			-- SPEC: Y Labels
			_var_Ylabels:append({String:new('y')..ToString((_var_i2 + 1))})
			
			-- NODE-ID: action18
			OtxDebug.setCurrentNodeId('action18')
			OtxDebug.logSpecification('X Limits')
			-- SPEC: X Limits
			_var_Ylimits:append({(OtxMath.ToFloat(_var_CLASS_5FWIDTH_5FY) * OtxMath.ToFloat((_var_i2 + 1)))})
			
			_var_i2 = _var_i2 + 1
		end
		
		-- NODE-ID: action78
		OtxDebug.setCurrentNodeId('action78')
		OtxDebug.logSpecification('make cluster')
		-- SPEC: make cluster
		_var_Cluster2d = UnifiedReturnStructures.CreateCluster2D(tostring(String:new('LoadCollectionMeasurement')), tostring(String:new('HPS_Time_LCMnp')), {name=tostring(String:new('Engine Speed')), description=tostring(String:new('Epm_nEng')), labels=UnifiedReturnStructures.toStringList(_var_Xlabels), limits=_var_Xlimits.provider, sampling_rate=_var_SamplingRate, unit=tostring(String:new('rpm'))}, {name=tostring(String:new('Rail Pressure')), description=tostring(String:new('railP')), labels=UnifiedReturnStructures.toStringList(_var_Ylabels), limits=_var_Ylimits.provider, sampling_rate=_var_SamplingRate, unit=tostring(String:new('bar'))}, 4)
		
	end
	
	-- NODE-ID: group1
	OtxDebug.setCurrentNodeId('group1')
	OtxDebug.logSpecification('RESULT-MATRIX')
	do
		-- NODE-ID: loop7
		OtxDebug.setCurrentNodeId('loop7')
		_var_i1 = 0
		while (_var_i1 <= (_var_NUM_5FCLASS_5FPRESS - 1)) do
			-- NODE-ID: action20
			OtxDebug.setCurrentNodeId('action20')
			_var_resulttmp:append({ListType:new({ListType:new({0},{'list','number'})},{'list',{'list','number'}})})
			
			-- NODE-ID: loop8
			OtxDebug.setCurrentNodeId('loop8')
			_var_i2 = 0
			while (_var_i2 <= (_var_NUM_5FCLASS_5FROT - 1)) do
				-- NODE-ID: action21
				OtxDebug.setCurrentNodeId('action21')
				_var_resulttmp[_var_i1][_var_i2] = 0
				
				_var_i2 = _var_i2 + 1
			end
			
			_var_i1 = _var_i1 + 1
		end
		
	end
	
	-- NODE-ID: return2
	OtxDebug.setCurrentNodeId('return2')
	do return getReturnTable() end
	
	do return getReturnTable() end
end

local _var_seq_result = OtxModule.defineMainAndExecute(_ENV, function()
	local mainArgs = {}
	local outArgTypes = {_var_sumResultElements='Integer',_var_scriptResult='Integer',_var_result='List'}
	return tdutil.runMain(_prc_main, mainArgs, outArgTypes)
end)

return _var_seq_result
